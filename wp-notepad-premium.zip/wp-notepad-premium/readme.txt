﻿=== Wp-Notepad premium   ===
Contributors: Amir Reza Khanjan
Donate link: https://notepad.titanicuk.org/
Tags: Notepad,Notepad Plugin, Reminder,plugin,parsi, persian,افزونه یاداشت نگاری 
Requires at least: 3.0.1
Tested up to: 4.9.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 A Plugin  for reminding and note of users on the client side


== Description ==

  A Plugin  for reminding and note of users on the client side


== Installation ==

1. Upload plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3.Use [Note]  Shortcode For Show Notes . 
4.Use `<?php echo do_shortcode('[Note') ?>` php code in themeplate. 
5.Use [note-login]  Shortcode For Custom Login And Registre . 
== Screenshots ==

1. Note Page 
2. Login page 
== Changelog ==

= 1.0 =
 *head version of plugin

== Upgrade Notice ==

= 1.0 =
Upgrade notices describe the reason a user should upgrade.  No more than 300 characters.






<?php 
/**
* Plugin Name: Wp-Connect
* Plugin URI: 
* Description:A For Check Connet Internet
* Version: 1.0.0
* Author: Mandegarweb Team
* Author URI: http://mandegarweb.com/
*
 * @package Connect
 * @category Wordpress
 * @author Mandegarweb
*
*/

/*
*
*check for correct directory
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'Connect' ) ) :
/**
* 
*define Cunter  class
* @version 1.0
*/
class Connect 
{
/**
 * WooCommerce version.
 *
 * @var string
*/
	public $version = '1.0.0';
/**
*
 *@var string
*/

	function __construct()
	{
     include_once('lib/autoload.php');
	}
	
}
$load=new Connect();
endif;?>

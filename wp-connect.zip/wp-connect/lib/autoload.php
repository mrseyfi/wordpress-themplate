<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class A_Connet  {

	public function __construct() 
	{
  add_action('admin_enqueue_scripts', array(&$this,'mandegarweb_Insurance_js_and_css'));  
  add_action('wp_enqueue_scripts', array(&$this,'mandegarweb_Insurance_js_and_css'));
  add_action( 'wp_footer', array(&$this,'Mandegarweb_wp_footer'),10,2,0 );
  add_action( 'admin_footer', array(&$this,'Mandegarweb_wp_footer'),10,2,0 );

  }
  

  function mandegarweb_Insurance_js_and_css()
  {

  wp_register_style('connect_css', plugins_url('/css/style.css', __FILE__) );
  wp_enqueue_style( 'connect_css' );
    wp_enqueue_script( "connect_js", plugin_dir_url( __FILE__ ) . 'js/connect.js', array( 'jquery' ) );
  }
  function Mandegarweb_wp_footer()
  {

    $htmls='
     <div class="connect" id="connect">
      <div class="offline-ui" id="bgconnet">
         <div class="offline-ui-content" id="connect-content">Connection lost. Reconnecting in <span id="secound"></span> seconds...</div>
         <div class="reconnect">Reconnect</div>
         <div class="loaders"></div>
      </div>
     </div>';

    echo  $htmls;
  }
   
					
					         
		}
new A_Connet();
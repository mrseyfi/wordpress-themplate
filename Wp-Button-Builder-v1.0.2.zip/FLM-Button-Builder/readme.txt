
                                        ||--[]---[]---[]---[]---[]------[]--[]-||
                                        |					|
                                        |					|
                                        |  Copy Right By: 20 SCRIPT		|
                                        |					|
                                        |					|
                                        |  Web Site: www.20script.IR        	|
                                        |					|
                                        |					|
                                        |  Forum: www.20script.ir/forum	        |
                                        |					|
                                        |					|
                                        |  Shop: www.20script.ir/shop		|
                                        |					|
                                        |					|
                                        |  Yahoo ID: abiweb                     | 
                                        |                                       | 
                                        |  Email : abiweb@yahoo.com		|
                                        |	    		                |
                                        |					|
                                        |					|
                                        |					|
                                        ||--[]---[]---[]---[]---[]------[]--[]-||


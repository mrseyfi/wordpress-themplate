<?php
//==========================================================
// Options
//==========================================================
require_once "Admin-Utility.php";
$Options = get_option( "FLMBTN" );
?>

<div id="Overlay"></div>

<div id="Wrapper" class="wrap">

	<div id="Header" class="CLR">
		<div id="Header-Icon"></div>
		<div id="Header-Title">Button Builder</div>
		<div id="Header-Right" class="CLR">
			<div id="Header-Button" class="Trans">Save Settings</div>
			<div id="Header-Loading"></div>
		</div>
	</div>
	
	<div id="Messages"></div>
	
	<div id="Main">
		<form id="Settings-Form">
		
			<!--========================================================
			// Sidebar
			=========================================================-->
			<nav id="Sidebar">
				<ul>
					<li id="Side-Builder">Builder</li>
					<li id="Side-Settings">Settings</li>
				</ul>
				<div class="Sidebar-Line"></div>
				<ul>
					<li id="Side-About">About Plugin</li>
					<li id="Side-Support">Plugin Support</li>
				</ul>
			</nav>
			
			<!--========================================================
			// SECTION: Builder
			=========================================================-->
			<section id="Section-Builder" class="Section">
			
				<!-- Preview -->
				<div id="Preview-Placeholder"></div>
				<div id="Preview">
					<div id="Preview-Title">Button Preview</div>
					<div id="Preview-Picker" class="Button" title="Change Background Color"><i class="fa fa-tint"></i></div>
					<input type="text" id="Preview-Color" class="Hidden" />
					<div id="Preview-Box"></div>
				</div>
				
				<!-- Code -->
				<div id="Code">
					<div id="Code-Top" class="CLR">
						<div id="Code-Tabs">
							<div id="Code-Tab-Shortcode" class="Button Left Active">Shortcode</div>
							<div id="Code-Tab-HTML" class="Button Left">HTML</div>
							<div id="Code-Tab-PHP" class="Button Left">PHP</div>
						</div>
						<div id="Code-Button" class="Button Right">Highlight</div>
					</div>
					<textarea type="text" class="Code-Text" id="Code-Text-Shortcode" readonly></textarea>
					<textarea type="text" class="Code-Text" id="Code-Text-HTML" readonly></textarea>
					<textarea type="text" class="Code-Text" id="Code-Text-PHP" readonly></textarea>
				</div>
				
				<!-- Box -->
				<div id="Box">
					<div id="Box-Tabs" class="CLR">
						<div id="Box-Tab-Details" class="Button Left Active">Details</div>
						<div id="Box-Tab-Styles"  class="Button Left">Styles</div>
						<div id="Box-Tab-Custom"  class="Button Left">Customize</div>
						<div id="Box-Tab-Icons"   class="Button Left">Icons</div>
						<div id="Box-Tab-Import"  class="Button Right">Import</div>
						<div id="Box-Tab-Extras"  class="Button Right">Extras</div>
					</div>
					
					<!-- Box Section - Details -->
					<section id="Box-Section-Details" class="Box-Section CLR">
					
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Link-Address">Link Address</label></div>
							<div class="Row-Right">
								<input type="text" id="OPT-Link-Address" spellcheck="false">
								<div id="Box-Menu-Shortcuts" class="Box-Menu">
									<div id="Box-Button-Shortcuts" class="Box-Button Trans" data-toggle="dropdown">
										Shortcuts &nbsp;<i class="fa fa-caret-down"></i>
									</div>
									<ul id="Box-Menu-Shortcuts" class="Box-Menu" aria-labelledby="Box-Button-Shortcuts">
										<li id="Shortcut-Home-Site">Home - Site</li>
										<li id="Shortcut-Home-Network">Home - Network</li>
										<li id="Shortcut-Admin-Panel">Admin Panel</li>
										<li id="Shortcut-Login">Login</li>
										<li id="Shortcut-Logout">Logout</li>
										<li id="Shortcut-Register">Register</li>
										<li id="Shortcut-Lost-Password">Lost Password</li>
										<li id="Shortcut-Dir-Includes">Directory - Includes</li>
										<li id="Shortcut-Dir-Content">Directory - Content</li>
										<li id="Shortcut-Dir-Stylesheet">Directory - Stylesheet</li>
										<li id="Shortcut-Dir-Template">Directory - Template</li>
									</ul>
								</div>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Link-Title">Link Target</label></div>
							<div class="Row-Right">
								<select id="OPT-Link-Target">
									<option value="">Default</option>
									<option value="_self">Self - Same Window</option>
									<option value="_blank">Blank - New Window</option>
									<option value="_parent">Parent - Parent Frameset</option>
									<option value="_top">Top - Top Document in Window</option>
								</select>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Link-Title">Link Title</label></div>
							<div class="Row-Right"><input type="text" id="OPT-Link-Title" spellcheck="false"></div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Link-Rel">Link Rel</label></div>
							<div class="Row-Right">
								<select id="OPT-Link-Rel">
									<option value="">None</option>
									<option value="alternate">Alternate - Links to an alternate version of the document.</option>
									<option value="author">Author - Links to the author of the document.</option>
									<option value="bookmark">Bookmark - Permanent URL used for bookmarking.</option>
									<option value="help">Help - Links to a help document.</option>
									<option value="license">License - Links to copyright information for the document.</option>
									<option value="next">Next - The next document in a selection.</option>
									<option value="nofollow">NoFollow - Links to an unendorsed document, like a paid link.</option>
									<option value="noreferrer">NoReferrer - Specifies that the browser should not send a HTTP referer header.</option>
									<option value="prefetch">Prefetch - Specifies that the target document should be cached.</option>
									<option value="prev">Prev - The previous document in a selection.</option>
									<option value="search">Search - Links to a search tool for the document.</option>
									<option value="tag">Tag - A tag (keyword) for the current document.</option>
								</select>
							</div>
						</div>
						
						<div class="Row-Line"></div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Custom-ID">Custom ID</label></div>
							<div class="Row-Right"><input type="text" id="OPT-Custom-ID" spellcheck="false"></div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Custom-Class">Custom Class</label></div>
							<div class="Row-Right"><input type="text" id="OPT-Custom-Class" spellcheck="false"></div>
						</div>
						
						<div class="Row-Line"></div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Text">Button Text</label></div>
							<div class="Row-Right"><input type="text" id="OPT-Button-Text"></div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Small">Button Small Text</label></div>
							<div class="Row-Right"><input type="text" id="OPT-Button-Small"></div>
						</div>
					</section>
					
					<!-- Box Section - Styles -->
					<section id="Box-Section-Styles" class="Box-Section CLR">
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Size">Button Size</label></div>
							<div class="Row-Right">
								<select id="OPT-Button-Size">
									<option value="XS">X-Small</option>
									<option value="SM">Small</option>
									<option value="MD">Medium</option>
									<option value="LG">Large</option>
								</select>
							</div>
						</div>
	
						<div class="Row-Line"></div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Color">Button Color</label></div>
							<div class="Row-Right">
								<select id="OPT-Button-Color">
									<option value="Light">Light</option>
									<option value="Tan">Tan</option>
									<option value="Dark">Dark</option>
									<option value="Blue">Blue</option>
									<option value="Green">Green</option>
									<option value="Red">Red</option>
									<option value="Orange">Orange</option>
									<option value="Yellow">Yellow</option>
									<option value="Pink">Pink</option>
									<option value="Purple">Purple</option>
									<option value="Black">Black (Outline)</option>
									<option value="White">White (Outline)</option>
								</select>
							</div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Text-Color">Text Color</label></div>
							<div class="Row-Right">
								<select id="OPT-Text-Color">
									<option value="Default">Default</option>
									<option value="Engrave">Engrave</option>
									<option value="Light">Light</option>
									<option value="Tan">Tan</option>
									<option value="Dark">Dark</option>
									<option value="Blue">Blue</option>
									<option value="Green">Green</option>
									<option value="Red">Red</option>
									<option value="Orange">Orange</option>
									<option value="Yellow">Yellow</option>
									<option value="Pink">Pink</option>
									<option value="Purple">Purple</option>
									<option value="Black">Black</option>
									<option value="White">White</option>
								</select>
							</div>
						</div>
	
						<div class="Row-Line"></div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Style">Button Style</label></div>
							<div class="Row-Right">
								<select id="OPT-Button-Style">
									<option value="Default">Default</option>
									<option value="Flat">Flat</option>
									<option value="Border">Border</option>
									<option value="Outline">Outline</option>
								</select>
							</div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Style-Icon">Button Style Icon</label></div>
							<div class="Row-Right">
								<select id="OPT-Button-Style-Icon">
									<option value="None">None</option>
									<option value="Lines-Left">Lines Left</option>
									<option value="Lines-Right">Lines Right</option>
									<option value="Mask-Left">Mask Left</option>
									<option value="Mask-Right">Mask Right</option>
								</select>
							</div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Style-3D">Button Style 3D</label></div>
							<div class="Row-Right">
								<select id="OPT-Button-Style-3D">
									<option value="None">None</option>
									<option value="D3">3D</option>
									<option value="D3-Large">Large 3D</option>
								</select>
							</div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Hover">Button Hover</label></div>
							<div class="Row-Right">
								<select id="OPT-Button-Hover">
									<option value="None">None</option>
									<option value="Hover-Light">Outline: Light</option>
									<option value="Hover-Tan">Outline: Tan</option>
									<option value="Hover-Dark">Outline: Dark</option>
									<option value="Hover-Blue">Outline: Blue</option>
									<option value="Hover-Green">Outline: Green</option>
									<option value="Hover-Red">Outline: Red</option>
									<option value="Hover-Orange">Outline: Orange</option>
									<option value="Hover-Yellow">Outline: Yellow</option>
									<option value="Hover-Pink">Outline: Pink</option>
									<option value="Hover-Purple">Outline: Purple</option>
									<option value="Hover-Black">Outline: Black</option>
									<option value="Hover-White">Outline: White</option>
									<option value="HoverB-Light">Border: Light</option>
									<option value="HoverB-Tan">Border: Tan</option>
									<option value="HoverB-Dark">Border: Dark</option>
									<option value="HoverB-Blue">Border: Blue</option>
									<option value="HoverB-Green">Border: Green</option>
									<option value="HoverB-Red">Border: Red</option>
									<option value="HoverB-Orange">Border: Orange</option>
									<option value="HoverB-Yellow">Border: Yellow</option>
									<option value="HoverB-Pink">Border: Pink</option>
									<option value="HoverB-Purple">Border: Purple</option>
									<option value="HoverB-Black">Border: Black</option>
									<option value="HoverB-White">Border: White</option>
									<option value="HoverF-Light">Flat: Light</option>
									<option value="HoverF-Tan">Flat: Tan</option>
									<option value="HoverF-Dark">Flat: Dark</option>
									<option value="HoverF-Blue">Flat: Blue</option>
									<option value="HoverF-Green">Flat: Green</option>
									<option value="HoverF-Red">Flat: Red</option>
									<option value="HoverF-Orange">Flat: Orange</option>
									<option value="HoverF-Yellow">Flat: Yellow</option>
									<option value="HoverF-Pink">Flat: Pink</option>
									<option value="HoverF-Purple">Flat: Purple</option>
									<option value="HoverF-Black">Flat: Black</option>
									<option value="HoverF-White">Flat: White</option>
								</select>
							</div>
						</div>
	
						<div class="Row-Line"></div>
	
						<div class="Row CLR">
							<div class="Row-Left">Rounded Corners</div>
							<div class="Row-Right">
								<div id="Slider-Rounded-Corners"></div>
								<div id="OPT-Rounded-Corners" class="Form-Count"></div>
							</div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left">Box Shadow</div>
							<div class="Row-Right">
								<div id="Slider-Box-Shadow"></div>
								<div id="OPT-Box-Shadow" class="Form-Count"></div>
							</div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left">Text Shadow</div>
							<div class="Row-Right">
								<div id="Slider-Text-Shadow"></div>
								<div id="OPT-Text-Shadow" class="Form-Count"></div>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left">Opacity</div>
							<div class="Row-Right">
								<div id="Slider-Opacity"></div>
								<div id="OPT-Opacity" class="Form-Count"></div>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left">Opacity Hover</div>
							<div class="Row-Right">
								<div id="Slider-Opacity-Hover"></div>
								<div id="OPT-Opacity-Hover" class="Form-Count"></div>
							</div>
						</div>
	
						<div class="Row-Line"></div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Animate-Icon">Animate Icon</label></div>
							<div class="Row-Right">
								<select id="OPT-Animate-Icon">
									<option value="None">None</option>
									<option value="Rotate-90">Rotate 90 Degrees</option>
									<option value="Rotate-180">Rotate 180 Degrees</option>
									<option value="Rotate-360">Rotate 360 Degrees</option>
									<option value="Zoom">Zoom</option>
									<option value="Loop">Loop</option>
									<option value="Grow">Grow</option>
									<option value="Shrink">Shrink</option>
									<option value="Skew">Skew</option>
									<option value="Flip-LR">Flip Left to Right</option>
									<option value="Flip-TB">Flip Top to Bottom</option>
								</select>
							</div>
						</div>
	
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Animate-Button">Animate Button</label></div>
							<div class="Row-Right">
								<select id="OPT-Animate-Button">
									<option value="None">None</option>
									<option value="Rotate">Rotate</option>
									<option value="Grow">Grow</option>
									<option value="Shrink">Shrink</option>
									<option value="Flip-LR">Flip Left to Right</option>
									<option value="Flip-TB">Flip Top to Bottom</option>
								</select>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Transitions">CSS Transitions</label></div>
							<div class="Row-Right">
								<select id="OPT-Transitions">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>
					</section>
					
					<!-- Box Section - Customize -->
					<section id="Box-Section-Custom" class="Box-Section CLR">
						<div class="Row CLR">
							<div class="Row-Left">
								<label for="OPT-Font-Family">
									<abbr title="Optional: Override default font with custom font family or web-safe font family class.">Font Family</abbr>
								</label>
							</div>
							<div class="Row-Right">
								<input type="text" id="OPT-Font-Family" spellcheck="false">
								<div id="Box-Menu-Fonts" class="Box-Menu">
									<div id="Box-Button-Fonts" class="Box-Button Trans" data-toggle="dropdown">
										Fonts &nbsp;<i class="fa fa-caret-down"></i>
									</div>
									<ul id="Box-Menu-Fonts" class="Box-Menu" aria-labelledby="Box-Button-Fonts">
										<li id="Font-Arial"><strong>Sans-Serif |</strong> Arial</li>
										<li id="Font-Arial-Black"><strong>Sans-Serif |</strong> Arial Black</li>
										<li id="Font-Comic-Sans-MS"><strong>Sans-Serif |</strong> Comic Sans MS</li>
										<li id="Font-Impact"><strong>Sans-Serif |</strong> Impact</li>
										<li id="Font-Lucida-Sans"><strong>Sans-Serif |</strong> Lucida Sans</li>
										<li id="Font-Tahoma"><strong>Sans-Serif |</strong> Tahoma</li>
										<li id="Font-Trebuchet-MS"><strong>Sans-Serif |</strong> Trebuchet MS</li>
										<li id="Font-Verdana"><strong>Sans-Serif |</strong> Verdana</li>
										<li id="Font-Book-Antiqua"><strong>Serif |</strong> Book Antiqua</li>
										<li id="Font-Georgia"><strong>Serif |</strong> Georgia</li>
										<li id="Font-Times-New-Roman"><strong>Serif |</strong> Times New Roman</li>
										<li id="Font-Courier-New"><strong>Monospace |</strong> Courier New</li>
										<li id="Font-Lucida-Console"><strong>Monospace |</strong> Lucida Console</li>
									</ul>
								</div>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left">
								<label for="OPT-Font-Size">
									<abbr title="Optional: Override and set a specific font size using inline-styles.">Font Size</abbr>
								</label>
							</div>
							<div class="Row-Right"><input type="text" id="OPT-Font-Size" spellcheck="false"></div>
						</div>

						<div class="Row-Line"></div>
					
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Icon-Placement">Icon Placement</label></div>
							<div class="Row-Right">
								<select id="OPT-Icon-Placement">
									<option value="Left">Left Side</option>
									<option value="Right">Right Side</option>
									<option value="None">No Icon</option>
									<option value="Only">Icon Only</option>
								</select>
							</div>
						</div>

						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Small-Placement">Small Text Placement</label></div>
							<div class="Row-Right">
								<select id="OPT-Small-Placement">
									<option value="None">No Small Text</option>
									<option value="Left">Left Side</option>
									<option value="Right">Right Side</option>
								</select>
							</div>
						</div>

						<div class="Row-Line"></div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Button-Type">Button Float</label></div>
							<div class="Row-Right">
								<select id="OPT-Button-Float">
									<option value="None">None</option>
									<option value="Left">Left</option>
									<option value="Right">Right</option>
								</select>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left">
								<label for="OPT-Button-Width">
									<abbr title="Optional: Override and set a specific button width using inline-styles.">Button Width</abbr>
								</label>
							</div>
							<div class="Row-Right"><input type="text" id="OPT-Button-Width" spellcheck="false"></div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left">
								<label for="OPT-Button-Height">
									<abbr title="Optional: Override and set a specific button height using inline-styles.">Button Height</abbr>
								</label>
							</div>
							<div class="Row-Right"><input type="text" id="OPT-Button-Height" spellcheck="false"></div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left">
								<label for="OPT-Button-Line-Height">
									<abbr title="Optional: Override and set a specific button line-height using inline-styles.">Button Line Height</abbr>
								</label>
							</div>
							<div class="Row-Right"><input type="text" id="OPT-Button-Line-Height" spellcheck="false"></div>
						</div>
						
						<div class="Row-Line"></div>

						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Custom-Text-Toggle">Custom Text Color</label></div>
							<div class="Row-Right">
								<select id="OPT-Custom-Text-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>

						<div id="Custom-Text-Color" style="display: none";>
							<div class="Row CLR">
								<div class="Row-Left"><label for="OPT-Custom-Text-Color">Hex Color:</label></div>
								<div class="Row-Right">
									<input type="text" id="OPT-Custom-Text-Color">
								</div>
							</div>
						</div>

						<div class="Row-Line"></div>

						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Custom-BG-Toggle">Custom Background Color</label></div>
							<div class="Row-Right">
								<select id="OPT-Custom-BG-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>

						<div id="Custom-BG-Color" style="display: none";>
							<div class="Row CLR">
								<div class="Row-Left"><label for="OPT-Custom-BG-Color">Hex Color:</label></div>
								<div class="Row-Right">
									<input type="text" id="OPT-Custom-BG-Color">
								</div>
							</div>
						</div>
						
						<div class="Row-Line"></div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Custom-Border-Toggle">Custom Border Color</label></div>
							<div class="Row-Right">
								<select id="OPT-Custom-Border-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>

						<div id="Custom-Border-Color" style="display: none";>
							<div class="Row CLR">
								<div class="Row-Left"><label for="OPT-Custom-Border-Color">Hex Color:</label></div>
								<div class="Row-Right">
									<input type="text" id="OPT-Custom-Border-Color">
								</div>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Custom-BorderW-Toggle">Custom Border Width</label></div>
							<div class="Row-Right">
								<select id="OPT-Custom-BorderW-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>
						
						<div id="Custom-Border-Width" style="display: none";>
							<div class="Row CLR">
								<div class="Row-Left">Width (Pixels)</div>
								<div class="Row-Right">
									<div id="Slider-Custom-BorderW"></div>
									<div id="OPT-Custom-BorderW" class="Form-Count"></div>
								</div>
							</div>
						</div>
						
						<div class="Row CLR">
							<div class="Row-Left"><label for="OPT-Custom-Border-Style">Custom Border Style</label></div>
							<div class="Row-Right">
								<select id="OPT-Custom-Border-Style">
									<option value="Default">Default</option>
									<option value="None">None</option>
									<option value="Dashed">Dashed</option>
									<option value="Dotted">Dotted</option>
									<option value="Double">Double</option>
									<option value="Groove">Groove</option>
									<option value="Inset">Inset</option>
									<option value="Outset">Outset</option>
									<option value="Ridge">Ridge</option>
									<option value="Solid">Solid</option>
								</select>
							</div>
						</div>
						
					</section>
					
					<!-- Box Section - Icons -->
					<section id="Box-Section-Icons" class="Box-Section CLR">
						<div id="Search-Bar">
							<input type="text" id="Search-Text" placeholder="Search for...">
							<div id="Search-Icon" class="Button" title="Search Icons"><i class="fa fa-search"></i></div>
							<div id="Search-Reset" class="Button" title="Reset Search"><i class="fa fa-times"></i></div>
						</div>
						<div id="Box-Icons">
							<div id="Icons-List"></div>
						</div>
					</section>
					
					<!-- Box Section - Extras -->
					<section id="Box-Section-Extras" class="Box-Section CLR">
						<div class="Row Button-Row CLR">
							<div class="Row-Left">Reset Builder</div>
							<div class="Row-Right" id="Reset-Buttons">
								<div id="Reset-All"     class="Left Button-Alt">All</div>
								<div id="Reset-Details" class="Left Button-Alt">Details</div>
								<div id="Reset-Styles"  class="Left Button-Alt">Styles</div>
								<div id="Reset-Custom"  class="Left Button-Alt">Customize</div>
								<div id="Reset-Icons"   class="Left Button-Alt">Icons</div>
							</div>
						</div>
						<div class="Row-Line"></div>
	
						<div class="Row Button-Row CLR">
							<div class="Row-Left">Button Samples</div>
							<div class="Row-Right">
								<div id="Sample-Add-to-Cart" class="Left Button-Alt">Add to Cart</div>
								<div id="Sample-Order-Now"   class="Left Button-Alt">Order Now</div>
								<div id="Sample-Read-More"   class="Left Button-Alt">Read More</div>
								<div id="Sample-Top"         class="Left Button-Alt">Top</div>
								<div id="Sample-Previous"    class="Left Button-Alt">Previous</div>
								<div id="Sample-Facebook"    class="Left Button-Alt">Facebook</div>
								<div id="Sample-Tweet-This"  class="Left Button-Alt">Tweet This</div>
								<div id="Sample-Google-Plus" class="Left Button-Alt">Google Plus</div>
								<div id="Sample-GitHub"      class="Left Button-Alt">GitHub</div>
								<div id="Sample-Play-Video"  class="Left Button-Alt">Play Video</div>
							</div>
						</div>
					</section>
					
					<!-- Box Section - Import -->
					<section id="Box-Section-Import" class="Box-Section CLR">
						<div class="Center">
							<h1>Import Button Code</h1>
							<p>
								Simply copy and paste an existing button (Shortcode, HTML, or PHP) into the box and press import.<br>
								This will automatically set the options and styles to match the button and allow for easy editing.
								<br><br>
								<strong>Note:</strong> Works with generated code. Altered codes may produce erratic imports.
							</p>
						</div>
						<textarea id="Import-Box" spellcheck="false"></textarea>
						<div id="Import-Button" class="Button-Alt">Import Code</div>
						<div id="Import-Space" class="Hidden"></div>
					</section>
					
				</div>
				
			</section>
			
			<!--========================================================
			// SECTION: Settings
			=========================================================-->
			<section id="Section-Settings" class="Section">
				<div class="Section-Box">
					<h2>Font Awesome</h2>
					<div class="Section-Inner">
						<p>
							<h3>What is this?</h3>
							Font Awesome is a fantastic scalable icon font originally designed for Twitter Bootstrap, 
							but available for free online. This plugin uses the font to provide non-image icons for 
							the buttons upon rendering and creation.
							<br><br>
							<h3>Duplicate Loading</h3>
							If you are already loading Font Awesome on your site please feel free to disable the 
							load option below to reduce duplicate loading and increase site efficiency.
						</p>
						<hr>
						<table class="form-table">
							<?php
								FLM_Admin_Option( $Options, array(
									"Option"  => "Font_Awesome_Enqueue",
									"Type"    => "Checkbox",
									"Label"   => "Load Font Awesome?",
									"Indent"  => TRUE,
									"Default" => TRUE
								));

								FLM_Admin_Option( $Options, array(
									"Option" => "Font_Awesome_Source",
									"Type"   => "Select",
									"Label"  => "Source",
									"Opt_Val" => array( "Internal", "BootstrapCDN", "MaxCDN", "CDNJS" ),
									"Opt_Lbl" => array( "Internal: From Plugin", "External: Boostrap CDN", "External: MaxCDN", "External: cdnjs",  )
								));
							?>
						</table>
					</div>
				</div>
				
				<div class="Section-Box">
					<h2>Button Style Enqueue</h2>
					<div class="Section-Inner">
						<p>
							<h3>What does this do?</h3>
							Enable this option to enqueue the button CSS file (and Font Awesome if enabled) on each page of your site. Normally these
							files are only included when the button shortcode is used. This option is useful if you use the HTML button code from the 
							builder on your site.
						</p>
						<hr>
						<table class="form-table">
							<?php
								FLM_Admin_Option( $Options, array(
									"Option"  => "Button_Styles_Enqueue",
									"Type"    => "Checkbox",
									"Label"   => "Always Enqueue Button Styles?",
									"Default" => FALSE
								));
							?>
						</table>
					</div>
				</div>
				
				<div class="Section-Box">
					<h2>Additional Integrations</h2>
					<div class="Section-Inner">
						<p>
							<h3>What are these?</h3>
							This plugin includes additional integrations that can make it much easier to generate buttons 
							for your site on the fly. They are also completely optional if you do not wish to load them.
						</p>
						<hr>
						<table class="form-table">
							<?php
								FLM_Admin_Option( $Options, array(
									"Option"  => "Enable_Integration_Editor",
									"Type"    => "Checkbox",
									"Label"   => "WordPress Editor",
									"Default" => TRUE
								));
								
								/*FLM_Admin_Option( $Options, array(
									"Option"  => "Enable_Integration_VC",
									"Type"    => "Checkbox",
									"Label"   => "Visual Composer",
									"Default" => FALSE
								));*/
							?>
						</table>
					</div>
				</div>
			</section>
			
			<!--========================================================
			// SECTION: About Plugin
			=========================================================-->
			<section id="Section-About" class="Section">
				<div class="Section-Box">
					<h2>About Plugin</h2>
					<div class="Section-Inner">
						<p>
							<h3 style="margin-bottom: 20px;">Developed by <a href="http://fuselightmedia.com" target="_blank">Fuselight Media, LLC</a></h3>
							Fuselight Media provides custom website design &amp; development services, specializing in WordPress themes, plugins, and extensions.
							<br><br>
							We also provide consultation on custom application design and development ranging from widgets to complete web apps.
							<br><br>
							With the right planning and tools, we can turn your ideas into a virtual reality.
						</p>
					</div>
				</div>
			</section>
			
			<!--========================================================
			// SECTION: Plugin Support
			=========================================================-->
			<section id="Section-Support" class="Section">
				<div class="Section-Box">
					<h2>Plugin Support &amp; Feedback</h2>
					<div class="Section-Inner">
						<p>
							<h3>Having trouble with the plugin?</h3>
							Please message us via our <a href="http://codecanyon.net/user/Fuselight_Media" target="_blank">Envato Profile</a> 
							for help or see the product page for additional support information.
							<br><br>
							<h3>Have a suggestion?</h3>
							If you have any feedback or suggestions on improving the plugin, please let us know via our 
							<a href="http://codecanyon.net/user/Fuselight_Media" target="_blank">Envato Profile</a>.
						</p>
					</div>
				</div>

				<div class="Section-Box">
					<h2>Server Information</h2>
					<div class="Section-Inner">
						<p>
							This information can be used to help determine potential issues with the plugin based on your server setup.
						</p>
						<hr>
						<table class="form-table">
							<tr valign='top'>
								<h3 style="margin-top: 20px;">Software Versions</h3>
							</tr>
							<tr valign='top'>
								<th scope='row'>Plugin</th>
								<td><?php echo FLMBTN_VER; ?></td>
							</tr>
							<tr valign='top'>
								<th scope='row'><a href="https://wordpress.org/about/requirements" target="_blank">WordPress</a></th>
								<td><?php global $wp_version; echo $wp_version; ?></td>
							</tr>
							<tr valign='top'>
								<th scope='row'><a href="http://codex.wordpress.org/WordPress_Versions" target="_blank">WordPress DB</a></th>
								<td><?php echo FLMBTN_Utility::Get_WP_Option( "db_version" ); ?></td>
							</tr>
							<tr valign='top'>
								<th scope='row'><a href="https://www.mysql.com" target="_blank">MySQL</a></th>
								<td><?php global $wpdb; echo $wpdb->get_var( "SELECT VERSION()" ); ?></td>
							</tr>
							<tr valign='top'>
								<th scope='row'><a href="http://www.php.net" target="_blank">PHP</a></th>
								<td><?php echo phpversion(); ?></td>
							</tr>
						</table>
					</div>
				</div>
			</section>
		
		</form>
	</div> <!-- #Main -->

</div> <!-- #Wrapper -->

<!-- TEMPLATE: Message -->
<div id="Template-Message" class="Hidden">
	<div id="Message-{{CODE}}" class="Message {{TYPE}}">
		<div class="Message-Icon dashicons"></div>
		<div class="Message-Text">{{TEXT}}</div>
		<div class="Clear"></div>
	</div>
</div>
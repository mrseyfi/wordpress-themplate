// Boostrap Dropdown Menu
+function(d){function f(a){var b=a.attr("data-target");b||(b=(b=a.attr("href"))&&/#[A-Za-z]/.test(b)&&b.replace(/.*(?=#[^\s]*$)/,""));return(b=b&&d(b))&&b.length?b:a.parent()}function g(a){a&&3===a.which||(d(".dropdown-backdrop").remove(),d('[data-toggle="dropdown"]').each(function(){var b=d(this),c=f(b),e={relatedTarget:this};!c.hasClass("open")||a&&"click"==a.type&&/input|textarea/i.test(a.target.tagName)&&d.contains(c[0],a.target)||(c.trigger(a=d.Event("hide.bs.dropdown",e)),a.isDefaultPrevented()||
(b.attr("aria-expanded","false"),c.removeClass("open").trigger("hidden.bs.dropdown",e)))}))}var e=function(a){d(a).on("click.bs.dropdown",this.toggle)};e.VERSION="3.3.5";e.prototype.toggle=function(a){var b=d(this);if(!b.is(".disabled, :disabled")){var c=f(b);a=c.hasClass("open");g();if(!a){if("ontouchstart"in document.documentElement&&!c.closest(".navbar-nav").length)d(document.createElement("div")).addClass("dropdown-backdrop").insertAfter(d(this)).on("click",g);var e={relatedTarget:this};c.trigger(a=
d.Event("show.bs.dropdown",e));if(a.isDefaultPrevented())return;b.trigger("focus").attr("aria-expanded","true");c.toggleClass("open").trigger("shown.bs.dropdown",e)}return!1}};e.prototype.keydown=function(a){if(/(38|40|27|32)/.test(a.which)&&!/input|textarea/i.test(a.target.tagName)){var b=d(this);a.preventDefault();a.stopPropagation();if(!b.is(".disabled, :disabled")){var c=f(b),e=c.hasClass("open");if(!e&&27!=a.which||e&&27==a.which)return 27==a.which&&c.find('[data-toggle="dropdown"]').trigger("focus"),
b.trigger("click");b=c.find(".dropdown-menu li:not(.disabled):visible a");b.length&&(c=b.index(a.target),38==a.which&&0<c&&c--,40==a.which&&c<b.length-1&&c++,~c||(c=0),b.eq(c).trigger("focus"))}}};var h=d.fn.dropdown;d.fn.dropdown=function(a){return this.each(function(){var b=d(this),c=b.data("bs.dropdown");c||b.data("bs.dropdown",c=new e(this));"string"==typeof a&&c[a].call(b)})};d.fn.dropdown.Constructor=e;d.fn.dropdown.noConflict=function(){d.fn.dropdown=h;return this};d(document).on("click.bs.dropdown.data-api",
g).on("click.bs.dropdown.data-api",".dropdown form",function(a){a.stopPropagation()}).on("click.bs.dropdown.data-api",'[data-toggle="dropdown"]',e.prototype.toggle).on("keydown.bs.dropdown.data-api",'[data-toggle="dropdown"]',e.prototype.keydown).on("keydown.bs.dropdown.data-api",".dropdown-menu",e.prototype.keydown)}(jQuery);

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

(function($) {

var FLMBTN = {};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// FLMBTN >> Popup
//  NOTES >> Opens or closes the popup.
//**********************************************************
FLMBTN.Popup = function()
{
	var Height = $(window).height();
	
	if ( ! $("#FLMBTN-Wrapper").length )
	{
		var Wrapper = "<div id='FLMBTN-Wrapper'></div>";
		$("body").append(Wrapper);
		$("#FLMBTN-Wrapper").html($("#FLMBTN-Popup").html());
		
		$("body").addClass("modal-open");
		$("#FLMBTN-Popup-Window" ).css("height", Height - 40 + "px");
		$("#FLMBTN-Popup-Overlay").css("height", Height + "px").show();
		
		if ($(window).width() <= 500)
			$("#FLMBTN-Popup-Window").css("height", Height + "px");
			
		// Sections Resize
		var Height_Window  = $("#FLMBTN-Popup-Window").height();
		var Height_Top     = $("#FLMBTN-Top"         ).height();
		var Height_Preview = $("#FLMBTN-Preview"     ).height();
		var Height_Tabs    = $("#FLMBTN-Tabs"        ).height();
		var Height_Bottom  = $("#FLMBTN-Bottom"      ).height();

		var Height_Sections = Height_Window - Height_Top - Height_Preview;
			Height_Sections = Height_Sections - Height_Tabs - Height_Bottom;
			
		var Height_Icons = Height_Sections - 40 - 34 - 10;

		$("#FLMBTN-Sections"  ).css("height", Height_Sections   + "px");
		$("#FLMBTN-Icons"     ).css("height", Height_Icons      + "px");
		$("#FLMBTN-Icons-List").css("height", Height_Icons - 10 + "px");
		
		// Build Icons
		FLMBTN.Icons_Selected = null;
		try { FLMBTN.Icons_Display(); } catch(e){}
		
		// Color Picker
		if ( typeof jQuery.wp === "object" && typeof jQuery.wp.wpColorPicker === "function" )
		{
			var Color_Opts = {
				defaultColor: false,
				change: function(event, ui){ FLMBTN.Build() },
				clear: function() { FLMBTN.Build() },
				hide: true,
				palettes: true
			};
		
			$(".Color-Picker").wpColorPicker( Color_Opts );
		}
		
		$("#FLMBTN-Wrapper .wp-color-result").click(function(){ FLMBTN.Build() });
		
		$(document).on("keyup.FLMBTN_Button",function(e)
		{
			if (e.keyCode == 27 && $("#FLMBTN-Popup-Overlay").css("display") !== "none")
				FLMBTN.Popup();
		});
		
		// Resize Checks
		$(window).resize(function() {	
			var Height = $(window).height();
			$("#FLMBTN-Popup-Window").css("height", Height - 40 + "px");
			$("#FLMBTN-Popup-Overlay").css("height", Height + "px");

			if ($(window).width() <= 500)
				$("#FLMBTN-Popup-Window").css("height", Height + "px");

			// Sections Resize
			var Height_Window  = $("#FLMBTN-Popup-Window").height();
			var Height_Top     = $("#FLMBTN-Top"         ).height();
			var Height_Preview = $("#FLMBTN-Preview"     ).height();
			var Height_Tabs    = $("#FLMBTN-Tabs"        ).height();
			var Height_Bottom  = $("#FLMBTN-Bottom"      ).height();

			var Height_Sections = Height_Window - Height_Top - Height_Preview;
				Height_Sections = Height_Sections - Height_Tabs - Height_Bottom;

			var Height_Icons = Height_Sections - 40 - 34 - 10;

			$("#FLMBTN-Sections"  ).css("height", Height_Sections   + "px");
			$("#FLMBTN-Icons"     ).css("height", Height_Icons      + "px");
			$("#FLMBTN-Icons-List").css("height", Height_Icons - 10 + "px");
		});

		// Bind: Overlay Close
		//$("#FLMBTN-Popup-Overlay").click(function(){ FLMBTN.Popup() });
		$("#FLMBTN-Top-Close"    ).click(function(){ FLMBTN.Popup() });
		$("#FLMBTN-Popup-Window" ).click(function(event){ event.stopImmediatePropagation() });

		// Bind: Box Tabs
		jQuery("#FLMBTN-Tabs div").each(function(i)
		{
			var ID = $(this).prop("id").replace("FLMBTN-Tab-", '');
			$(this).click(function(){ FLMBTN.Section(ID) });
		});

		// Bind: Box Menus
		$(".FLMBTN-Button").dropdown();

		// Bind: Shortcut Codes
		$("#FLMBTN-Menu-Shortcuts ul li").each(function(){
			$(this).click(function(){ FLMBTN.Link_Shortcut($(this).prop("id")) });
		});

		// Bind: Fonts
		$("#FLMBTN-Menu-Fonts ul li").each(function(){
			$(this).click(function(){ FLMBTN.Button_Fonts($(this).prop("id")) });
		});

		// Regex Checks (A-Z, 0-9, -, _)
		$("#FLMBTN-OPT-Custom-ID"   ).keyup(function() { FLMBTN.Regex_Check( $(this) ) });
		$("#FLMBTN-OPT-Custom-Class").keyup(function() { FLMBTN.Regex_Check( $(this) ) });
		
		// Bind: Icon Search
		$("#FLMBTN-Search-Text" ).keyup(function(){ try { FLMBTN.Icons_Display() } catch(e){} });
		$("#FLMBTN-Search-Reset").click(function(){ try { FLMBTN.Icons_Reset()   } catch(e){} });
		$("#FLMBTN-Search-Icon" ).click(function(){ $("#FLMBTN-Search-Text").focus() });
		
		// Bind: Custom Colors
		$("#FLMBTN-OPT-Custom-Text-Toggle"  ).change(function(){ FLMBTN.Text_Color()       });
		$("#FLMBTN-OPT-Custom-BG-Toggle"    ).change(function(){ FLMBTN.Background_Color() });
		$("#FLMBTN-OPT-Custom-Border-Toggle").change(function(){ FLMBTN.Border_Color()     });

		// Bind: Custom Border Width
		$("#FLMBTN-OPT-Custom-BorderW-Toggle").change(function(){ FLMBTN.Border_Width() });
		
		// Bind: Reset Buttons
		$("#FLMBTN-Reset-All"    ).click(function(){ FLMBTN.Build_Reset("All")     });
		$("#FLMBTN-Reset-Details").click(function(){ FLMBTN.Build_Reset("Details") });
		$("#FLMBTN-Reset-Styles" ).click(function(){ FLMBTN.Build_Reset("Styles")  });
		$("#FLMBTN-Reset-Custom" ).click(function(){ FLMBTN.Build_Reset("Custom")  });
		$("#FLMBTN-Reset-Icons"  ).click(function(){ FLMBTN.Build_Reset("Icons")   });
		
		// Bind: Samples
		$("#FLMBTN-Sample-Add-to-Cart").click(function(){ FLMBTN.Build_Sample("Add-to-Cart") });
		$("#FLMBTN-Sample-Order-Now"  ).click(function(){ FLMBTN.Build_Sample("Order-Now")   });
		$("#FLMBTN-Sample-Read-More"  ).click(function(){ FLMBTN.Build_Sample("Read-More")   });
		$("#FLMBTN-Sample-Top"        ).click(function(){ FLMBTN.Build_Sample("Top")         });
		$("#FLMBTN-Sample-Previous"   ).click(function(){ FLMBTN.Build_Sample("Previous")    });
		$("#FLMBTN-Sample-Facebook"   ).click(function(){ FLMBTN.Build_Sample("Facebook")    });
		$("#FLMBTN-Sample-Tweet-This" ).click(function(){ FLMBTN.Build_Sample("Tweet-This")  });
		$("#FLMBTN-Sample-Google-Plus").click(function(){ FLMBTN.Build_Sample("Google-Plus") });
		$("#FLMBTN-Sample-GitHub"     ).click(function(){ FLMBTN.Build_Sample("GitHub")      });
		$("#FLMBTN-Sample-Play-Video" ).click(function(){ FLMBTN.Build_Sample("Play-Video")  });

		// Bind: Import Button
		$("#FLMBTN-Import-Button").click(function(){ FLMBTN.Import(); FLMBTN.Section("Details"); });
		
		// Bind: Fields
		$("#FLMBTN-OPT-Link-Address"       ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Link-Title"         ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-ID"          ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-Class"       ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Text"        ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Small"       ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Width"       ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Height"      ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Line-Height" ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Font-Family"        ).keyup(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Font-Size"          ).keyup(function(){ FLMBTN.Build() });
		
		$("#FLMBTN-OPT-Link-Target"        ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Link-Rel"           ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Icon-Placement"     ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Small-Placement"    ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Float"       ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Size"        ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Color"       ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Text-Color"         ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Style"       ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Style-Icon"  ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Style-3D"    ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Hover"       ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Button-Size"        ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-BG-Color"    ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-Text-Color"  ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-Border-Color").change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-BorderW"     ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-Border-Style").change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Animate-Icon"       ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Animate-Button"     ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Transitions"        ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Rounded-Corners"    ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Box-Shadow"         ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Text-Shadow"        ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Opacity"            ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Opacity-Hover"      ).change(function(){ FLMBTN.Build() });
		$("#FLMBTN-OPT-Custom-BorderW"     ).change(function(){ FLMBTN.Build() });
		
		$("#FLMBTN-Insert").click(function() {
			var Str = $("#FLMBTN-Code").html();
			tinyMCE.activeEditor.execCommand("mceInsertContent", 0, Str);
			FLMBTN.Popup();
		});
		
		// Reset Builder Fields
		FLMBTN.Build_Reset("All");
		
		var Selection = tinyMCE.activeEditor.selection.getContent();
		if (Selection !== '' && Selection !== undefined && Selection)
		{
			$("#FLMBTN-Import-Box").val(Selection);
			FLMBTN.Import();
		}
		
		FLMBTN.Box_Section = '';
		FLMBTN.Section("Details");
		$("FLMBTN-OPT-Link-Address").focus();
	}
	else
	{
		$("body").removeClass("modal-open");
		$("#FLMBTN-Wrapper").remove();
		$(document).unbind("keyup.FLMBTN_Button");
	}
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// PROTO >> String: Search
// PARAM >> String | A
// PARAM >> String | B
// NOTES >> Grab a section of string based on A/B.
//**********************************************************
String.prototype.Search = function(A, B)
{
	var Str = this.toString();
		Str = Str.substring(Str.indexOf(A) + A.length);
		Str = Str.substring(0, Str.indexOf(B));
	return Str;
};

//**********************************************************
// FLMBTN >> Regex Check
//  PARAM >> Object | Field
//  NOTES >> Restrict input based on alphanumeric chars.
//**********************************************************
FLMBTN.Regex_Check = function(Field)
{
	if (!Field) return;

	var Check = $(Field).val().replace(/[^a-zA-Z0-9-_\s]/g, "");

	if (/\s/.test(Check))
		Check = Check.replace(/\s/g, "");
	$(Field).val(Check);
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// FLMBTN >> Section
//  PARAM >> String | Section
//**********************************************************
FLMBTN.Section = function(Section)
{
	if (Section !== FLMBTN.Box_Section)
	{
		// Reset Tabs
		$("#FLMBTN-Tabs div").each(function() { $(this).removeClass("Active"); });

		// Reset Sections
		$("#FLMBTN-Sections section").each(function() { $(this).hide(); });

		// Set Active Tab / Section
		$("#FLMBTN-Tab-" + Section).addClass("Active");
		$("#FLMBTN-Section-" + Section).fadeIn();

		FLMBTN.Box_Section = Section;
	}
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// FLMBTN >> Link Shortcut
//  PARAM >> String | Shortcut
//**********************************************************
FLMBTN.Link_Shortcut = function(Shortcut)
{
	Shortcut = "{" + Shortcut.toUpperCase().replace("SHORTCUT-", '') + "}";
	var Value = $("#FLMBTN-OPT-Link-Address").val();
	$("#FLMBTN-OPT-Link-Address").val(Value + Shortcut);
	$("#FLMBTN-Button-Shortcuts").click();
	FLMBTN.Build();
};

//**********************************************************
// FLMBTN >> Button Fonts
//  PARAM >> String | ID
//**********************************************************
FLMBTN.Button_Fonts = function(ID)
{
	var Font = ID.replace("Font-", '');
		Font = "{CLASS-" + Font + "}";

	$("#FLMBTN-OPT-Font-Family").val(Font);
	$("#FLMBTN-Button-Fonts").click();
	FLMBTN.Build();
};

//**********************************************************
// FLMBTN >> Text Color
//**********************************************************
FLMBTN.Text_Color = function()
{	
	if ($("#FLMBTN-OPT-Custom-Text-Toggle").val() === "Enabled") $("#FLMBTN-Custom-Text-Color").show();
	else $("#FLMBTN-Custom-Text-Color").hide();
	FLMBTN.Build();
};

//**********************************************************
// FLMBTN >> Background Color
//**********************************************************
FLMBTN.Background_Color = function()
{	
	if ($("#FLMBTN-OPT-Custom-BG-Toggle").val() === "Enabled") $("#FLMBTN-Custom-BG-Color").show();
	else $("#FLMBTN-Custom-BG-Color").hide();
	FLMBTN.Build();
};

//**********************************************************
// FLMBTN >> Border Color
//**********************************************************
FLMBTN.Border_Color = function()
{	
	if ($("#FLMBTN-OPT-Custom-Border-Toggle").val() === "Enabled") $("#FLMBTN-Custom-Border-Color").show();
	else $("#FLMBTN-Custom-Border-Color").hide();
	FLMBTN.Build();
};

//**********************************************************
// FLMBTN >> Border Width
//**********************************************************
FLMBTN.Border_Width = function()
{	
	if ($("#FLMBTN-OPT-Custom-BorderW-Toggle").val() === "Enabled") $("#FLMBTN-Custom-Border-Width").show();
	else $("#FLMBTN-Custom-Border-Width").hide();
	FLMBTN.Build();
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// FLMBTN >> Icons: Display
//**********************************************************
FLMBTN.Icons_Display = function()
{
	var Search = $("#FLMBTN-Search-Text").val().toLowerCase();
	var Icons  = '';

	for (var i = 0, Len = ICONS.length; i < Len; i++)
	{
		if (Search === '' || ICONS[i].indexOf(Search) > -1)
		{
			Icons += "<div id='" + ICONS[i] + "' class='Button-Alt' title='" + ICONS[i] + "'>";
			Icons += "<i class='" + ICONS_TYPE + " " + ICONS[i] + "'></i></div>";
		}
	}

	$("#FLMBTN-Icons-List").html(Icons);
	FLMBTN.Icons_Select(FLMBTN.Icons_Selected);
	
	$("#FLMBTN-Icons-List div").each(function() {
		$(this).click(function() {
			FLMBTN.Icons_Select( $(this).prop("id") );
		});
	});

	if (Search !== '')
	{
		$("#FLMBTN-Search-Icon").hide();
		$("#FLMBTN-Search-Reset").show();
	}
	else
	{
		$("#FLMBTN-Search-Reset").hide();
		$("#FLMBTN-Search-Icon").show();
	}
};

//**********************************************************
// FLMBTN >> Icons: Reset
//**********************************************************
FLMBTN.Icons_Reset = function()
{
	$("#FLMBTN-Search-Text").val('');
	FLMBTN.Icons_Display();
};

//**********************************************************
// FLMBTN >> Icons: Select
//  PARAM >> String | ID
//**********************************************************
FLMBTN.Icons_Select = function(ID)
{
	$("#FLMBTN-Icons-List div").each(function() { $(this).removeClass("Selected"); });
	$("#FLMBTN-Icons-List #" + ID).addClass("Selected");
	FLMBTN.Icons_Selected = ID;
	FLMBTN.Build();
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// FLMBTN >> Build
//**********************************************************
FLMBTN.Build = function()
{
	var Str_Code = '';
	var Str_HTML = '';
	var Str_PHP  = ''; 
	var OPT = {
		Link_Address:          $("#FLMBTN-OPT-Link-Address"         ).val(),
		Link_Target:           $("#FLMBTN-OPT-Link-Target"          ).val(),
		Link_Title:            $("#FLMBTN-OPT-Link-Title"           ).val(),
		Link_Rel:              $("#FLMBTN-OPT-Link-Rel"             ).val(),
		Custom_ID:             $("#FLMBTN-OPT-Custom-ID"            ).val(),
		Custom_Class:          $("#FLMBTN-OPT-Custom-Class"         ).val(),
		Button_Text:           $("#FLMBTN-OPT-Button-Text"          ).val(),
		Button_Small:          $("#FLMBTN-OPT-Button-Small"         ).val(),
		Icon_Placement:        $("#FLMBTN-OPT-Icon-Placement"       ).val(),
		Small_Placement:       $("#FLMBTN-OPT-Small-Placement"      ).val(),
		Button_Float:          $("#FLMBTN-OPT-Button-Float"         ).val(),
		Button_Width:          $("#FLMBTN-OPT-Button-Width"         ).val(),
		Button_Height:         $("#FLMBTN-OPT-Button-Height"        ).val(),
		Button_Line_Height:    $("#FLMBTN-OPT-Button-Line-Height"   ).val(),
		Font_Family:           $("#FLMBTN-OPT-Font-Family"          ).val(),
		Font_Size:             $("#FLMBTN-OPT-Font-Size"            ).val(),
		Button_Size:           $("#FLMBTN-OPT-Button-Size"          ).val(),
		Button_Color:          $("#FLMBTN-OPT-Button-Color"         ).val(),
		Text_Color:            $("#FLMBTN-OPT-Text-Color"           ).val(),
		Button_Style:          $("#FLMBTN-OPT-Button-Style"         ).val(),
		Button_Style_Icon:     $("#FLMBTN-OPT-Button-Style-Icon"    ).val(),
		Button_Style_3D:       $("#FLMBTN-OPT-Button-Style-3D"      ).val(),
		Button_Hover:          $("#FLMBTN-OPT-Button-Hover"         ).val(),
		Rounded_Corners:       $("#FLMBTN-OPT-Rounded-Corners"      ).val(),
		Box_Shadow:            $("#FLMBTN-OPT-Box-Shadow"           ).val(),
		Text_Shadow:           $("#FLMBTN-OPT-Text-Shadow"          ).val(),
		Opacity:               $("#FLMBTN-OPT-Opacity"              ).val(),
		Opacity_Hover:         $("#FLMBTN-OPT-Opacity-Hover"        ).val(),
		Custom_BorderW:        $("#FLMBTN-OPT-Custom-BorderW"       ).val(),
		Custom_Text_Toggle:    $("#FLMBTN-OPT-Custom-Text-Toggle"   ).val(),
		Custom_Text_Color:     $("#FLMBTN-OPT-Custom-Text-Color"    ).val().replace("#", ''),
		Custom_BG_Toggle:      $("#FLMBTN-OPT-Custom-BG-Toggle"     ).val(),
		Custom_BG_Color:       $("#FLMBTN-OPT-Custom-BG-Color"      ).val().replace("#", ''),
		Custom_Border_Toggle:  $("#FLMBTN-OPT-Custom-Border-Toggle" ).val(),
		Custom_Border_Color:   $("#FLMBTN-OPT-Custom-Border-Color"  ).val().replace("#", ''),
		Custom_BorderW_Toggle: $("#FLMBTN-OPT-Custom-BorderW-Toggle").val(),
		Custom_BorderW:        $("#FLMBTN-OPT-Custom-BorderW"       ).val(),
		Custom_Border_Style:   $("#FLMBTN-OPT-Custom-Border-Style"  ).val(),
		Animate_Icon:          $("#FLMBTN-OPT-Animate-Icon"         ).val(),
		Animate_Button:        $("#FLMBTN-OPT-Animate-Button"       ).val(),
		Transitions:           $("#FLMBTN-OPT-Transitions"          ).val(),
		Icon: 			       FLMBTN.Icons_Selected
	};
	
	// Defaults
	if (OPT.Icon === undefined || ! OPT.Icon) OPT.Icon = '';
	
	// Setup Class
	var Prefix = "FLMBTN-";
	var Class  = Prefix + "Btn";
		Class += " " + Prefix + "Size-"  + OPT.Button_Size;
		Class += " " + Prefix + "Color-" + OPT.Button_Color;

	if (OPT.Rounded_Corners > 0) Class += " " + Prefix + "BR-" + OPT.Rounded_Corners;
	if (OPT.Box_Shadow      > 0) Class += " " + Prefix + "BS-" + OPT.Box_Shadow;
	if (OPT.Text_Shadow     > 0) Class += " " + Prefix + "TS-" + OPT.Text_Shadow;
	if (OPT.Opacity       < 100) Class += " " + Prefix + "OP-" + OPT.Opacity;
	if (OPT.Icon_Placement    === "Right") Class += " " + Prefix + "Icon-Right";
	if (OPT.Icon_Placement    === "Only")  Class += " " + Prefix + "Icon-Only";
	if (OPT.Small_Placement   === "Left")  Class += " " + Prefix + "Small-Left";
	if (OPT.Small_Placement   === "Right") Class += " " + Prefix + "Small-Right";
	if (OPT.Button_Style_Icon !== "None")  Class += " " + Prefix + OPT.Button_Style_Icon;
	if (OPT.Button_Style_3D   !== "None")  Class += " " + Prefix + OPT.Button_Style_3D;
	if (OPT.Button_Hover      !== "None")  Class += " " + Prefix + OPT.Button_Hover;
	if (OPT.Animate_Icon      !== "None")  Class += " " + Prefix + "AnIco-" + OPT.Animate_Icon;
	if (OPT.Animate_Button    !== "None")  Class += " " + Prefix + "Anim-" + OPT.Animate_Button;
	if (OPT.Transitions   !== "Disabled")  Class += " " + Prefix + "Trans";

	if (OPT.Custom_Border_Style !== "Default")
		Class += " " + Prefix + "BorderStyle-" + OPT.Custom_Border_Style;

	if (OPT.Opacity < 100 || OPT.Opacity_Hover < 100)
		Class += " " + Prefix + "OH-" + OPT.Opacity_Hover;

	if (OPT.Button_Style !== "Default")
	{
			 if (OPT.Button_Style === "Flat")    Class += " " + Prefix + "Flat-"    + OPT.Button_Color;
		else if (OPT.Button_Style === "Border")  Class += " " + Prefix + "Border-"  + OPT.Button_Color;
		else if (OPT.Button_Style === "Outline") Class += " " + Prefix + "Outline-" + OPT.Button_Color;
		else Class += " " + Prefix + OPT.Button_Style;
	}

	if (OPT.Text_Color !== "Default")
	{
		if (OPT.Text_Color !== "Engrave") Class += " " + Prefix + "Text-" + OPT.Text_Color;
		else Class += " " + Prefix + OPT.Text_Color;
	}

	if (OPT.Custom_Class !== '')
		Class += " " + OPT.Custom_Class;

	var Font_Class = '';
	if (OPT.Font_Family.indexOf("{") > -1)
	{
		Font_Class = OPT.Font_Family;
		Font_Class = Font_Class.replace("{CLASS-", '');
		Font_Class = Font_Class.replace("}", '');
		Font_Class = " " + Prefix + "Font-" + Font_Class;
		Class += Font_Class;
	}

	// No Icon or Small Text
	OPT.Text_Only = '';
	if (OPT.Icon_Placement === "None" && OPT.Small_Placement === "None")
	{
		OPT.Text_Only = "Yes";
		Class += " " + Prefix + "Text-Only";
	}
	
	// Build: Shortcode
	Str_Code  = '[flm_button';
	Str_Code += FLMBTN.Shortcode_Parameter("link_address",       OPT.Link_Address      );
	Str_Code += FLMBTN.Shortcode_Parameter("link_target",        OPT.Link_Target       );
	Str_Code += FLMBTN.Shortcode_Parameter("link_title",         OPT.Link_Title        );
	Str_Code += FLMBTN.Shortcode_Parameter("link_rel",           OPT.Link_Rel          );
	Str_Code += FLMBTN.Shortcode_Parameter("custom_id",          OPT.Custom_ID         );
	Str_Code += FLMBTN.Shortcode_Parameter("custom_class",       OPT.Custom_Class      );
	Str_Code += FLMBTN.Shortcode_Parameter("icon_placement",     OPT.Icon_Placement    );
	Str_Code += FLMBTN.Shortcode_Parameter("small_placement",    OPT.Small_Placement   );

	if (OPT.Icon_Placement !== "Only")
		Str_Code += FLMBTN.Shortcode_Parameter("button_text", OPT.Button_Text);

	if (OPT.Small_Placement !== "None")
		Str_Code += FLMBTN.Shortcode_Parameter("button_small", OPT.Button_Small);

	Str_Code += FLMBTN.Shortcode_Parameter("button_float",       OPT.Button_Float      );
	Str_Code += FLMBTN.Shortcode_Parameter("button_width",       OPT.Button_Width      );
	Str_Code += FLMBTN.Shortcode_Parameter("button_height",      OPT.Button_Height     );
	Str_Code += FLMBTN.Shortcode_Parameter("button_line_height", OPT.Button_Line_Height);
	Str_Code += FLMBTN.Shortcode_Parameter("font_family",        OPT.Font_Family       );
	Str_Code += FLMBTN.Shortcode_Parameter("font_size",          OPT.Font_Size         );
	Str_Code += FLMBTN.Shortcode_Parameter("button_size",        OPT.Button_Size       );
	Str_Code += FLMBTN.Shortcode_Parameter("button_color",       OPT.Button_Color      );
	Str_Code += FLMBTN.Shortcode_Parameter("text_color",         OPT.Text_Color        );
	Str_Code += FLMBTN.Shortcode_Parameter("button_style",       OPT.Button_Style      );
	Str_Code += FLMBTN.Shortcode_Parameter("button_style_icon",  OPT.Button_Style_Icon );
	Str_Code += FLMBTN.Shortcode_Parameter("button_style_3d",    OPT.Button_Style_3D   );
	Str_Code += FLMBTN.Shortcode_Parameter("button_hover",       OPT.Button_Hover      );
	Str_Code += FLMBTN.Shortcode_Parameter("rounded_corners",    OPT.Rounded_Corners   );
	Str_Code += FLMBTN.Shortcode_Parameter("box_shadow",         OPT.Box_Shadow        );
	Str_Code += FLMBTN.Shortcode_Parameter("text_shadow",        OPT.Text_Shadow       );
	Str_Code += FLMBTN.Shortcode_Parameter("opacity",            OPT.Opacity           );

	if (OPT.Opacity < 100 || OPT.Opacity_Hover < 100)
		Str_Code += FLMBTN.Shortcode_Parameter("opacity_hover", OPT.Opacity_Hover);

	if (OPT.Custom_Text_Toggle === "Enabled")
		Str_Code += FLMBTN.Shortcode_Parameter("custom_text_color", OPT.Custom_Text_Color );

	if (OPT.Custom_BG_Toggle === "Enabled")
		Str_Code += FLMBTN.Shortcode_Parameter("custom_bg_color", OPT.Custom_BG_Color);

	if (OPT.Custom_Border_Toggle === "Enabled")
		Str_Code += FLMBTN.Shortcode_Parameter("custom_border_color", OPT.Custom_Border_Color);

	if (OPT.Custom_BorderW_Toggle === "Enabled")
		Str_Code += FLMBTN.Shortcode_Parameter("custom_border_width", OPT.Custom_BorderW);

	Str_Code += FLMBTN.Shortcode_Parameter("custom_border_style", OPT.Custom_Border_Style);
	Str_Code += FLMBTN.Shortcode_Parameter("animate_icon",        OPT.Animate_Icon       );
	Str_Code += FLMBTN.Shortcode_Parameter("animate_button",      OPT.Animate_Button     );
	Str_Code += FLMBTN.Shortcode_Parameter("transitions",         OPT.Transitions        );
	Str_Code += FLMBTN.Shortcode_Parameter("text_only",           OPT.Text_Only          );

	if (OPT.Icon_Placement !== "None")
		Str_Code += FLMBTN.Shortcode_Parameter("icon", OPT.Icon);

	Str_Code += ']';

	// Build: PHP Function
	Str_PHP  = '<?php FLMBTN_Build( array(';
	Str_PHP += FLMBTN.PHP_Parameter("link_address",       OPT.Link_Address      );
	Str_PHP += FLMBTN.PHP_Parameter("link_target",        OPT.Link_Target       );
	Str_PHP += FLMBTN.PHP_Parameter("link_title",         OPT.Link_Title        );
	Str_PHP += FLMBTN.PHP_Parameter("link_rel",           OPT.Link_Rel          );
	Str_PHP += FLMBTN.PHP_Parameter("custom_id",          OPT.Custom_ID         );
	Str_PHP += FLMBTN.PHP_Parameter("custom_class",       OPT.Custom_Class      );
	Str_PHP += FLMBTN.PHP_Parameter("icon_placement",     OPT.Icon_Placement    );
	Str_PHP += FLMBTN.PHP_Parameter("small_placement",    OPT.Small_Placement   );

	if (OPT.Icon_Placement !== "Only")
		Str_PHP += FLMBTN.PHP_Parameter("button_text", OPT.Button_Text);

	if (OPT.Small_Placement !== "None")
		Str_PHP += FLMBTN.PHP_Parameter("button_small", OPT.Button_Small);

	Str_PHP += FLMBTN.PHP_Parameter("button_float",       OPT.Button_Float      );
	Str_PHP += FLMBTN.PHP_Parameter("button_width",       OPT.Button_Width      );
	Str_PHP += FLMBTN.PHP_Parameter("button_height",      OPT.Button_Height     );
	Str_PHP += FLMBTN.PHP_Parameter("button_line_height", OPT.Button_Line_Height);
	Str_PHP += FLMBTN.PHP_Parameter("font_family",        OPT.Font_Family       );
	Str_PHP += FLMBTN.PHP_Parameter("font_size",          OPT.Font_Size         );
	Str_PHP += FLMBTN.PHP_Parameter("button_size",        OPT.Button_Size       );
	Str_PHP += FLMBTN.PHP_Parameter("button_color",       OPT.Button_Color      );
	Str_PHP += FLMBTN.PHP_Parameter("text_color",         OPT.Text_Color        );
	Str_PHP += FLMBTN.PHP_Parameter("button_style",       OPT.Button_Style      );
	Str_PHP += FLMBTN.PHP_Parameter("button_style_icon",  OPT.Button_Style_Icon );
	Str_PHP += FLMBTN.PHP_Parameter("button_style_3d",    OPT.Button_Style_3D   );
	Str_PHP += FLMBTN.PHP_Parameter("button_hover",       OPT.Button_Hover      );
	Str_PHP += FLMBTN.PHP_Parameter("rounded_corners",    OPT.Rounded_Corners   );
	Str_PHP += FLMBTN.PHP_Parameter("box_shadow",         OPT.Box_Shadow        );
	Str_PHP += FLMBTN.PHP_Parameter("text_shadow",        OPT.Text_Shadow       );
	Str_PHP += FLMBTN.PHP_Parameter("opacity",            OPT.Opacity           );

	if (OPT.Opacity < 100 || OPT.Opacity_Hover < 100)
		Str_PHP += FLMBTN.PHP_Parameter("opacity_hover", OPT.Opacity_Hover );

	if (OPT.Custom_Text_Toggle === "Enabled")
		Str_PHP += FLMBTN.PHP_Parameter("custom_text_color", OPT.Custom_Text_Color );

	if (OPT.Custom_BG_Toggle === "Enabled")
		Str_PHP += FLMBTN.PHP_Parameter("custom_bg_color", OPT.Custom_BG_Color);

	if (OPT.Custom_Border_Toggle === "Enabled")
		Str_PHP += FLMBTN.PHP_Parameter("custom_border_color", OPT.Custom_Border_Color);

	if (OPT.Custom_BorderW_Toggle === "Enabled")
		Str_PHP += FLMBTN.PHP_Parameter("custom_border_width", OPT.Custom_BorderW);

	Str_PHP += FLMBTN.PHP_Parameter("custom_border_style", OPT.Custom_Border_Style);
	Str_PHP += FLMBTN.PHP_Parameter("animate_icon",        OPT.Animate_Icon       );
	Str_PHP += FLMBTN.PHP_Parameter("animate_button",      OPT.Animate_Button     );
	Str_PHP += FLMBTN.PHP_Parameter("transitions",         OPT.Transitions        );
	Str_PHP += FLMBTN.PHP_Parameter("text_only",           OPT.Text_Only          );

	if (OPT.Icon_Placement !== "None")
		Str_PHP += FLMBTN.PHP_Parameter("icon", OPT.Icon);

	if (Str_PHP.charAt(Str_PHP.length - 1) === ",")
		Str_PHP = Str_PHP.slice(0, -1);
	Str_PHP += ' ) ); ?>';

	// Build: HTML Code
	Str_HTML = '<a ';

	Str_HTML += 'href="#"';

	if (OPT.Link_Target !== '')
		Str_HTML += ' target="' + OPT.Link_Target + '"';

	if (OPT.Link_Rel !== '')
		Str_HTML += ' rel="' + OPT.Link_Rel + '"';

	if (OPT.Link_Title !== '')
		Str_HTML += ' title="' + OPT.Link_Title.replace(/"/g, '&#34;') + '"';

	// Set Class
	Str_HTML += ' class="' + Class + '"';

	// Custom Styles
	var Styles = '';

	// Custom Text Color
	if (OPT.Custom_Text_Toggle === "Enabled" && OPT.Custom_Text_Color !== '')
		Styles += 'color:#' + OPT.Custom_Text_Color + ';';

	// Custom Background Color
	if (OPT.Custom_BG_Toggle === "Enabled" && OPT.Custom_BG_Color !== '')
		Styles += 'background:#' + OPT.Custom_BG_Color + ';';

	// Custom Border Color
	if (OPT.Custom_Border_Toggle === "Enabled" && OPT.Custom_Border_Color !== '')
		Styles += 'border-color:#' + OPT.Custom_Border_Color + ';';

	// Custom Border Width
	if (OPT.Custom_BorderW_Toggle === "Enabled" && OPT.Custom_BorderW !== '')
		Styles += 'border-width:' + OPT.Custom_BorderW + 'px;';

	// Button Float
	if (OPT.Button_Float !== "None")
		Styles += 'float:' + OPT.Button_Float.toLowerCase() + ';';

	// Custom Font
	if (OPT.Font_Family !== '' && OPT.Font_Family.indexOf("{") <= -1)
		Styles += 'font-family:' + OPT.Font_Family.replace(/"/g, '') + ';';

	// Font Size
	if (OPT.Font_Size !== '')
		Styles += 'font-size:' + OPT.Font_Size + ';';

	// Button Width
	if (OPT.Button_Width !== '')
		Styles += 'width:' + OPT.Button_Width + ';';

	// Button Height
	if (OPT.Button_Height !== '')
		Styles += 'height:' + OPT.Button_Height + ';';

	// Button Line Height
	if (OPT.Button_Line_Height !== '')
		Styles += 'line-height:' + OPT.Button_Line_Height + ';';

	// Append Styles
	if (Styles !== '') Str_HTML += ' style="' + Styles + '"';

	// Append Custom ID
	if (OPT.Custom_ID !== '')
		Str_HTML += ' id="' + OPT.Custom_ID + '"';

	Str_HTML += '>';

	// Set Inner
	var Button_Text = OPT.Button_Text;
	if (Button_Text === '') Button_Text = "Button";

	if (Button_Text      !== '') Button_Text      = '<span>'  + Button_Text  + '</span>';
	if (OPT.Button_Small !== '') OPT.Button_Small = '<small>' + OPT.Button_Small + '</small>';
	if (OPT.Icon         !== '')
	{
		OPT.Icon = '<b><i class="' + ICONS_TYPE +' ' + OPT.Icon + '"';

		if (OPT.Button_Line_Height !== '' || OPT.Font_Size !== '')
		{
			OPT.Icon += 'style="';

			if (OPT.Button_Line_Height !== '')
				OPT.Icon += 'line-height:' + OPT.Button_Line_Height + ';';

			if (OPT.Font_Size !== '')
				OPT.Icon += 'font-size:' + OPT.Font_Size + ';';

			OPT.Icon += '"';
		}

		OPT.Icon += '></i></b>';
	}

	if (OPT.Icon_Placement === "Only") Str_HTML += OPT.Icon;
	else
	{
		if (OPT.Icon_Placement  === "Left") Str_HTML += OPT.Icon;
		if (OPT.Small_Placement === "Left") Str_HTML += OPT.Button_Small;

		Str_HTML += Button_Text;

		if (OPT.Small_Placement === "Right") Str_HTML += OPT.Button_Small;
		if (OPT.Icon_Placement  === "Right") Str_HTML += OPT.Icon;
	}

	Str_HTML += '</a>';
	
	// Preview
	$("#FLMBTN-Code").html(Str_Code);
	$("#FLMBTN-Preview-Inner").html(Str_HTML);
	
	$("#FLMBTN-Preview-Inner a").click(function(e){ e.preventDefault() });
};

//**********************************************************
// FLMBTN >> Shortcode Paramter
//  PARAM >> String | Name
//  PARAM >> String | Value
//  NOTES >> Sanatizes string and returns prepared param.
//**********************************************************
FLMBTN.Shortcode_Parameter = function(Name, Value)
{
	if (Name === '' || Value === '' || Value === undefined || ! Value) return '';

	if (Name === "opacity")
	{
		if (Value === "100") return '';
	}
	else if (Name === "custom_border_style")
	{
		if (Value === "Default") return '';
	}
	else if (Name === "custom_border_width"){}
	else
	{	
		if (Value === "None"    ) return '';
		if (Value === "Default" ) return '';
		if (Value === "0"       ) return '';
		if (Value === "Disabled") return '';
	}

	Value = Value.replace(/"/g, '&#34;');

	return ' ' + Name + '="' + Value + '"';
}

//**********************************************************
// FLMBTN >> PHP Paramter
//  PARAM >> String | Name
//  PARAM >> String | Value
//  NOTES >> Sanatizes string and returns prepared param.
//**********************************************************
FLMBTN.PHP_Parameter = function(Name, Value)
{
	if (Name === '' || Value === '' || Value === undefined || ! Value) return '';

	if (Name === "opacity")
	{
		if (Value === "100") return '';
	}
	else if (Name === "custom_border_style")
	{
		if (Value === "Default") return '';
	}
	else if (Name === "custom_border_width"){}
	else
	{	
		if (Value === "None"    ) return '';
		if (Value === "Default" ) return '';
		if (Value === "0"       ) return '';
		if (Value === "Disabled") return '';
	}

	Value = Value.replace(/"/g, '&#34;');

	return ' "' + Name + '"=>"' + Value + '",';
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// FLMBTN >> Build: Reset
//  PARAM >> String | Type
//**********************************************************
FLMBTN.Build_Reset = function(Type)
{
	if (Type === "All")
	{
		Reset_Details();
		Reset_Styles();
		Reset_Custom();
		Reset_Icons();
	}
	else if (Type === "Details") Reset_Details();
	else if (Type === "Styles")  Reset_Styles();
	else if (Type === "Custom")  Reset_Custom();
	else if (Type === "Icons")   Reset_Icons();

	function Reset_Details()
	{
		$("#FLMBTN-OPT-Link-Address").val('');
		$("#FLMBTN-OPT-Link-Target" ).val('');
		$("#FLMBTN-OPT-Link-Title"  ).val('');
		$("#FLMBTN-OPT-Link-Rel"    ).val('');
		$("#FLMBTN-OPT-Custom-ID"   ).val('');
		$("#FLMBTN-OPT-Custom-Class").val('');
		$("#FLMBTN-OPT-Button-Text" ).val('');
		$("#FLMBTN-OPT-Button-Small").val('');
	}

	function Reset_Styles()
	{
		$("#FLMBTN-OPT-Button-Size"      ).val("XS");
		$("#FLMBTN-OPT-Button-Color"     ).val("Light");
		$("#FLMBTN-OPT-Text-Color"       ).val("Default");
		$("#FLMBTN-OPT-Button-Style"     ).val("Default");
		$("#FLMBTN-OPT-Button-Style-Icon").val("None");
		$("#FLMBTN-OPT-Button-Style-3D"  ).val("None");
		$("#FLMBTN-OPT-Button-Hover"     ).val("None");
		$("#FLMBTN-OPT-Animate-Icon"     ).val("None");
		$("#FLMBTN-OPT-Animate-Button"   ).val("None");
		$("#FLMBTN-OPT-Transitions"      ).val("Disabled");
		
		$("#FLMBTN-OPT-Rounded-Corners"  ).val("3");
		$("#FLMBTN-OPT-Box-Shadow"       ).val("0");
		$("#FLMBTN-OPT-Text-Shadow"      ).val("0");
		$("#FLMBTN-OPT-Opacity"          ).val("100");
		$("#FLMBTN-OPT-Opacity-Hover"    ).val("100");
	}

	function Reset_Custom()
	{
		$("#FLMBTN-OPT-Font-Family"        ).val('');
		$("#FLMBTN-OPT-Font-Size"          ).val('');
		$("#FLMBTN-OPT-Icon-Placement"     ).val("Left");
		$("#FLMBTN-OPT-Small-Placement"    ).val("None");
		$("#FLMBTN-OPT-Button-Float"       ).val("None");
		$("#FLMBTN-OPT-Button-Width"       ).val('');
		$("#FLMBTN-OPT-Button-Height"      ).val('');
		$("#FLMBTN-OPT-Button-Line-Height" ).val('');
		$("#FLMBTN-OPT-Custom-Border-Style").val("Default");

		$("#FLMBTN-OPT-Custom-Text-Toggle").val("Disabled");
		$("#FLMBTN-OPT-Custom-Text-Color" ).val('');
		FLMBTN.Text_Color();

		$("#FLMBTN-OPT-Custom-BG-Toggle").val("Disabled");
		$("#FLMBTN-OPT-Custom-BG-Color" ).val('');
		FLMBTN.Background_Color();

		$("#FLMBTN-OPT-Custom-Border-Toggle").val("Disabled");
		$("#FLMBTN-OPT-Custom-Border-Color" ).val('');
		FLMBTN.Border_Color();

		$("#FLMBTN-OPT-Custom-BorderW-Toggle").val("Disabled");
		$("#FLMBTN-OPT-Custom-BorderW"    ).val("1");
		FLMBTN.Border_Width();
	}

	function Reset_Icons()
	{
		FLMBTN.Icons_Selected = undefined;
		FLMBTN.Icons_Reset();
	}

	FLMBTN.Build();
};

//**********************************************************
// FLMBTN >> Build: Sample
//  PARAM >> String | Type
//**********************************************************
FLMBTN.Build_Sample = function(Type)
{
	FLMBTN.Build_Reset("All");
	var Str = '';

	if (Type === "Add-to-Cart")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-MD FLMBTN-Color-Green FLMBTN-BR-5 FLMBTN-Icon-Right FLMBTN-Lines-Right FLMBTN-D3">';
		Str += '<span>Add to Cart</span><i class="fa fa-shopping-cart"></i></a>';
	}
	else if (Type === "Facebook")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-SM FLMBTN-Color-Blue FLMBTN-BR-3 FLMBTN-BS-3 FLMBTN-Mask-Left FLMBTN-Anim-Grow FLMBTN-Flat-Blue">';
		Str += '<i class="fa fa-facebook"></i><span>Facebook</span></a>';
	}
	else if (Type === "Tweet-This")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-XS FLMBTN-Color-Light FLMBTN-BR-3 FLMBTN-Hover-Blue FLMBTN-AnIco-Rotate-360 FLMBTN-Flat-Light FLMBTN-Text-Blue">';
		Str += '<i class="fa fa-twitter"></i><span>Tweet This!</span></a>';
	}
	else if (Type === "Read-More")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-MD FLMBTN-Color-Dark FLMBTN-BR-3 FLMBTN-BS-4 FLMBTN-Icon-Right FLMBTN-Small-Left FLMBTN-Mask-Right" style="color:#fffe00;">';
		Str += '<small>Next</small><span>Read More</span><i class="fa fa-arrow-right"></i></a>';
	}
	else if (Type === "Google-Plus")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-XS FLMBTN-Color-Red FLMBTN-BR-3 FLMBTN-Lines-Left FLMBTN-HoverB-Red FLMBTN-Engrave">';
		Str += '<i class="fa fa-google-plus-square"></i><span>Google+</span></a>';
	}
	else if (Type === "Order-Now")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-LG FLMBTN-Color-Orange FLMBTN-BR-25 FLMBTN-Icon-Right FLMBTN-Hover-Orange">';
		Str += '<span>Order Now</span><i class="fa fa-chevron-right"></i></a>';
	}
	else if (Type === "GitHub")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-SM FLMBTN-Color-Light FLMBTN-BR-3 FLMBTN-Hover-Dark FLMBTN-Outline-Light">';
		Str += '<i class="fa fa-github-square"></i><span>Fork on GitHub</span></a>';
	}
	else if (Type === "Top")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-XS FLMBTN-Color-Light FLMBTN-BR-25 FLMBTN-Icon-Only FLMBTN-Hover-Light FLMBTN-Flat-Light">';
		Str += '<i class="fa fa-arrow-circle-up"></i></a>';
	}
	else if (Type === "Play-Video")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-MD FLMBTN-Color-Tan FLMBTN-BR-3 FLMBTN-Icon-Right FLMBTN-Lines-Right FLMBTN-D3 FLMBTN-Engrave">';
		Str += '<span>Play Video</span><i class="fa fa-youtube-play"></i></a>';
	}
	else if (Type === "Previous")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-LG FLMBTN-Color-Purple FLMBTN-BR-10 FLMBTN-TS-5 FLMBTN-Icon-Only FLMBTN-HoverB-Purple FLMBTN-Flat-Purple">';
		Str += '<i class="fa fa-chevron-left"></i></a>';
	}

	$("#FLMBTN-Import-Box").val(Str);
	FLMBTN.Import();	
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//*************************************************************
// FLMBTN >> Import
//*************************************************************
FLMBTN.Import = function()
{
	// Check For Blank
	if ($("#FLMBTN-Import-Box").val() == '')
	{
		$("#FLMBTN-Import-Box").focus();
		return;
	}

	// Reset
	FLMBTN.Build_Reset("All");

	// Get Input
	var Input = $("#FLMBTN-Import-Box").val();

	// Check Input
	if (Input.indexOf("<a href=") > -1)
		FLMBTN.Import_HTML(Input);
	else if (Input.indexOf("[flm_button") > -1)
		FLMBTN.Import_Shortcode(Input);
	else if (Input.indexOf("<?php FLMBTN_Build(") > -1)
		FLMBTN.Import_PHP(Input);

	$("#FLMBTN-Import-Box").val('');
	FLMBTN.Build();
};

//*************************************************************
// FLMBTN >> Import: HTML
//  PARAM >> String | Input
//*************************************************************
FLMBTN.Import_HTML = function(Input)
{
	var Prefix = "FLMBTN-";
	var Check  = false;
	var Temp   = '';
	var OPT    = {};

	// Create Workspace
	$("#FLMBTN-Import-Space").html(Input);

	// General Element Calls
	OPT.Classes = String($("#FLMBTN-Import-Space a").prop("class"));
	OPT.Styles  = $("#FLMBTN-Import-Space a").prop("style");

	// Details - Link Address
	OPT.Link_Address = Input.Search('href="', '"');
	$("#FLMBTN-OPT-Link-Address").val(OPT.Link_Address);

	// Details - Link Target
	OPT.Link_Target = String($("#FLMBTN-Import-Space a").prop("target"));
	$("#FLMBTN-OPT-Link-Target").val(OPT.Link_Target);

	// Details - Link Title
	OPT.Link_Title = String($("#FLMBTN-Import-Space a").prop("title"));
	$("#FLMBTN-OPT-Link-Title").val(OPT.Link_Title);

	// Details - Link Rel
	OPT.Link_Rel = String($("#FLMBTN-Import-Space a").prop("rel"));
	$("#FLMBTN-OPT-Link-Rel").val(OPT.Link_Rel);

	// Details - Custom ID
	OPT.Custom_ID = String($("#FLMBTN-Import-Space a").prop("id"));
	$("#FLMBTN-OPT-Custom-ID").val(OPT.Custom_ID);

	// Details - Custom Class
	Temp = OPT.Classes.split(" ");
	for (var i = 0; i < Temp.length; i++)
	{
		if (Temp[i].indexOf(Prefix) <= -1)
		{
			OPT.Custom_Class = Temp[i];
			break;
		}
	}
	if (OPT.Custom_Class !== '')
		$("#FLMBTN-OPT-Custom-Class").val(OPT.Custom_Class);

	// Details - Button Text
	if (Input.indexOf("<span>") > -1) $("#FLMBTN-OPT-Button-Text").val($("#FLMBTN-Import-Space span").html());

	// Details - Small Text
	if (Input.indexOf("<small>") > -1) $("#FLMBTN-OPT-Button-Small").val($("#FLMBTN-Import-Space small").html());

	// Styles - Button Size
		 if (OPT.Classes.indexOf(Prefix + "Size-XS") > -1) $("#FLMBTN-OPT-Button-Size").val("XS");
	else if (OPT.Classes.indexOf(Prefix + "Size-SM") > -1) $("#FLMBTN-OPT-Button-Size").val("SM");
	else if (OPT.Classes.indexOf(Prefix + "Size-MD") > -1) $("#FLMBTN-OPT-Button-Size").val("MD");
	else if (OPT.Classes.indexOf(Prefix + "Size-LG") > -1) $("#FLMBTN-OPT-Button-Size").val("LG");

	// Styles - Button Color
		 if (OPT.Classes.indexOf("Color-Light")  > -1) OPT.Button_Color = "Light";
	else if (OPT.Classes.indexOf("Color-Tan")    > -1) OPT.Button_Color = "Tan";
	else if (OPT.Classes.indexOf("Color-Dark")   > -1) OPT.Button_Color = "Dark";
	else if (OPT.Classes.indexOf("Color-Blue")   > -1) OPT.Button_Color = "Blue";
	else if (OPT.Classes.indexOf("Color-Green")  > -1) OPT.Button_Color = "Green";
	else if (OPT.Classes.indexOf("Color-Red")    > -1) OPT.Button_Color = "Red";
	else if (OPT.Classes.indexOf("Color-Orange") > -1) OPT.Button_Color = "Orange";
	else if (OPT.Classes.indexOf("Color-Yellow") > -1) OPT.Button_Color = "Yellow";
	else if (OPT.Classes.indexOf("Color-Pink")   > -1) OPT.Button_Color = "Pink";
	else if (OPT.Classes.indexOf("Color-Purple") > -1) OPT.Button_Color = "Purple";
	else if (OPT.Classes.indexOf("Color-Black")  > -1) OPT.Button_Color = "Black";
	else if (OPT.Classes.indexOf("Color-White")  > -1) OPT.Button_Color = "White";

	$("#FLMBTN-OPT-Button-Color").val(OPT.Button_Color);

	// Styles - Text Color
		 if (OPT.Classes.indexOf(Prefix + "Engrave")     > -1) OPT.Text_Color = "Engrave";
	else if (OPT.Classes.indexOf(Prefix + "Text-Light")  > -1) OPT.Text_Color = "Light";
	else if (OPT.Classes.indexOf(Prefix + "Text-Tan")    > -1) OPT.Text_Color = "Tan";
	else if (OPT.Classes.indexOf(Prefix + "Text-Dark")   > -1) OPT.Text_Color = "Dark";
	else if (OPT.Classes.indexOf(Prefix + "Text-Blue")   > -1) OPT.Text_Color = "Blue";
	else if (OPT.Classes.indexOf(Prefix + "Text-Green")  > -1) OPT.Text_Color = "Green";
	else if (OPT.Classes.indexOf(Prefix + "Text-Red")    > -1) OPT.Text_Color = "Red";
	else if (OPT.Classes.indexOf(Prefix + "Text-Orange") > -1) OPT.Text_Color = "Orange";
	else if (OPT.Classes.indexOf(Prefix + "Text-Yellow") > -1) OPT.Text_Color = "Yellow";
	else if (OPT.Classes.indexOf(Prefix + "Text-Pink")   > -1) OPT.Text_Color = "Pink";
	else if (OPT.Classes.indexOf(Prefix + "Text-Purple") > -1) OPT.Text_Color = "Purple";
	else if (OPT.Classes.indexOf(Prefix + "Text-Black")  > -1) OPT.Text_Color = "Black";
	else if (OPT.Classes.indexOf(Prefix + "Text-White")  > -1) OPT.Text_Color = "White";
	else OPT.Text_Color = "Default";

	$("#FLMBTN-OPT-Text-Color").val(OPT.Text_Color);

	// Styles - Button Style
		 if (OPT.Classes.indexOf(Prefix + "Flat-")    > -1) OPT.Button_Style = "Flat";
	else if (OPT.Classes.indexOf(Prefix + "Border-")  > -1) OPT.Button_Style = "Border";
	else if (OPT.Classes.indexOf(Prefix + "Outline-") > -1) OPT.Button_Style = "Outline";
	else OPT.Button_Style = "Default";

	$("#FLMBTN-OPT-Button-Style").val(OPT.Button_Style);

	// Styles - Button Style Icon
		 if (OPT.Classes.indexOf(Prefix + "Lines-Left")  > -1) OPT.Button_Style_Icon = "Lines-Left";
	else if (OPT.Classes.indexOf(Prefix + "Lines-Right") > -1) OPT.Button_Style_Icon = "Lines-Right";
	else if (OPT.Classes.indexOf(Prefix + "Mask-Left")   > -1) OPT.Button_Style_Icon = "Mask-Left";
	else if (OPT.Classes.indexOf(Prefix + "Mask-Right")  > -1) OPT.Button_Style_Icon = "Mask-Right";
	else OPT.Button_Style_Icon = "None";

	$("#FLMBTN-OPT-Button-Style-Icon").val(OPT.Button_Style_Icon);

	// Styles - Button Style 3D
		 if (OPT.Classes.indexOf(Prefix + "D3-Large") > -1) OPT.Button_Style_3D = "D3-Large";
	else if (OPT.Classes.indexOf(Prefix + "D3")       > -1) OPT.Button_Style_3D = "D3";
	else OPT.Button_Style_3D = "None";

	$("#FLMBTN-OPT-Button-Style-3D").val(OPT.Button_Style_3D);

	// Styles - Button Hover
		 if (OPT.Classes.indexOf(Prefix + "Hover-Light")   > -1) OPT.Button_Hover = "Hover-Light";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Tan")     > -1) OPT.Button_Hover = "Hover-Tan";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Dark")    > -1) OPT.Button_Hover = "Hover-Dark";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Blue")    > -1) OPT.Button_Hover = "Hover-Blue";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Green")   > -1) OPT.Button_Hover = "Hover-Green";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Red")     > -1) OPT.Button_Hover = "Hover-Red";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Orange")  > -1) OPT.Button_Hover = "Hover-Orange";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Yellow")  > -1) OPT.Button_Hover = "Hover-Yellow";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Pink")    > -1) OPT.Button_Hover = "Hover-Pink";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Purple")  > -1) OPT.Button_Hover = "Hover-Purple";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Black")   > -1) OPT.Button_Hover = "Hover-Black";
	else if (OPT.Classes.indexOf(Prefix + "Hover-White")   > -1) OPT.Button_Hover = "Hover-White";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Light")  > -1) OPT.Button_Hover = "HoverB-Light";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Tan")    > -1) OPT.Button_Hover = "HoverB-Tan";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Dark")   > -1) OPT.Button_Hover = "HoverB-Dark";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Blue")   > -1) OPT.Button_Hover = "HoverB-Blue";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Green")  > -1) OPT.Button_Hover = "HoverB-Green";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Red")    > -1) OPT.Button_Hover = "HoverB-Red";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Orange") > -1) OPT.Button_Hover = "HoverB-Orange";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Yellow") > -1) OPT.Button_Hover = "HoverB-Yellow";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Pink")   > -1) OPT.Button_Hover = "HoverB-Pink";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Purple") > -1) OPT.Button_Hover = "HoverB-Purple";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Black")  > -1) OPT.Button_Hover = "HoverB-Black";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-White")  > -1) OPT.Button_Hover = "HoverB-White";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Light")  > -1) OPT.Button_Hover = "HoverF-Light";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Tan")    > -1) OPT.Button_Hover = "HoverF-Tan";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Dark")   > -1) OPT.Button_Hover = "HoverF-Dark";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Blue")   > -1) OPT.Button_Hover = "HoverF-Blue";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Green")  > -1) OPT.Button_Hover = "HoverF-Green";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Red")    > -1) OPT.Button_Hover = "HoverF-Red";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Orange") > -1) OPT.Button_Hover = "HoverF-Orange";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Yellow") > -1) OPT.Button_Hover = "HoverF-Yellow";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Pink")   > -1) OPT.Button_Hover = "HoverF-Pink";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Purple") > -1) OPT.Button_Hover = "HoverF-Purple";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Black")  > -1) OPT.Button_Hover = "HoverF-Black";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-White")  > -1) OPT.Button_Hover = "HoverF-White";
	else OPT.Button_Hover = "None";

	$("#FLMBTN-OPT-Button-Hover").val(OPT.Button_Hover);

	// Styles - Rounded Corners
			 OPT.Rounded_Corners = 0;
		 if (OPT.Classes.indexOf(Prefix + "BR-25") > -1) OPT.Rounded_Corners = 25;
	else if (OPT.Classes.indexOf(Prefix + "BR-24") > -1) OPT.Rounded_Corners = 24;
	else if (OPT.Classes.indexOf(Prefix + "BR-23") > -1) OPT.Rounded_Corners = 23;
	else if (OPT.Classes.indexOf(Prefix + "BR-22") > -1) OPT.Rounded_Corners = 22;
	else if (OPT.Classes.indexOf(Prefix + "BR-21") > -1) OPT.Rounded_Corners = 21;
	else if (OPT.Classes.indexOf(Prefix + "BR-20") > -1) OPT.Rounded_Corners = 20;
	else if (OPT.Classes.indexOf(Prefix + "BR-19") > -1) OPT.Rounded_Corners = 19;
	else if (OPT.Classes.indexOf(Prefix + "BR-18") > -1) OPT.Rounded_Corners = 18;
	else if (OPT.Classes.indexOf(Prefix + "BR-17") > -1) OPT.Rounded_Corners = 17;
	else if (OPT.Classes.indexOf(Prefix + "BR-16") > -1) OPT.Rounded_Corners = 16;
	else if (OPT.Classes.indexOf(Prefix + "BR-15") > -1) OPT.Rounded_Corners = 15;
	else if (OPT.Classes.indexOf(Prefix + "BR-14") > -1) OPT.Rounded_Corners = 14;
	else if (OPT.Classes.indexOf(Prefix + "BR-13") > -1) OPT.Rounded_Corners = 13;
	else if (OPT.Classes.indexOf(Prefix + "BR-12") > -1) OPT.Rounded_Corners = 12;
	else if (OPT.Classes.indexOf(Prefix + "BR-11") > -1) OPT.Rounded_Corners = 11;
	else if (OPT.Classes.indexOf(Prefix + "BR-10") > -1) OPT.Rounded_Corners = 10;
	else if (OPT.Classes.indexOf(Prefix + "BR-9")  > -1) OPT.Rounded_Corners = 9;
	else if (OPT.Classes.indexOf(Prefix + "BR-8")  > -1) OPT.Rounded_Corners = 8;
	else if (OPT.Classes.indexOf(Prefix + "BR-7")  > -1) OPT.Rounded_Corners = 7;
	else if (OPT.Classes.indexOf(Prefix + "BR-6")  > -1) OPT.Rounded_Corners = 6;
	else if (OPT.Classes.indexOf(Prefix + "BR-5")  > -1) OPT.Rounded_Corners = 5;
	else if (OPT.Classes.indexOf(Prefix + "BR-4")  > -1) OPT.Rounded_Corners = 4;
	else if (OPT.Classes.indexOf(Prefix + "BR-3")  > -1) OPT.Rounded_Corners = 3;
	else if (OPT.Classes.indexOf(Prefix + "BR-2")  > -1) OPT.Rounded_Corners = 2;
	else if (OPT.Classes.indexOf(Prefix + "BR-1")  > -1) OPT.Rounded_Corners = 1;

	$("#FLMBTN-OPT-Rounded-Corners").val(OPT.Rounded_Corners);

	// Styles - Box Shadow
			 OPT.Box_Shadow = 0;
		 if (OPT.Classes.indexOf(Prefix + "BS-10") > -1) OPT.Box_Shadow = 10;
	else if (OPT.Classes.indexOf(Prefix + "BS-9")  > -1) OPT.Box_Shadow = 9;
	else if (OPT.Classes.indexOf(Prefix + "BS-8")  > -1) OPT.Box_Shadow = 8;
	else if (OPT.Classes.indexOf(Prefix + "BS-7")  > -1) OPT.Box_Shadow = 7;
	else if (OPT.Classes.indexOf(Prefix + "BS-6")  > -1) OPT.Box_Shadow = 6;
	else if (OPT.Classes.indexOf(Prefix + "BS-5")  > -1) OPT.Box_Shadow = 5;
	else if (OPT.Classes.indexOf(Prefix + "BS-4")  > -1) OPT.Box_Shadow = 4;
	else if (OPT.Classes.indexOf(Prefix + "BS-3")  > -1) OPT.Box_Shadow = 3;
	else if (OPT.Classes.indexOf(Prefix + "BS-2")  > -1) OPT.Box_Shadow = 2;
	else if (OPT.Classes.indexOf(Prefix + "BS-1")  > -1) OPT.Box_Shadow = 1;

	$("#FLMBTN-OPT-Box-Shadow").val(OPT.Box_Shadow);

	// Styles - Text Shadow
				 OPT.Text_Shadow = 0;
		 if (OPT.Classes.indexOf(Prefix + "TS-10") > -1) OPT.Text_Shadow = 10;
	else if (OPT.Classes.indexOf(Prefix + "TS-9")  > -1) OPT.Text_Shadow = 9;
	else if (OPT.Classes.indexOf(Prefix + "TS-8")  > -1) OPT.Text_Shadow = 8;
	else if (OPT.Classes.indexOf(Prefix + "TS-7")  > -1) OPT.Text_Shadow = 7;
	else if (OPT.Classes.indexOf(Prefix + "TS-6")  > -1) OPT.Text_Shadow = 6;
	else if (OPT.Classes.indexOf(Prefix + "TS-5")  > -1) OPT.Text_Shadow = 5;
	else if (OPT.Classes.indexOf(Prefix + "TS-4")  > -1) OPT.Text_Shadow = 4;
	else if (OPT.Classes.indexOf(Prefix + "TS-3")  > -1) OPT.Text_Shadow = 3;
	else if (OPT.Classes.indexOf(Prefix + "TS-2")  > -1) OPT.Text_Shadow = 2;
	else if (OPT.Classes.indexOf(Prefix + "TS-1")  > -1) OPT.Text_Shadow = 1;

	$("#FLMBTN-OPT-Text-Shadow").val(OPT.Text_Shadow);

	// Styles - Opacity
	OPT.Opacity = 100;

		 if (OPT.Classes.indexOf(Prefix + "OP-90") > -1) OPT.Opacity = 90;
	else if (OPT.Classes.indexOf(Prefix + "OP-80") > -1) OPT.Opacity = 80;
	else if (OPT.Classes.indexOf(Prefix + "OP-70") > -1) OPT.Opacity = 70;
	else if (OPT.Classes.indexOf(Prefix + "OP-60") > -1) OPT.Opacity = 60;
	else if (OPT.Classes.indexOf(Prefix + "OP-50") > -1) OPT.Opacity = 50;
	else if (OPT.Classes.indexOf(Prefix + "OP-40") > -1) OPT.Opacity = 40;
	else if (OPT.Classes.indexOf(Prefix + "OP-30") > -1) OPT.Opacity = 30;
	else if (OPT.Classes.indexOf(Prefix + "OP-20") > -1) OPT.Opacity = 20;
	else if (OPT.Classes.indexOf(Prefix + "OP-30") > -1) OPT.Opacity = 30;
	else if (OPT.Classes.indexOf(Prefix + "OP-20") > -1) OPT.Opacity = 20;
	else if (OPT.Classes.indexOf(Prefix + "OP-10") > -1) OPT.Opacity = 10;
	else if (OPT.Classes.indexOf(Prefix + "OP-0")  > -1) OPT.Opacity = 0;

	$("#FLMBTN-OPT-Opacity").val(OPT.Opacity);

	// Styles - Opacity Hover
	OPT.Opacity_Hover = 100;

		 if (OPT.Classes.indexOf(Prefix + "OH-90") > -1) OPT.Opacity_Hover = 90;
	else if (OPT.Classes.indexOf(Prefix + "OH-80") > -1) OPT.Opacity_Hover = 80;
	else if (OPT.Classes.indexOf(Prefix + "OH-70") > -1) OPT.Opacity_Hover = 70;
	else if (OPT.Classes.indexOf(Prefix + "OH-60") > -1) OPT.Opacity_Hover = 60;
	else if (OPT.Classes.indexOf(Prefix + "OH-50") > -1) OPT.Opacity_Hover = 50;
	else if (OPT.Classes.indexOf(Prefix + "OH-40") > -1) OPT.Opacity_Hover = 40;
	else if (OPT.Classes.indexOf(Prefix + "OH-30") > -1) OPT.Opacity_Hover = 30;
	else if (OPT.Classes.indexOf(Prefix + "OH-20") > -1) OPT.Opacity_Hover = 20;
	else if (OPT.Classes.indexOf(Prefix + "OH-30") > -1) OPT.Opacity_Hover = 30;
	else if (OPT.Classes.indexOf(Prefix + "OH-20") > -1) OPT.Opacity_Hover = 20;
	else if (OPT.Classes.indexOf(Prefix + "OH-10") > -1) OPT.Opacity_Hover = 10;
	else if (OPT.Classes.indexOf(Prefix + "OH-0")  > -1) OPT.Opacity_Hover = 0;

	$("#FLMBTN-OPT-Opacity-Hover").val(OPT.Opacity_Hover);

	// Styles - Animate Icon
		 if (OPT.Classes.indexOf(Prefix + "AnIco-Rotate-90")  > -1) OPT.Animate_Icon = "Rotate-90";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Rotate-180") > -1) OPT.Animate_Icon = "Rotate-180";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Rotate-360") > -1) OPT.Animate_Icon = "Rotate-360";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Zoom")       > -1) OPT.Animate_Icon = "Zoom";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Loop")       > -1) OPT.Animate_Icon = "Loop";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Grow")       > -1) OPT.Animate_Icon = "Grow";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Shrink")     > -1) OPT.Animate_Icon = "Shrink";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Skew")       > -1) OPT.Animate_Icon = "Skew";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Flip-LR")    > -1) OPT.Animate_Icon = "Flip-LR";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Flip-TB")    > -1) OPT.Animate_Icon = "Flip-TB";
	else OPT.Animate_Icon = "None";

	$("#FLMBTN-OPT-Animate-Icon").val(OPT.Animate_Icon);

	// Styles - Animate Button
		 if (OPT.Classes.indexOf(Prefix + "Anim-Rotate")  > -1) OPT.Animate_Button = "Rotate";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Zoom")    > -1) OPT.Animate_Button = "Zoom";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Grow")    > -1) OPT.Animate_Button = "Grow";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Shrink")  > -1) OPT.Animate_Button = "Shrink";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Flip-LR") > -1) OPT.Animate_Button = "Flip-LR";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Flip-TB") > -1) OPT.Animate_Button = "Flip-TB";
	else OPT.Animate_Button = "None";

	$("#FLMBTN-OPT-Animate-Button").val(OPT.Animate_Button);

	// Styles - Transitions
	if (OPT.Classes.indexOf(Prefix + "Trans")  > -1)
		$("#FLMBTN-OPT-Transitions").val("Enabled");
	else
		$("#FLMBTN-OPT-Transitions").val("Disabled");

	// Customize - Font Family
	OPT.Font_Family = '';

		 if (OPT.Classes.indexOf(Prefix + "Font-Arial")           > -1) OPT.Font_Family = "[CLASS-Arial]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Arial-Black")     > -1) OPT.Font_Family = "[CLASS-Arial-Black]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Comic-Sans-MS")   > -1) OPT.Font_Family = "[CLASS-Comic-Sans-MS]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Impact")          > -1) OPT.Font_Family = "[CLASS-Impact]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Lucida-Sans")     > -1) OPT.Font_Family = "[CLASS-Lucida-Sans]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Tahoma")          > -1) OPT.Font_Family = "[CLASS-Tahoma]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Trebuchet-MS")    > -1) OPT.Font_Family = "[CLASS-Trebuchet-MS]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Verdana")         > -1) OPT.Font_Family = "[CLASS-Verdana]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Book-Antiqua")    > -1) OPT.Font_Family = "[CLASS-Book-Antiqua]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Georgia")         > -1) OPT.Font_Family = "[CLASS-Georgia]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Times-New-Roman") > -1) OPT.Font_Family = "[CLASS-Times-New-Roman]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Courier-New")     > -1) OPT.Font_Family = "[CLASS-Courier-New]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Lucida-Console")  > -1) OPT.Font_Family = "[CLASS-Lucida-Console]";

	if (OPT.Font_Family === '' && OPT.Styles.fontFamily !== '')
		OPT.Font_Family = String(OPT.Styles.fontFamily);

	$("#FLMBTN-OPT-Font-Family").val(OPT.Font_Family);

	// Customize - Font Size
	if (OPT.Styles.fontSize !== '')
		$("#FLMBTN-OPT-Font-Size").val(OPT.Styles.fontSize);

	// Customize - Icon Placement
	if (Input.indexOf("<i") > -1)
	{
			 if (OPT.Classes.indexOf(Prefix + "Icon-Right") > -1) $("#FLMBTN-OPT-Icon-Placement").val("Right");
		else if (OPT.Classes.indexOf(Prefix + "Icon-Only")  > -1) $("#FLMBTN-OPT-Icon-Placement").val("Only");

		// Select Icon
		OPT.Icon = $("#FLMBTN-Import-Space i").prop("class");
		OPT.Icon = OPT.Icon.replace(ICONS_TYPE, '').replace(/ /g, '');
		FLMBTN.Icons_Select(OPT.Icon);
	}

	// Customize - Small Placement
	if (Input.indexOf("<small>") > -1)
	{
		if (OPT.Classes.indexOf(Prefix + "Small-Left") > -1) $("#FLMBTN-OPT-Small-Placement").val("Left");
		else $("#FLMBTN-OPT-Small-Placement").val("Right");
	}

	// Customize - Text Only
	if (OPT.Classes.indexOf(Prefix + "Text-Only") > -1)
	{
		$("#FLMBTN-OPT-Icon-Placement").val("None");
		$("#FLMBTN-OPT-Small-Placement").val("None");
	}

	// Customize - Button Float
		 if (Input.indexOf("float:left;")  > -1) $("#FLMBTN-OPT-Button-Float").val("Left");
	else if (Input.indexOf("float:right;") > -1) $("#FLMBTN-OPT-Button-Float").val("Right");

	// Customize - Button Width
	if (OPT.Styles.width !== '')
		$("#FLMBTN-OPT-Button-Width").val(OPT.Styles.width);

	// Customize - Button Height
	if (OPT.Styles.height !== '')
		$("#FLMBTN-OPT-Button-Height").val(OPT.Styles.height);

	// Customize - Button Line Height
	if (OPT.Styles.lineHeight !== '')
		$("#FLMBTN-OPT-Button-Line-Height").val(OPT.Styles.lineHeight);

	// Customize - Custom Text Color
	if (Input.indexOf("color:#") > -1)
	{
		$("#FLMBTN-OPT-Custom-Text-Toggle").val("Enabled");
		$("#FLMBTN-OPT-Custom-Text-Color" ).val(Input.Search("color:#", ";"));
		FLMBTN.Text_Color();
	}

	// Customize - Custom Background Color
	if (Input.indexOf("background:#") > -1)
	{
		$("#FLMBTN-OPT-Custom-BG-Toggle").val("Enabled");
		$("#FLMBTN-OPT-Custom-BG-Color" ).val(Input.Search("background:#", ";"));
		FLMBTN.Background_Color();
	}

	// Customize - Custom Border Color
	if (Input.indexOf("border-color:#") > -1)
	{
		$("#FLMBTN-OPT-Custom-Border-Toggle").val("Enabled");
		$("#FLMBTN-OPT-Custom-Border-Color" ).val(Input.Search("border-color:#", ";"));
		FLMBTN.Border_Color();
	}

	// Customize - Custom Border Width
	if (OPT.Styles.borderWidth !== '')
	{
		$("#FLMBTN-OPT-Custom-BorderW-Toggle").val("Enabled");
		FLMBTN.Border_Width();
		OPT.Border_Width = OPT.Styles.borderWidth.replace("px", '');
		FLMBTN.Slider_Set({Name: "Custom-BorderW", Value: OPT.Border_Width });
	}

	// Customize - Custom Border Style	
		 if (OPT.Classes.indexOf(Prefix + "Border-None")        > -1) OPT.Border_Style = "None";
	else if (OPT.Classes.indexOf(Prefix + "Border-Dashed")      > -1) OPT.Border_Style = "Dashed";
	else if (OPT.Classes.indexOf(Prefix + "Border-Dotted")      > -1) OPT.Border_Style = "Dotted";
	else if (OPT.Classes.indexOf(Prefix + "Border-Double")      > -1) OPT.Border_Style = "Double";
	else if (OPT.Classes.indexOf(Prefix + "Border-Groove")      > -1) OPT.Border_Style = "Groove";
	else if (OPT.Classes.indexOf(Prefix + "Border-Inset")       > -1) OPT.Border_Style = "Inset";
	else if (OPT.Classes.indexOf(Prefix + "Border-Outset")      > -1) OPT.Border_Style = "Outset";
	else if (OPT.Classes.indexOf(Prefix + "Border-Ridge")       > -1) OPT.Border_Style = "Ridge";
	else if (OPT.Classes.indexOf(Prefix + "Border-Solid")       > -1) OPT.Border_Style = "Solid";
	else OPT.Border_Style = "Default";

	$("#FLMBTN-OPT-Custom-Border-Style").val(OPT.Border_Style);
};

//*************************************************************
// FLMBTN >> Import: Shortcode
//  PARAM >> String | Input
//*************************************************************
FLMBTN.Import_Shortcode = function(Input)
{
	var Args = [];
	var Params = Input.match(/[\w-]+="[^"]*"/g);
   
	for (var i = 0; i < Params.length; i++)
	{
		var Temp = Params[i].split(/=(.+)?/);
			Temp[1] = Temp[1].slice(1);
			Temp[1] = Temp[1].slice(0, -1);
	
		Args[Temp[0]] = Temp[1];
	}
	
	// Section - Details
	Shortcode_Value(Args, "link_address", '', "OPT-Link-Address");
	Shortcode_Value(Args, "link_target",  '', "OPT-Link-Target");
	Shortcode_Value(Args, "link_title",   '', "OPT-Link-Title");
	Shortcode_Value(Args, "link_rel",     '', "OPT-Link-Rel");
	Shortcode_Value(Args, "custom_id",    '', "OPT-Custom-ID");
	Shortcode_Value(Args, "custom_class", '', "OPT-Custom-Class");
	Shortcode_Value(Args, "button_text",  '', "OPT-Button-Text");
	Shortcode_Value(Args, "button_small", '', "OPT-Button-Small");
	
	// Section - Styles
	Shortcode_Value(Args, "button_size",       "XS",       "OPT-Button-Size");
	Shortcode_Value(Args, "button_color",      "Light",    "OPT-Button-Color");
	Shortcode_Value(Args, "text_color",        "Default",  "OPT-Text-Color");
	Shortcode_Value(Args, "button_style",      "Default",  "OPT-Button-Style");
	Shortcode_Value(Args, "button_style_icon", "None",     "OPT-Button-Style-Icon");
	Shortcode_Value(Args, "button_style_3d",   "None",     "OPT-Button-Style-3D");
	Shortcode_Value(Args, "button_hover",      "None",     "OPT-Button-Hover");
	Shortcode_Value(Args, "rounded_corners",   "3",        "Rounded-Corners", true);
	Shortcode_Value(Args, "box_shadow",        "0",        "Box-Shadow", true);
	Shortcode_Value(Args, "text_shadow",       "0",        "Text-Shadow", true);
	Shortcode_Value(Args, "opacity",           "100",      "Opacity", true);
	Shortcode_Value(Args, "opacity_hover",     "100",      "Opacity-Hover", true);
	Shortcode_Value(Args, "animate_icon",      "None",     "OPT-Animate-Icon");
	Shortcode_Value(Args, "animate_button",    "None",     "OPT-Animate-Button");
	Shortcode_Value(Args, "transitions",       "Disabled", "OPT-Transitions");
	
	// Section - Customize
	Shortcode_Value(Args, "font_family",         '',        "OPT-Font-Family");
	Shortcode_Value(Args, "font_size",           '',        "OPT-Font-Size");
	Shortcode_Value(Args, "icon_placement",      "Left",    "OPT-Icon-Placement");
	Shortcode_Value(Args, "small_placement",     "None",    "OPT-Small-Placement");
	Shortcode_Value(Args, "button_float",        "None",    "OPT-Button-Float");
	Shortcode_Value(Args, "button_width",        '',        "OPT-Button-Width");
	Shortcode_Value(Args, "button_height",       '',        "OPT-Button-Height");
	Shortcode_Value(Args, "button_line_height",  '',        "OPT-Button-Line-Height");
	Shortcode_Value(Args, "custom_text_color",   '',        "OPT-Custom-Text-Color");
	Shortcode_Value(Args, "custom_bg_color",     '',        "OPT-Custom-BG-Color");
	Shortcode_Value(Args, "custom_border_color", '',        "OPT-Custom-Border-Color");
	Shortcode_Value(Args, "custom_border_width", "1",       "Custom-BorderW", true);
	Shortcode_Value(Args, "custom_border_style", "Default", "OPT-Custom-Border-Style");
	
	if ($("#FLMBTN-OPT-Custom-Text-Color").val() !== '')
	{
		$("#FLMBTN-OPT-Custom-Text-Toggle").val("Enabled");
		FLMBTN.Text_Color();
	}
	
	if ($("#FLMBTN-OPT-Custom-BG-Color").val() !== '')
	{
		$("#FLMBTN-OPT-Custom-BG-Toggle").val("Enabled");
		FLMBTN.Background_Color();
	}
	
	if ($("#FLMBTN-OPT-Custom-Border-Color").val() !== '')
	{
		$("#FLMBTN-OPT-Custom-Border-Toggle").val("Enabled");
		FLMBTN.Border_Color();
	}
	
	if ("custom_border_width" in Args)
	{
		$("#FLMBTN-OPT-Custom-BorderW-Toggle").val("Enabled");
		FLMBTN.Border_Width();
	}
	
	// Customize - Text Only
	if ("text_only" in Args)
	{
		if (Args['text_only'] === "Yes")
		{
			$("#FLMBTN-OPT-Icon-Placement").val("None");
			$("#FLMBTN-OPT-Small-Placement").val("None");
		}
	}
	
	// Section - Icon
	if ("icon" in Args)
		FLMBTN.Icons_Select(Args['icon']);
	
	function Shortcode_Value(Obj, Label, Default, Field, Slider)
	{
		try
		{
			Slider = Slider || false;
			var Temp = Default;
		
			if (Label in Obj)
				Temp = Obj[Label];
			
			if (Slider)
				APP.Slider_Set({Name: Field, Value: Temp });
			else
				jQuery("#FLMBTN-" + Field).val(Temp);
		}
		catch(e){}
	}
};

//*************************************************************
// FLMBTN >> Import: PHP
//  PARAM >> String | Input
//*************************************************************
FLMBTN.Import_PHP = function(Input)
{
	Input = Input.replace('<?php FLMBTN_Build( array( ', '');
	Input = Input.replace(' ) ); ?>', '');
	
	var Args = [];
	var Params = Input.split('", "');

	for (var i = 0; i < Params.length; i++)
	{
		var Temp = Params[i].split(/=>(.+)?/);
			Temp[0] = Temp[0].replace(/"/g, '');
			Temp[1] = Temp[1].replace(/"/g, '');

		Args[Temp[0]] = Temp[1];
	}
	
	// Section - Details
	PHP_Value(Args, "link_address", '', "OPT-Link-Address");
	PHP_Value(Args, "link_target",  '', "OPT-Link-Target");
	PHP_Value(Args, "link_title",   '', "OPT-Link-Title");
	PHP_Value(Args, "link_rel",     '', "OPT-Link-Rel");
	PHP_Value(Args, "custom_id",    '', "OPT-Custom-ID");
	PHP_Value(Args, "custom_class", '', "OPT-Custom-Class");
	PHP_Value(Args, "button_text",  '', "OPT-Button-Text");
	PHP_Value(Args, "button_small", '', "OPT-Button-Small");

	// Section - Styles
	PHP_Value(Args, "button_size",       "XS",       "OPT-Button-Size");
	PHP_Value(Args, "button_color",      "Light",    "OPT-Button-Color");
	PHP_Value(Args, "text_color",        "Default",  "OPT-Text-Color");
	PHP_Value(Args, "button_style",      "Default",  "OPT-Button-Style");
	PHP_Value(Args, "button_style_icon", "None",     "OPT-Button-Style-Icon");
	PHP_Value(Args, "button_style_3d",   "None",     "OPT-Button-Style-3D");
	PHP_Value(Args, "button_hover",      "None",     "OPT-Button-Hover");
	PHP_Value(Args, "rounded_corners",   "3",        "Rounded-Corners", true);
	PHP_Value(Args, "box_shadow",        "0",        "Box-Shadow", true);
	PHP_Value(Args, "text_shadow",       "0",        "Text-Shadow", true);
	PHP_Value(Args, "opacity",           "100",      "Opacity", true);
	PHP_Value(Args, "opacity_hover",     "100",      "Opacity-Hover", true);
	PHP_Value(Args, "animate_icon",      "None",     "OPT-Animate-Icon");
	PHP_Value(Args, "animate_button",    "None",     "OPT-Animate-Button");
	PHP_Value(Args, "transitions",       "Disabled", "OPT-Transitions");

	// Section - Customize
	PHP_Value(Args, "font_family",         '',        "OPT-Font-Family");
	PHP_Value(Args, "font_size",           '',        "OPT-Font-Size");
	PHP_Value(Args, "icon_placement",      "Left",    "OPT-Icon-Placement");
	PHP_Value(Args, "small_placement",     "None",    "OPT-Small-Placement");
	PHP_Value(Args, "button_float",        "None",    "OPT-Button-Float");
	PHP_Value(Args, "button_width",        '',        "OPT-Button-Width");
	PHP_Value(Args, "button_height",       '',        "OPT-Button-Height");
	PHP_Value(Args, "button_line_height",  '',        "OPT-Button-Line-Height");
	PHP_Value(Args, "custom_text_color",   '',        "OPT-Custom-Text-Color");
	PHP_Value(Args, "custom_bg_color",     '',        "OPT-Custom-BG-Color");
	PHP_Value(Args, "custom_border_color", '',        "OPT-Custom-Border-Color");
	PHP_Value(Args, "custom_border_width", "1",       "Custom-BorderW", true);
	PHP_Value(Args, "custom_border_style", "Default", "OPT-Custom-Border-Style");

	if ($("#FLMBTN-OPT-Custom-Text-Color").val() !== '')
	{
		$("#FLMBTN-OPT-Custom-Text-Toggle").val("Enabled");
		FLMBTN.Text_Color();
	}

	if ($("#FLMBTN-OPT-Custom-BG-Color").val() !== '')
	{
		$("#FLMBTN-OPT-Custom-BG-Toggle").val("Enabled");
		FLMBTN.Background_Color();
	}

	if ($("#FLMBTN-OPT-Custom-Border-Color").val() !== '')
	{
		$("#FLMBTN-OPT-Custom-Border-Toggle").val("Enabled");
		FLMBTN.Border_Color();
	}

	if ("custom_border_width" in Args)
	{
		$("#FLMBTN-OPT-Custom-BorderW-Toggle").val("Enabled");
		FLMBTN.Border_Width();
	}
	
	// Customize - Text Only
	if ("text_only" in Args)
	{
		if (Args['text_only'] === "Yes")
		{
			$("#FLMBTN-OPT-Icon-Placement").val("None");
			$("#FLMBTN-OPT-Small-Placement").val("None");
		}
	}

	// Section - Icon
	if ("icon" in Args)
		FLMBTN.Icons_Select(Args['icon']);
	
	function PHP_Value(Obj, Label, Default, Field, Slider)
	{
		try
		{
			Slider = Slider || false;
			var Temp = Default;

			if (Label in Obj)
				Temp = Obj[Label];

			if (Slider)
				APP.Slider_Set({Name: Field, Value: Temp });
			else
				jQuery("#FLMBTN-" + Field).val(Temp);
		}
		catch(e){}
	}
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

$(document).ready(function()
{
	tinymce.PluginManager.add("FLMBTN_Button", function( editor, url )
	{
		editor.addButton("FLMBTN_Button", {
			title: "Button Builder",
			image: url + "/../Images/Icon-Editor.png",
			icon: false,
			onclick: function() { FLMBTN.Popup() }
		});
	});
});

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

})(jQuery);
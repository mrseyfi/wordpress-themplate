//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

(function($) {

var APP = {};

$(document).ready(function()
{
	// Preview Window Background
	APP.Preview_BG = "FFFFFF";
	var Preview_BG = $("#Preview-Color").colorpicker({
		color: "#" + APP.Preview_BG,
		close:  function(event, color) { APP.Preview_BG = color.formatted; },
		select: function(event, color) { $("#Preview").css("background-color", "#" + color.formatted); },
		cancel: function(event, color) { $("#Preview").css("background-color", "#" + APP.Preview_BG);  }
	});

	$("#Preview-Picker").click(function(e) {
		e.stopPropagation();
		Preview_BG.colorpicker("open");
	});
	
	// Preview Window Scroll
	$(window).scroll(function()
	{
		var Check       = $(window).scrollTop();
		var Prev_Height = $("#Preview").height();
		var Prev_Top    = $("#wpadminbar").height();
		
		if (Check > 111 && $(window).width() > 586)
		{
			$("#Preview").css("top", Prev_Top + "px");
			$("#Preview").addClass("Scrolled");
			$("#Preview-Box").css("max-height", "200px");
			$("#Preview-Placeholder").css("height", Prev_Height + "px").show();
		}
		else
		{
			$("#Preview").css("top", "0px");
			$("#Preview").removeClass("Scrolled");
			$("#Preview-Box").css("max-height", "none");
			$("#Preview-Placeholder").css("height", "240px").hide();
		}
		return false;
	});
	
	// Preview Window Resize
	$("#Preview").css("max-width", $("#Code").width() + "px");
	$(window).resize(function()
	{
		$("#Preview").css("max-width", $("#Code").width() + "px");
	});
	
	// Bind: Code Tabs
	$("#Code-Tabs div").each(function(i)
	{
		var ID = $(this).prop("id").replace("Code-Tab-", '');
		$(this).click(function(){ APP.Section_Code(ID) });
	});
	
	// Bind: Code Highlight
	$("#Code-Button").click(function(){ $("#Code-Text-" + APP.Code_Section).select() });
	
	// Bind: Box Tabs
	$("#Box-Tabs div").each(function(i)
	{
		var ID = $(this).prop("id").replace("Box-Tab-", '');
		$(this).click(function(){ APP.Section_Box(ID) });
	});
	
	// Bind: Box Menus
	$(".Box-Button").dropdown();
	
	// Bind: Shortcut Codes
	$("#Box-Menu-Shortcuts ul li").each(function(){
		$(this).click(function(){ APP.Link_Shortcut($(this).prop("id")) });
	});
	
	// Bind: Fonts
	$("#Box-Menu-Fonts ul li").each(function(){
		$(this).click(function(){ APP.Button_Fonts($(this).prop("id")) });
	});
	
	// Bind: Custom Text Color
	$("#OPT-Custom-Text-Toggle").change(function(){ APP.Text_Color() });
	$("#OPT-Custom-Text-Color").colorpicker({ select: function(event, color){ APP.Build() } });

	// Bind: Custom Background Color
	$("#OPT-Custom-BG-Toggle").change(function(){ APP.Background_Color() });
	$("#OPT-Custom-BG-Color").colorpicker({ select: function(event, color){ APP.Build() } });
	
	// Bind: Custom Border Color
	$("#OPT-Custom-Border-Toggle").change(function(){ APP.Border_Color() });
	$("#OPT-Custom-Border-Color").colorpicker({ select: function(event, color){ APP.Build() } });
	
	// Bind: Custom Border Width
	$("#OPT-Custom-BorderW-Toggle").change(function(){ APP.Border_Width() });
	
	// Setup Sliders
	APP.Slider_Setup({Name: "Rounded-Corners", Value: 3,   Min: 0, Max: 25});
	APP.Slider_Setup({Name: "Box-Shadow",      Value: 0,   Min: 0, Max: 10});
	APP.Slider_Setup({Name: "Text-Shadow",     Value: 0,   Min: 0, Max: 10});
	APP.Slider_Setup({Name: "Opacity",         Value: 100, Min: 0, Max: 100, Step: 10});
	APP.Slider_Setup({Name: "Opacity-Hover",   Value: 100, Min: 0, Max: 100, Step: 10});
	APP.Slider_Setup({Name: "Custom-BorderW",  Value: 1,   Min: 0, Max: 25});
	
	// Initial Sections
	APP.Section_Code("Shortcode");
	APP.Section_Box("Details");
	
	// Build Icons
	try { APP.Icons_Display(); } catch(e){}
	
	// Bind: Icon Search
	$("#Search-Text" ).keyup(function(){ try { APP.Icons_Display() } catch(e){} });
	$("#Search-Reset").click(function(){ try { APP.Icons_Reset()   } catch(e){} });
	$("#Search-Icon" ).click(function(){ $("#Search-Text").focus() });
	
	// Regex Checks (A-Z, 0-9, -, _)
	$("#OPT-Custom-ID"   ).keyup(function() { APP.Regex_Check( $(this) ) });
	$("#OPT-Custom-Class").keyup(function() { APP.Regex_Check( $(this) ) });
	
	// Bind: Reset Buttons
	$("#Reset-All"    ).click(function(){ APP.Build_Reset("All")     });
	$("#Reset-Details").click(function(){ APP.Build_Reset("Details") });
	$("#Reset-Styles" ).click(function(){ APP.Build_Reset("Styles")  });
	$("#Reset-Custom" ).click(function(){ APP.Build_Reset("Custom")  });
	$("#Reset-Icons"  ).click(function(){ APP.Build_Reset("Icons")   });
	
	// Bind: Samples
	$("#Sample-Add-to-Cart").click(function(){ APP.Build_Sample("Add-to-Cart") });
	$("#Sample-Order-Now"  ).click(function(){ APP.Build_Sample("Order-Now")   });
	$("#Sample-Read-More"  ).click(function(){ APP.Build_Sample("Read-More")   });
	$("#Sample-Top"        ).click(function(){ APP.Build_Sample("Top")         });
	$("#Sample-Previous"   ).click(function(){ APP.Build_Sample("Previous")    });
	$("#Sample-Facebook"   ).click(function(){ APP.Build_Sample("Facebook")    });
	$("#Sample-Tweet-This" ).click(function(){ APP.Build_Sample("Tweet-This")  });
	$("#Sample-Google-Plus").click(function(){ APP.Build_Sample("Google-Plus") });
	$("#Sample-GitHub"     ).click(function(){ APP.Build_Sample("GitHub")      });
	$("#Sample-Play-Video" ).click(function(){ APP.Build_Sample("Play-Video")  });
	
	// Bind: Import Button
	$("#Import-Button").click(function(){ APP.Import(); APP.Section_Box("Details"); });
	
	// Bind: Fields
	$("#OPT-Link-Address"       ).keyup(function(){ APP.Build() });
	$("#OPT-Link-Title"         ).keyup(function(){ APP.Build() });
	$("#OPT-Custom-ID"          ).keyup(function(){ APP.Build() });
	$("#OPT-Custom-Class"       ).keyup(function(){ APP.Build() });
	$("#OPT-Button-Text"        ).keyup(function(){ APP.Build() });
	$("#OPT-Button-Small"       ).keyup(function(){ APP.Build() });
	$("#OPT-Button-Width"       ).keyup(function(){ APP.Build() });
	$("#OPT-Button-Height"      ).keyup(function(){ APP.Build() });
	$("#OPT-Button-Line-Height" ).keyup(function(){ APP.Build() });
	$("#OPT-Font-Family"        ).keyup(function(){ APP.Build() });
	$("#OPT-Font-Size"          ).keyup(function(){ APP.Build() });
	
	$("#OPT-Link-Target"        ).change(function(){ APP.Build() });
	$("#OPT-Link-Rel"           ).change(function(){ APP.Build() });
	$("#OPT-Icon-Placement"     ).change(function(){ APP.Build() });
	$("#OPT-Small-Placement"    ).change(function(){ APP.Build() });
	$("#OPT-Button-Float"       ).change(function(){ APP.Build() });
	$("#OPT-Button-Size"        ).change(function(){ APP.Build() });
	$("#OPT-Button-Color"       ).change(function(){ APP.Build() });
	$("#OPT-Text-Color"         ).change(function(){ APP.Build() });
	$("#OPT-Button-Style"       ).change(function(){ APP.Build() });
	$("#OPT-Button-Style-Icon"  ).change(function(){ APP.Build() });
	$("#OPT-Button-Style-3D"    ).change(function(){ APP.Build() });
	$("#OPT-Button-Hover"       ).change(function(){ APP.Build() });
	$("#OPT-Button-Size"        ).change(function(){ APP.Build() });
	$("#OPT-Custom-BG-Color"    ).change(function(){ APP.Build() });
	$("#OPT-Custom-Text-Color"  ).change(function(){ APP.Build() });
	$("#OPT-Custom-Border-Color").change(function(){ APP.Build() });
	$("#OPT-Custom-BorderW"     ).change(function(){ APP.Build() });
	$("#OPT-Custom-Border-Style").change(function(){ APP.Build() });
	$("#OPT-Animate-Icon"       ).change(function(){ APP.Build() });
	$("#OPT-Animate-Button"     ).change(function(){ APP.Build() });
	$("#OPT-Transitions"        ).change(function(){ APP.Build() });
	
	// Initialize Builder
	APP.Build();
});

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
//   APP >> Slider: Setup
// PARAM >> Obj | Data
//**********************************************************
APP.Slider_Setup = function(Data)
{
	var Name = Data["Name"], Val = Data["Value"];
	var Min  = Data["Min"],  Max = Data["Max"];
	var Step = Data["Step"];
	
	if (Step === undefined || !Step || Step === '' || Step === 0)
		Step = 1;

	$("#Slider-" + Name).slider({
		value: Val,
		min: Min,
		max: Max,
		step: Step,
		slide: function(event, ui) {
			$("#OPT-" + Name).html(ui.value);
			APP.Build();
		}
	});
	$("#OPT-" + Name).html($("#Slider-" + Name).slider("value"));
};

//**********************************************************
//   APP >> Slider: Set
// PARAM >> Obj | Data
//**********************************************************
APP.Slider_Set = function(Data)
{
	var Name = Data["Name"], Val = Data["Value"];
	$("#Slider-" + Name).slider({value: Val});
	$("#OPT-" + Name).html(Val);
};

//**********************************************************
// PROTO >> String: Search
// PARAM >> String | A
// PARAM >> String | B
// NOTES >> Grab a section of string based on A/B.
//**********************************************************
String.prototype.Search = function(A, B)
{
	var Str = this.toString();
		Str = Str.substring(Str.indexOf(A) + A.length);
		Str = Str.substring(0, Str.indexOf(B));
	return Str;
};

//**********************************************************
//   APP >> Regex Check
// PARAM >> Object | Field
// NOTES >> Restrict input based on alphanumeric chars.
//**********************************************************
APP.Regex_Check = function(Field)
{
	if (!Field) return;
	
	var Check = $(Field).val().replace(/[^a-zA-Z0-9-_\s]/g, "");
	
	if (/\s/.test(Check))
		Check = Check.replace(/\s/g, "");
	$(Field).val(Check);
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
//   APP >> Section (Code)
// PARAM >> String | Section
//**********************************************************
APP.Section_Code = function(Section)
{
	if (Section !== APP.Code_Section)
	{
		// Reset Tabs
		$("#Code-Tabs div").each(function() { $(this).removeClass("Active"); });

		// Reset Sections
		$("#Code textarea").each(function() { $(this).hide(); });

		// Set Active Tab / Section
		$("#Code-Tab-" + Section).addClass("Active");
		$("#Code-Text-" + Section).fadeIn();

		APP.Code_Section = Section;
	}
};

//**********************************************************
//   APP >> Section (Box)
// PARAM >> String | Section
//**********************************************************
APP.Section_Box = function(Section)
{
	if (Section !== APP.Box_Section)
	{
		// Reset Tabs
		$("#Box-Tabs div").each(function() { $(this).removeClass("Active"); });
		
		// Reset Sections
		$("#Box section").each(function() { $(this).hide(); });
	
		// Set Active Tab / Section
		$("#Box-Tab-" + Section).addClass("Active");
		$("#Box-Section-" + Section).fadeIn();

		APP.Box_Section = Section;
	}
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
//   APP >> Link Shortcut
// PARAM >> String | Shortcut
//**********************************************************
APP.Link_Shortcut = function(Shortcut)
{
	Shortcut = "{" + Shortcut.toUpperCase().replace("SHORTCUT-", '') + "}";
	var Value = $("#OPT-Link-Address").val();
	$("#OPT-Link-Address").val(Value + Shortcut);
	APP.Build();
};

//**********************************************************
//   APP >> Button Fonts
// PARAM >> String | ID
//**********************************************************
APP.Button_Fonts = function(ID)
{
	var Font = ID.replace("Font-", '');
		Font = "{CLASS-" + Font + "}";

	$("#OPT-Font-Family").val(Font);
	APP.Build();
};

//**********************************************************
// APP >> Text Color
//**********************************************************
APP.Text_Color = function()
{	
	if ($("#OPT-Custom-Text-Toggle").val() === "Enabled") $("#Custom-Text-Color").show();
	else $("#Custom-Text-Color").hide();
	APP.Build();
};

//**********************************************************
// APP >> Background Color
//**********************************************************
APP.Background_Color = function()
{	
	if ($("#OPT-Custom-BG-Toggle").val() === "Enabled") $("#Custom-BG-Color").show();
	else $("#Custom-BG-Color").hide();
	APP.Build();
};

//**********************************************************
// APP >> Border Color
//**********************************************************
APP.Border_Color = function()
{	
	if ($("#OPT-Custom-Border-Toggle").val() === "Enabled") $("#Custom-Border-Color").show();
	else $("#Custom-Border-Color").hide();
	APP.Build();
};

//**********************************************************
// APP >> Border Width
//**********************************************************
APP.Border_Width = function()
{	
	if ($("#OPT-Custom-BorderW-Toggle").val() === "Enabled") $("#Custom-Border-Width").show();
	else $("#Custom-Border-Width").hide();
	APP.Build();
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// APP >> Icons: Display
//**********************************************************
APP.Icons_Display = function()
{
	var Search = $("#Search-Text").val().toLowerCase();
	var Icons  = '';

	for (var i = 0, Len = ICONS.length; i < Len; i++)
	{
		if (Search === '' || ICONS[i].indexOf(Search) > -1)
		{		
			Icons += "<div id='" + ICONS[i] + "' class='Button-Alt' title='" + ICONS[i] + "'>";
			Icons += "<i class='" + ICONS_TYPE + " " + ICONS[i] + "'></i></div>";
		}
	}

	$("#Icons-List").html(Icons);
	
	$("#Icons-List div").each(function()
	{
		var ID = $(this).prop("id");
		$(this).click(function(){ APP.Icons_Select(ID) });
	});	
	
	APP.Icons_Select(APP.Icons_Selected);

	if (Search !== '')
	{
		$("#Search-Icon").hide();
		$("#Search-Reset").show();
	}
	else
	{
		$("#Search-Reset").hide();
		$("#Search-Icon").show();
	}
};

//**********************************************************
//   APP >> Icons: Reset
//**********************************************************
APP.Icons_Reset = function()
{
	$("#Search-Text").val('');
	APP.Icons_Display();
};

//**********************************************************
//   APP >> Icons: Select
// PARAM >> String | ID
//**********************************************************
APP.Icons_Select = function(ID)
{
	$("#Icons-List div").each(function() { $(this).removeClass("Selected"); });
	$("#Icons-List #" + ID).addClass("Selected");
	APP.Icons_Selected = ID;
	APP.Build();
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// APP >> Build
//**********************************************************
APP.Build = function()
{
	var Str_Code = '';
	var Str_HTML = '';
	var Str_PHP  = ''; 
	var OPT = {
		Link_Address:          $("#OPT-Link-Address"         ).val(),
		Link_Target:           $("#OPT-Link-Target"          ).val(),
		Link_Title:            $("#OPT-Link-Title"           ).val(),
		Link_Rel:              $("#OPT-Link-Rel"             ).val(),
		Custom_ID:             $("#OPT-Custom-ID"            ).val(),
		Custom_Class:          $("#OPT-Custom-Class"         ).val(),
		Button_Text:           $("#OPT-Button-Text"          ).val(),
		Button_Small:          $("#OPT-Button-Small"         ).val(),
		Icon_Placement:        $("#OPT-Icon-Placement"       ).val(),
		Small_Placement:       $("#OPT-Small-Placement"      ).val(),
		Button_Float:          $("#OPT-Button-Float"         ).val(),
		Button_Width:          $("#OPT-Button-Width"         ).val(),
		Button_Height:         $("#OPT-Button-Height"        ).val(),
		Button_Line_Height:    $("#OPT-Button-Line-Height"   ).val(),
		Font_Family:           $("#OPT-Font-Family"          ).val(),
		Font_Size:             $("#OPT-Font-Size"            ).val(),
		Button_Size:           $("#OPT-Button-Size"          ).val(),
		Button_Color:          $("#OPT-Button-Color"         ).val(),
		Text_Color:            $("#OPT-Text-Color"           ).val(),
		Button_Style:          $("#OPT-Button-Style"         ).val(),
		Button_Style_Icon:     $("#OPT-Button-Style-Icon"    ).val(),
		Button_Style_3D:       $("#OPT-Button-Style-3D"      ).val(),
		Button_Hover:          $("#OPT-Button-Hover"         ).val(),
		Rounded_Corners:       $("#OPT-Rounded-Corners"      ).html(),
		Box_Shadow:            $("#OPT-Box-Shadow"           ).html(),
		Text_Shadow:           $("#OPT-Text-Shadow"          ).html(),
		Opacity:               $("#OPT-Opacity"              ).html(),
		Opacity_Hover:         $("#OPT-Opacity-Hover"        ).html(),
		Custom_BorderW:        $("#OPT-Custom-BorderW"       ).html(),
		Custom_Text_Toggle:    $("#OPT-Custom-Text-Toggle"   ).val(),
		Custom_Text_Color:     $("#OPT-Custom-Text-Color"    ).val(),
		Custom_BG_Toggle:      $("#OPT-Custom-BG-Toggle"     ).val(),
		Custom_BG_Color:       $("#OPT-Custom-BG-Color"      ).val(),
		Custom_Border_Toggle:  $("#OPT-Custom-Border-Toggle" ).val(),
		Custom_Border_Color:   $("#OPT-Custom-Border-Color"  ).val(),
		Custom_BorderW_Toggle: $("#OPT-Custom-BorderW-Toggle").val(),
		Custom_Border_Style:   $("#OPT-Custom-Border-Style"  ).val(),
		Animate_Icon:          $("#OPT-Animate-Icon"         ).val(),
		Animate_Button:        $("#OPT-Animate-Button"       ).val(),
		Transitions:           $("#OPT-Transitions"          ).val(),
		Icon: 			       APP.Icons_Selected
	};
	
	// Defaults
	if (OPT.Icon === undefined) OPT.Icon = '';
	
	// URL Check
	var Link_Address = OPT.Link_Address;
		Link_Address = Link_Address.replace("{HOME-SITE}",      URL.Home_Site);
		Link_Address = Link_Address.replace("{HOME-NETWORK}",   URL.Home_Network);
		Link_Address = Link_Address.replace("{ADMIN-PANEL}",    URL.Admin_Panel);
		Link_Address = Link_Address.replace("{LOGIN}",          URL.Login);
		Link_Address = Link_Address.replace("{LOGOUT}",         URL.Logout);
		Link_Address = Link_Address.replace("{REGISTER}",       URL.Register);
		Link_Address = Link_Address.replace("{LOST-PASSWORD}",  URL.Lost_Password);
		Link_Address = Link_Address.replace("{DIR-INCLUDES}",   URL.Dir_Includes);
		Link_Address = Link_Address.replace("{DIR-CONTENT}",    URL.Dir_Content);
		Link_Address = Link_Address.replace("{DIR-STYLESHEET}", URL.Dir_Stylesheet);
		Link_Address = Link_Address.replace("{DIR-TEMPLATE}",   URL.Dir_Template);
		
	// Setup Class
	var Prefix = "FLMBTN-";
	var Class  = Prefix + "Btn";
		Class += " " + Prefix + "Size-"  + OPT.Button_Size;
		Class += " " + Prefix + "Color-" + OPT.Button_Color;
		
	if (OPT.Rounded_Corners > 0) Class += " " + Prefix + "BR-" + OPT.Rounded_Corners;
	if (OPT.Box_Shadow      > 0) Class += " " + Prefix + "BS-" + OPT.Box_Shadow;
	if (OPT.Text_Shadow     > 0) Class += " " + Prefix + "TS-" + OPT.Text_Shadow;
	if (OPT.Opacity       < 100) Class += " " + Prefix + "OP-" + OPT.Opacity;
	if (OPT.Icon_Placement    === "Right") Class += " " + Prefix + "Icon-Right";
	if (OPT.Icon_Placement    === "Only")  Class += " " + Prefix + "Icon-Only";
	if (OPT.Small_Placement   === "Left")  Class += " " + Prefix + "Small-Left";
	if (OPT.Small_Placement   === "Right") Class += " " + Prefix + "Small-Right";
	if (OPT.Button_Style_Icon !== "None")  Class += " " + Prefix + OPT.Button_Style_Icon;
	if (OPT.Button_Style_3D   !== "None")  Class += " " + Prefix + OPT.Button_Style_3D;
	if (OPT.Button_Hover      !== "None")  Class += " " + Prefix + OPT.Button_Hover;
	if (OPT.Animate_Icon      !== "None")  Class += " " + Prefix + "AnIco-" + OPT.Animate_Icon;
	if (OPT.Animate_Button    !== "None")  Class += " " + Prefix + "Anim-" + OPT.Animate_Button;
	if (OPT.Transitions   !== "Disabled")  Class += " " + Prefix + "Trans";
	
	if (OPT.Custom_Border_Style !== "Default")
		Class += " " + Prefix + "BorderStyle-" + OPT.Custom_Border_Style;
	
	if (OPT.Opacity < 100 || OPT.Opacity_Hover < 100)
		Class += " " + Prefix + "OH-" + OPT.Opacity_Hover;

	if (OPT.Button_Style !== "Default")
	{
			 if (OPT.Button_Style === "Flat")    Class += " " + Prefix + "Flat-"    + OPT.Button_Color;
		else if (OPT.Button_Style === "Border")  Class += " " + Prefix + "Border-"  + OPT.Button_Color;
		else if (OPT.Button_Style === "Outline") Class += " " + Prefix + "Outline-" + OPT.Button_Color;
		else Class += " " + Prefix + OPT.Button_Style;
	}

	if (OPT.Text_Color !== "Default")
	{
		if (OPT.Text_Color !== "Engrave") Class += " " + Prefix + "Text-" + OPT.Text_Color;
		else Class += " " + Prefix + OPT.Text_Color;
	}
	
	if (OPT.Custom_Class !== '')
		Class += " " + OPT.Custom_Class;
	
	var Font_Class = '';
	if (OPT.Font_Family.indexOf("{") > -1)
	{
		Font_Class = OPT.Font_Family;
		Font_Class = Font_Class.replace("{CLASS-", '');
		Font_Class = Font_Class.replace("}", '');
		Font_Class = " " + Prefix + "Font-" + Font_Class;
		Class += Font_Class;
	}
	
	// No Icon or Small Text
	OPT.Text_Only = '';
	if (OPT.Icon_Placement === "None" && OPT.Small_Placement === "None")
	{
		OPT.Text_Only = "Yes";
		Class += " " + Prefix + "Text-Only";
	}

	// Build: Shortcode
	Str_Code  = '[flm_button';
	Str_Code += APP.Shortcode_Parameter("link_address",       OPT.Link_Address      );
	Str_Code += APP.Shortcode_Parameter("link_target",        OPT.Link_Target       );
	Str_Code += APP.Shortcode_Parameter("link_title",         OPT.Link_Title        );
	Str_Code += APP.Shortcode_Parameter("link_rel",           OPT.Link_Rel          );
	Str_Code += APP.Shortcode_Parameter("custom_id",          OPT.Custom_ID         );
	Str_Code += APP.Shortcode_Parameter("custom_class",       OPT.Custom_Class      );
	Str_Code += APP.Shortcode_Parameter("icon_placement",     OPT.Icon_Placement    );
	Str_Code += APP.Shortcode_Parameter("small_placement",    OPT.Small_Placement   );
	
	if (OPT.Icon_Placement !== "Only")
		Str_Code += APP.Shortcode_Parameter("button_text", OPT.Button_Text);
	
	if (OPT.Small_Placement !== "None")
		Str_Code += APP.Shortcode_Parameter("button_small", OPT.Button_Small);
	
	Str_Code += APP.Shortcode_Parameter("button_float",       OPT.Button_Float      );
	Str_Code += APP.Shortcode_Parameter("button_width",       OPT.Button_Width      );
	Str_Code += APP.Shortcode_Parameter("button_height",      OPT.Button_Height     );
	Str_Code += APP.Shortcode_Parameter("button_line_height", OPT.Button_Line_Height);
	Str_Code += APP.Shortcode_Parameter("font_family",        OPT.Font_Family       );
	Str_Code += APP.Shortcode_Parameter("font_size",          OPT.Font_Size         );
	Str_Code += APP.Shortcode_Parameter("button_size",        OPT.Button_Size       );
	Str_Code += APP.Shortcode_Parameter("button_color",       OPT.Button_Color      );
	Str_Code += APP.Shortcode_Parameter("text_color",         OPT.Text_Color        );
	Str_Code += APP.Shortcode_Parameter("button_style",       OPT.Button_Style      );
	Str_Code += APP.Shortcode_Parameter("button_style_icon",  OPT.Button_Style_Icon );
	Str_Code += APP.Shortcode_Parameter("button_style_3d",    OPT.Button_Style_3D   );
	Str_Code += APP.Shortcode_Parameter("button_hover",       OPT.Button_Hover      );
	Str_Code += APP.Shortcode_Parameter("rounded_corners",    OPT.Rounded_Corners   );
	Str_Code += APP.Shortcode_Parameter("box_shadow",         OPT.Box_Shadow        );
	Str_Code += APP.Shortcode_Parameter("text_shadow",        OPT.Text_Shadow       );
	Str_Code += APP.Shortcode_Parameter("opacity",            OPT.Opacity           );
	
	if (OPT.Opacity < 100 || OPT.Opacity_Hover < 100)
		Str_Code += APP.Shortcode_Parameter("opacity_hover", OPT.Opacity_Hover);
	
	if (OPT.Custom_Text_Toggle === "Enabled")
		Str_Code += APP.Shortcode_Parameter("custom_text_color", OPT.Custom_Text_Color );

	if (OPT.Custom_BG_Toggle === "Enabled")
		Str_Code += APP.Shortcode_Parameter("custom_bg_color", OPT.Custom_BG_Color);
		
	if (OPT.Custom_Border_Toggle === "Enabled")
		Str_Code += APP.Shortcode_Parameter("custom_border_color", OPT.Custom_Border_Color);
		
	if (OPT.Custom_BorderW_Toggle === "Enabled")
		Str_Code += APP.Shortcode_Parameter("custom_border_width", OPT.Custom_BorderW);
	
	Str_Code += APP.Shortcode_Parameter("custom_border_style", OPT.Custom_Border_Style);
	Str_Code += APP.Shortcode_Parameter("animate_icon",        OPT.Animate_Icon       );
	Str_Code += APP.Shortcode_Parameter("animate_button",      OPT.Animate_Button     );
	Str_Code += APP.Shortcode_Parameter("transitions",         OPT.Transitions        );
	Str_Code += APP.Shortcode_Parameter("text_only",           OPT.Text_Only          );

	if (OPT.Icon_Placement !== "None")
		Str_Code += APP.Shortcode_Parameter("icon", OPT.Icon);

	Str_Code += ']';
	
	// Build: PHP Function
	Str_PHP  = '<?php FLMBTN_Build( array(';
	Str_PHP += APP.PHP_Parameter("link_address",       OPT.Link_Address      );
	Str_PHP += APP.PHP_Parameter("link_target",        OPT.Link_Target       );
	Str_PHP += APP.PHP_Parameter("link_title",         OPT.Link_Title        );
	Str_PHP += APP.PHP_Parameter("link_rel",           OPT.Link_Rel          );
	Str_PHP += APP.PHP_Parameter("custom_id",          OPT.Custom_ID         );
	Str_PHP += APP.PHP_Parameter("custom_class",       OPT.Custom_Class      );
	Str_PHP += APP.PHP_Parameter("icon_placement",     OPT.Icon_Placement    );
	Str_PHP += APP.PHP_Parameter("small_placement",    OPT.Small_Placement   );
	
	if (OPT.Icon_Placement !== "Only")
		Str_PHP += APP.PHP_Parameter("button_text", OPT.Button_Text);

	if (OPT.Small_Placement !== "None")
		Str_PHP += APP.PHP_Parameter("button_small", OPT.Button_Small);

	Str_PHP += APP.PHP_Parameter("button_float",       OPT.Button_Float      );
	Str_PHP += APP.PHP_Parameter("button_width",       OPT.Button_Width      );
	Str_PHP += APP.PHP_Parameter("button_height",      OPT.Button_Height     );
	Str_PHP += APP.PHP_Parameter("button_line_height", OPT.Button_Line_Height);
	Str_PHP += APP.PHP_Parameter("font_family",        OPT.Font_Family       );
	Str_PHP += APP.PHP_Parameter("font_size",          OPT.Font_Size         );
	Str_PHP += APP.PHP_Parameter("button_size",        OPT.Button_Size       );
	Str_PHP += APP.PHP_Parameter("button_color",       OPT.Button_Color      );
	Str_PHP += APP.PHP_Parameter("text_color",         OPT.Text_Color        );
	Str_PHP += APP.PHP_Parameter("button_style",       OPT.Button_Style      );
	Str_PHP += APP.PHP_Parameter("button_style_icon",  OPT.Button_Style_Icon );
	Str_PHP += APP.PHP_Parameter("button_style_3d",    OPT.Button_Style_3D   );
	Str_PHP += APP.PHP_Parameter("button_hover",       OPT.Button_Hover      );
	Str_PHP += APP.PHP_Parameter("rounded_corners",    OPT.Rounded_Corners   );
	Str_PHP += APP.PHP_Parameter("box_shadow",         OPT.Box_Shadow        );
	Str_PHP += APP.PHP_Parameter("text_shadow",        OPT.Text_Shadow       );
	Str_PHP += APP.PHP_Parameter("opacity",            OPT.Opacity           );
	
	if (OPT.Opacity < 100 || OPT.Opacity_Hover < 100)
		Str_PHP += APP.PHP_Parameter("opacity_hover", OPT.Opacity_Hover );
		
	if (OPT.Custom_Text_Toggle === "Enabled")
		Str_PHP += APP.PHP_Parameter("custom_text_color", OPT.Custom_Text_Color );

	if (OPT.Custom_BG_Toggle === "Enabled")
		Str_PHP += APP.PHP_Parameter("custom_bg_color", OPT.Custom_BG_Color);

	if (OPT.Custom_Border_Toggle === "Enabled")
		Str_PHP += APP.PHP_Parameter("custom_border_color", OPT.Custom_Border_Color);
		
	if (OPT.Custom_BorderW_Toggle === "Enabled")
		Str_PHP += APP.PHP_Parameter("custom_border_width", OPT.Custom_BorderW);
	
	Str_PHP += APP.PHP_Parameter("custom_border_style", OPT.Custom_Border_Style);
	Str_PHP += APP.PHP_Parameter("animate_icon",        OPT.Animate_Icon       );
	Str_PHP += APP.PHP_Parameter("animate_button",      OPT.Animate_Button     );
	Str_PHP += APP.PHP_Parameter("transitions",         OPT.Transitions        );
	Str_PHP += APP.PHP_Parameter("text_only",           OPT.Text_Only          );
	
	if (OPT.Icon_Placement !== "None")
		Str_PHP += APP.PHP_Parameter("icon", OPT.Icon);
	
	if (Str_PHP.charAt(Str_PHP.length - 1) === ",")
		Str_PHP = Str_PHP.slice(0, -1);
	Str_PHP += ' ) ); ?>';
	
	// Build: HTML Code
	Str_HTML = '<a ';
	
	Str_HTML += 'href="' + Link_Address + '"';
	
	if (OPT.Link_Target !== '')
		Str_HTML += ' target="' + OPT.Link_Target + '"';
	
	if (OPT.Link_Rel !== '')
		Str_HTML += ' rel="' + OPT.Link_Rel + '"';
		
	if (OPT.Link_Title !== '')
		Str_HTML += ' title="' + OPT.Link_Title.replace(/"/g, '&#34;') + '"';
		
	// Set Class
	Str_HTML += ' class="' + Class + '"';
	
	// Custom Styles
	var Styles = '';

	// Custom Text Color
	if (OPT.Custom_Text_Toggle === "Enabled" && OPT.Custom_Text_Color !== '')
		Styles += 'color:#' + OPT.Custom_Text_Color + ';';

	// Custom Background Color
	if (OPT.Custom_BG_Toggle === "Enabled" && OPT.Custom_BG_Color !== '')
		Styles += 'background:#' + OPT.Custom_BG_Color + ';';
		
	// Custom Border Color
	if (OPT.Custom_Border_Toggle === "Enabled" && OPT.Custom_Border_Color !== '')
		Styles += 'border-color:#' + OPT.Custom_Border_Color + ';';
		
	// Custom Border Width
	if (OPT.Custom_BorderW_Toggle === "Enabled" && OPT.Custom_BorderW !== '')
		Styles += 'border-width:' + OPT.Custom_BorderW + 'px;';
		
	// Button Float
	if (OPT.Button_Float !== "None")
		Styles += 'float:' + OPT.Button_Float.toLowerCase() + ';';

	// Custom Font
	if (OPT.Font_Family !== '' && OPT.Font_Family.indexOf("{") <= -1)
		Styles += 'font-family:' + OPT.Font_Family.replace(/"/g, '') + ';';
		
	// Font Size
	if (OPT.Font_Size !== '')
		Styles += 'font-size:' + OPT.Font_Size + ';';
		
	// Button Width
	if (OPT.Button_Width !== '')
		Styles += 'width:' + OPT.Button_Width + ';';
		
	// Button Height
	if (OPT.Button_Height !== '')
		Styles += 'height:' + OPT.Button_Height + ';';
		
	// Button Line Height
	if (OPT.Button_Line_Height !== '')
		Styles += 'line-height:' + OPT.Button_Line_Height + ';';

	// Append Styles
	if (Styles !== '') Str_HTML += ' style="' + Styles + '"';
	
	// Append Custom ID
	if (OPT.Custom_ID !== '')
		Str_HTML += ' id="' + OPT.Custom_ID + '"';
		
	Str_HTML += '>';
	
	// Set Inner
	var Button_Text = OPT.Button_Text;
	if (Button_Text === '') Button_Text = "Button";
	
	if (Button_Text      !== '') Button_Text      = '<span>'  + Button_Text  + '</span>';
	if (OPT.Button_Small !== '') OPT.Button_Small = '<small>' + OPT.Button_Small + '</small>';
	if (OPT.Icon         !== '')
	{
		OPT.Icon = '<b><i class="' + ICONS_TYPE +' ' + OPT.Icon + '"';
		
		if (OPT.Button_Line_Height !== '' || OPT.Font_Size !== '')
		{
			OPT.Icon += 'style="';
		
			if (OPT.Button_Line_Height !== '')
				OPT.Icon += 'line-height:' + OPT.Button_Line_Height + ';';
	
			if (OPT.Font_Size !== '')
				OPT.Icon += 'font-size:' + OPT.Font_Size + ';';
				
			OPT.Icon += '"';
		}
	
		OPT.Icon += '></i></b>';
	}

	if (OPT.Icon_Placement === "Only") Str_HTML += OPT.Icon;
	else
	{
		if (OPT.Icon_Placement  === "Left") Str_HTML += OPT.Icon;
		if (OPT.Small_Placement === "Left") Str_HTML += OPT.Button_Small;

		Str_HTML += Button_Text;

		if (OPT.Small_Placement === "Right") Str_HTML += OPT.Button_Small;
		if (OPT.Icon_Placement  === "Right") Str_HTML += OPT.Icon;
	}
	
	Str_HTML += '</a>';
	
	// Preview
	$("#Code-Text-Shortcode").val(Str_Code);
	$("#Code-Text-HTML"     ).val(Str_HTML);
	$("#Code-Text-PHP"      ).val(Str_PHP );
	
	$("#Preview-Box").html(Str_HTML);
	
	$("#Preview-Box a").click(function(e){ e.preventDefault() });
};

//**********************************************************
//   APP >> Shortcode Paramter
// PARAM >> String | Name
// PARAM >> String | Value
// NOTES >> Sanatizes string and returns prepared param.
//**********************************************************
APP.Shortcode_Parameter = function(Name, Value)
{
	if (Name === '' || Value === '' || Value === undefined || ! Value) return '';
	
	if (Name === "opacity")
	{
		if (Value === "100") return '';
	}
	else if (Name === "custom_border_style")
	{
		if (Value === "Default") return '';
	}
	else if (Name === "custom_border_width"){}
	else
	{	
		if (Value === "None"    ) return '';
		if (Value === "Default" ) return '';
		if (Value === "0"       ) return '';
		if (Value === "Disabled") return '';
	}
	
	Value = Value.replace(/"/g, '&#34;');
	
	return ' ' + Name + '="' + Value + '"';
}

//**********************************************************
//   APP >> PHP Paramter
// PARAM >> String | Name
// PARAM >> String | Value
// NOTES >> Sanatizes string and returns prepared param.
//**********************************************************
APP.PHP_Parameter = function(Name, Value)
{
	if (Name === '' || Value === '' || Value === undefined || ! Value) return '';

	if (Name === "opacity")
	{
		if (Value === "100") return '';
	}
	else if (Name === "custom_border_style")
	{
		if (Value === "Default") return '';
	}
	else if (Name === "custom_border_width"){}
	else
	{	
		if (Value === "None"    ) return '';
		if (Value === "Default" ) return '';
		if (Value === "0"       ) return '';
		if (Value === "Disabled") return '';
	}

	Value = Value.replace(/"/g, '&#34;');

	return ' "' + Name + '"=>"' + Value + '",';
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
//   APP >> Build: Reset
// PARAM >> String | Type
//**********************************************************
APP.Build_Reset = function(Type)
{
	if (Type === "All")
	{
		Reset_Details();
		Reset_Styles();
		Reset_Custom();
		Reset_Icons();
	}
	else if (Type === "Details") Reset_Details();
	else if (Type === "Styles")  Reset_Styles();
	else if (Type === "Custom")  Reset_Custom();
	else if (Type === "Icons")   Reset_Icons();

	function Reset_Details()
	{
		$("#OPT-Link-Address").val('');
		$("#OPT-Link-Target" ).val('');
		$("#OPT-Link-Title"  ).val('');
		$("#OPT-Link-Rel"    ).val('');
		$("#OPT-Custom-ID"   ).val('');
		$("#OPT-Custom-Class").val('');
		$("#OPT-Button-Text" ).val('');
		$("#OPT-Button-Small").val('');
	}

	function Reset_Styles()
	{
		$("#OPT-Button-Size"      ).val("XS");
		$("#OPT-Button-Color"     ).val("Light");
		$("#OPT-Text-Color"       ).val("Default");
		$("#OPT-Button-Style"     ).val("Default");
		$("#OPT-Button-Style-Icon").val("None");
		$("#OPT-Button-Style-3D"  ).val("None");
		$("#OPT-Button-Hover"     ).val("None");
		$("#OPT-Animate-Icon"     ).val("None");
		$("#OPT-Animate-Button"   ).val("None");
		$("#OPT-Transitions"      ).val("Disabled");

		APP.Slider_Set({Name: "Rounded-Corners", Value: 3   });
		APP.Slider_Set({Name: "Box-Shadow",      Value: 0   });
		APP.Slider_Set({Name: "Text-Shadow",     Value: 0   });
		APP.Slider_Set({Name: "Opacity",         Value: 100 });
		APP.Slider_Set({Name: "Opacity-Hover",   Value: 100 });
	}
	
	function Reset_Custom()
	{
		$("#OPT-Font-Family"        ).val('');
		$("#OPT-Font-Size"          ).val('');
		$("#OPT-Icon-Placement"     ).val("Left");
		$("#OPT-Small-Placement"    ).val("None");
		$("#OPT-Button-Float"       ).val("None");
		$("#OPT-Button-Width"       ).val('');
		$("#OPT-Button-Height"      ).val('');
		$("#OPT-Button-Line-Height" ).val('');
		$("#OPT-Custom-Border-Style").val("Default");
		
		$("#OPT-Custom-Text-Toggle").val("Disabled");
		$("#OPT-Custom-Text-Color" ).val('');
		APP.Text_Color();

		$("#OPT-Custom-BG-Toggle").val("Disabled");
		$("#OPT-Custom-BG-Color" ).val('');
		APP.Background_Color();
		
		$("#OPT-Custom-Border-Toggle").val("Disabled");
		$("#OPT-Custom-Border-Color" ).val('');
		APP.Border_Color();
		
		$("#OPT-Custom-BorderW-Toggle").val("Disabled");
		APP.Slider_Set({Name: "Custom-BorderW", Value: 1 });
		APP.Border_Width();
	}

	function Reset_Icons()
	{
		APP.Icons_Selected = undefined;
		APP.Icons_Reset();
	}

	APP.Build();
};

//**********************************************************
//   APP >> Build: Sample
// PARAM >> String | Type
//**********************************************************
APP.Build_Sample = function(Type)
{
	APP.Build_Reset("All");
	var Str = '';

	if (Type === "Add-to-Cart")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-MD FLMBTN-Color-Green FLMBTN-BR-5 FLMBTN-Icon-Right FLMBTN-Lines-Right FLMBTN-D3">';
		Str += '<span>Add to Cart</span><i class="fa fa-shopping-cart"></i></a>';
	}
	else if (Type === "Facebook")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-SM FLMBTN-Color-Blue FLMBTN-BR-3 FLMBTN-BS-3 FLMBTN-Mask-Left FLMBTN-Anim-Grow FLMBTN-Flat-Blue">';
		Str += '<i class="fa fa-facebook"></i><span>Facebook</span></a>';
	}
	else if (Type === "Tweet-This")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-XS FLMBTN-Color-Light FLMBTN-BR-3 FLMBTN-Hover-Blue FLMBTN-AnIco-Rotate-360 FLMBTN-Flat-Light FLMBTN-Text-Blue">';
		Str += '<i class="fa fa-twitter"></i><span>Tweet This!</span></a>';
	}
	else if (Type === "Read-More")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-MD FLMBTN-Color-Dark FLMBTN-BR-3 FLMBTN-BS-4 FLMBTN-Icon-Right FLMBTN-Small-Left FLMBTN-Mask-Right" style="color:#fffe00;">';
		Str += '<small>Next</small><span>Read More</span><i class="fa fa-arrow-right"></i></a>';
	}
	else if (Type === "Google-Plus")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-XS FLMBTN-Color-Red FLMBTN-BR-3 FLMBTN-Lines-Left FLMBTN-HoverB-Red FLMBTN-Engrave">';
		Str += '<i class="fa fa-google-plus-square"></i><span>Google+</span></a>';
	}
	else if (Type === "Order-Now")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-LG FLMBTN-Color-Orange FLMBTN-BR-25 FLMBTN-Icon-Right FLMBTN-Hover-Orange">';
		Str += '<span>Order Now</span><i class="fa fa-chevron-right"></i></a>';
	}
	else if (Type === "GitHub")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-SM FLMBTN-Color-Light FLMBTN-BR-3 FLMBTN-Hover-Dark FLMBTN-Outline-Light">';
		Str += '<i class="fa fa-github-square"></i><span>Fork on GitHub</span></a>';
	}
	else if (Type === "Top")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-XS FLMBTN-Color-Light FLMBTN-BR-25 FLMBTN-Icon-Only FLMBTN-Hover-Light FLMBTN-Flat-Light">';
		Str += '<i class="fa fa-arrow-circle-up"></i></a>';
	}
	else if (Type === "Play-Video")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-MD FLMBTN-Color-Tan FLMBTN-BR-3 FLMBTN-Icon-Right FLMBTN-Lines-Right FLMBTN-D3 FLMBTN-Engrave">';
		Str += '<span>Play Video</span><i class="fa fa-youtube-play"></i></a>';
	}
	else if (Type === "Previous")
	{
		Str += '<a href="#" class="FLMBTN-Btn FLMBTN-Size-LG FLMBTN-Color-Purple FLMBTN-BR-10 FLMBTN-TS-5 FLMBTN-Icon-Only FLMBTN-HoverB-Purple FLMBTN-Flat-Purple">';
		Str += '<i class="fa fa-chevron-left"></i></a>';
	}

	$("#Import-Box").val(Str);
	APP.Import();	
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//*************************************************************
// APP >> Import
//*************************************************************
APP.Import = function()
{
	// Check For Blank
	if ($("#Import-Box").val() == '')
	{
		$("#Import-Box").focus();
		return;
	}
	
	// Reset
	APP.Build_Reset("All");
	
	// Get Input
	var Input = $("#Import-Box").val();
	
	// Check Input
	if (Input.indexOf("<a href=") > -1)
		APP.Import_HTML(Input);
	else if (Input.indexOf("[flm_button") > -1)
		APP.Import_Shortcode(Input);
	else if (Input.indexOf("<?php FLMBTN_Build(") > -1)
		APP.Import_PHP(Input);
	
	$("#Import-Box").val('');
	APP.Build();
};

//*************************************************************
//   APP >> Import: HTML
// PARAM >> String | Input
//*************************************************************
APP.Import_HTML = function(Input)
{
	var Prefix = "FLMBTN-";
	var Check  = false;
	var Temp   = '';
	var OPT    = {};

	// Create Workspace
	$("#Import-Space").html(Input);

	// General Element Calls
	OPT.Classes = String($("#Import-Space a").prop("class"));
	OPT.Styles  = $("#Import-Space a").prop("style");
	
	// Details - Link Address
	OPT.Link_Address = Input.Search('href="', '"');
	$("#OPT-Link-Address").val(OPT.Link_Address);
	
	// Details - Link Target
	OPT.Link_Target = String($("#Import-Space a").prop("target"));
	$("#OPT-Link-Target").val(OPT.Link_Target);
	
	// Details - Link Title
	OPT.Link_Title = String($("#Import-Space a").prop("title"));
	$("#OPT-Link-Title").val(OPT.Link_Title);
	
	// Details - Link Rel
	OPT.Link_Rel = String($("#Import-Space a").prop("rel"));
	$("#OPT-Link-Rel").val(OPT.Link_Rel);
	
	// Details - Custom ID
	OPT.Custom_ID = String($("#Import-Space a").prop("id"));
	$("#OPT-Custom-ID").val(OPT.Custom_ID);
	
	// Details - Custom Class
	Temp = OPT.Classes.split(" ");
	for (var i = 0; i < Temp.length; i++)
	{
		if (Temp[i].indexOf(Prefix) <= -1)
		{
			OPT.Custom_Class = Temp[i];
			break;
		}
	}
	if (OPT.Custom_Class !== '')
		$("#OPT-Custom-Class").val(OPT.Custom_Class);
		
	// Details - Button Text
	if (Input.indexOf("<span>") > -1) $("#OPT-Button-Text").val($("#Import-Space span").html());
	
	// Details - Small Text
	if (Input.indexOf("<small>") > -1) $("#OPT-Button-Small").val($("#Import-Space small").html());
	
	// Styles - Button Size
		 if (OPT.Classes.indexOf(Prefix + "Size-XS") > -1) $("#OPT-Button-Size").val("XS");
	else if (OPT.Classes.indexOf(Prefix + "Size-SM") > -1) $("#OPT-Button-Size").val("SM");
	else if (OPT.Classes.indexOf(Prefix + "Size-MD") > -1) $("#OPT-Button-Size").val("MD");
	else if (OPT.Classes.indexOf(Prefix + "Size-LG") > -1) $("#OPT-Button-Size").val("LG");
	
	// Styles - Button Color
		 if (OPT.Classes.indexOf("Color-Light")  > -1) OPT.Button_Color = "Light";
	else if (OPT.Classes.indexOf("Color-Tan")    > -1) OPT.Button_Color = "Tan";
	else if (OPT.Classes.indexOf("Color-Dark")   > -1) OPT.Button_Color = "Dark";
	else if (OPT.Classes.indexOf("Color-Blue")   > -1) OPT.Button_Color = "Blue";
	else if (OPT.Classes.indexOf("Color-Green")  > -1) OPT.Button_Color = "Green";
	else if (OPT.Classes.indexOf("Color-Red")    > -1) OPT.Button_Color = "Red";
	else if (OPT.Classes.indexOf("Color-Orange") > -1) OPT.Button_Color = "Orange";
	else if (OPT.Classes.indexOf("Color-Yellow") > -1) OPT.Button_Color = "Yellow";
	else if (OPT.Classes.indexOf("Color-Pink")   > -1) OPT.Button_Color = "Pink";
	else if (OPT.Classes.indexOf("Color-Purple") > -1) OPT.Button_Color = "Purple";
	else if (OPT.Classes.indexOf("Color-Black")  > -1) OPT.Button_Color = "Black";
	else if (OPT.Classes.indexOf("Color-White")  > -1) OPT.Button_Color = "White";
	
	$("#OPT-Button-Color").val(OPT.Button_Color);
	
	// Styles - Text Color
		 if (OPT.Classes.indexOf(Prefix + "Engrave")     > -1) OPT.Text_Color = "Engrave";
	else if (OPT.Classes.indexOf(Prefix + "Text-Light")  > -1) OPT.Text_Color = "Light";
	else if (OPT.Classes.indexOf(Prefix + "Text-Tan")    > -1) OPT.Text_Color = "Tan";
	else if (OPT.Classes.indexOf(Prefix + "Text-Dark")   > -1) OPT.Text_Color = "Dark";
	else if (OPT.Classes.indexOf(Prefix + "Text-Blue")   > -1) OPT.Text_Color = "Blue";
	else if (OPT.Classes.indexOf(Prefix + "Text-Green")  > -1) OPT.Text_Color = "Green";
	else if (OPT.Classes.indexOf(Prefix + "Text-Red")    > -1) OPT.Text_Color = "Red";
	else if (OPT.Classes.indexOf(Prefix + "Text-Orange") > -1) OPT.Text_Color = "Orange";
	else if (OPT.Classes.indexOf(Prefix + "Text-Yellow") > -1) OPT.Text_Color = "Yellow";
	else if (OPT.Classes.indexOf(Prefix + "Text-Pink")   > -1) OPT.Text_Color = "Pink";
	else if (OPT.Classes.indexOf(Prefix + "Text-Purple") > -1) OPT.Text_Color = "Purple";
	else if (OPT.Classes.indexOf(Prefix + "Text-Black")  > -1) OPT.Text_Color = "Black";
	else if (OPT.Classes.indexOf(Prefix + "Text-White")  > -1) OPT.Text_Color = "White";
	else OPT.Text_Color = "Default";
	
	$("#OPT-Text-Color").val(OPT.Text_Color);
	
	// Styles - Button Style
		 if (OPT.Classes.indexOf(Prefix + "Flat-")    > -1) OPT.Button_Style = "Flat";
	else if (OPT.Classes.indexOf(Prefix + "Border-")  > -1) OPT.Button_Style = "Border";
	else if (OPT.Classes.indexOf(Prefix + "Outline-") > -1) OPT.Button_Style = "Outline";
	else OPT.Button_Style = "Default";

	$("#OPT-Button-Style").val(OPT.Button_Style);
	
	// Styles - Button Style Icon
		 if (OPT.Classes.indexOf(Prefix + "Lines-Left")  > -1) OPT.Button_Style_Icon = "Lines-Left";
	else if (OPT.Classes.indexOf(Prefix + "Lines-Right") > -1) OPT.Button_Style_Icon = "Lines-Right";
	else if (OPT.Classes.indexOf(Prefix + "Mask-Left")   > -1) OPT.Button_Style_Icon = "Mask-Left";
	else if (OPT.Classes.indexOf(Prefix + "Mask-Right")  > -1) OPT.Button_Style_Icon = "Mask-Right";
	else OPT.Button_Style_Icon = "None";

	$("#OPT-Button-Style-Icon").val(OPT.Button_Style_Icon);
	
	// Styles - Button Style 3D
		 if (OPT.Classes.indexOf(Prefix + "D3-Large") > -1) OPT.Button_Style_3D = "D3-Large";
	else if (OPT.Classes.indexOf(Prefix + "D3")       > -1) OPT.Button_Style_3D = "D3";
	else OPT.Button_Style_3D = "None";

	$("#OPT-Button-Style-3D").val(OPT.Button_Style_3D);
	
	// Styles - Button Hover
		 if (OPT.Classes.indexOf(Prefix + "Hover-Light")   > -1) OPT.Button_Hover = "Hover-Light";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Tan")     > -1) OPT.Button_Hover = "Hover-Tan";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Dark")    > -1) OPT.Button_Hover = "Hover-Dark";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Blue")    > -1) OPT.Button_Hover = "Hover-Blue";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Green")   > -1) OPT.Button_Hover = "Hover-Green";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Red")     > -1) OPT.Button_Hover = "Hover-Red";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Orange")  > -1) OPT.Button_Hover = "Hover-Orange";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Yellow")  > -1) OPT.Button_Hover = "Hover-Yellow";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Pink")    > -1) OPT.Button_Hover = "Hover-Pink";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Purple")  > -1) OPT.Button_Hover = "Hover-Purple";
	else if (OPT.Classes.indexOf(Prefix + "Hover-Black")   > -1) OPT.Button_Hover = "Hover-Black";
	else if (OPT.Classes.indexOf(Prefix + "Hover-White")   > -1) OPT.Button_Hover = "Hover-White";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Light")  > -1) OPT.Button_Hover = "HoverB-Light";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Tan")    > -1) OPT.Button_Hover = "HoverB-Tan";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Dark")   > -1) OPT.Button_Hover = "HoverB-Dark";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Blue")   > -1) OPT.Button_Hover = "HoverB-Blue";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Green")  > -1) OPT.Button_Hover = "HoverB-Green";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Red")    > -1) OPT.Button_Hover = "HoverB-Red";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Orange") > -1) OPT.Button_Hover = "HoverB-Orange";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Yellow") > -1) OPT.Button_Hover = "HoverB-Yellow";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Pink")   > -1) OPT.Button_Hover = "HoverB-Pink";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Purple") > -1) OPT.Button_Hover = "HoverB-Purple";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-Black")  > -1) OPT.Button_Hover = "HoverB-Black";
	else if (OPT.Classes.indexOf(Prefix + "HoverB-White")  > -1) OPT.Button_Hover = "HoverB-White";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Light")  > -1) OPT.Button_Hover = "HoverF-Light";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Tan")    > -1) OPT.Button_Hover = "HoverF-Tan";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Dark")   > -1) OPT.Button_Hover = "HoverF-Dark";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Blue")   > -1) OPT.Button_Hover = "HoverF-Blue";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Green")  > -1) OPT.Button_Hover = "HoverF-Green";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Red")    > -1) OPT.Button_Hover = "HoverF-Red";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Orange") > -1) OPT.Button_Hover = "HoverF-Orange";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Yellow") > -1) OPT.Button_Hover = "HoverF-Yellow";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Pink")   > -1) OPT.Button_Hover = "HoverF-Pink";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Purple") > -1) OPT.Button_Hover = "HoverF-Purple";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-Black")  > -1) OPT.Button_Hover = "HoverF-Black";
	else if (OPT.Classes.indexOf(Prefix + "HoverF-White")  > -1) OPT.Button_Hover = "HoverF-White";
	else OPT.Button_Hover = "None";

	$("#OPT-Button-Hover").val(OPT.Button_Hover);
	
	// Styles - Rounded Corners
			 OPT.Rounded_Corners = 0;
		 if (OPT.Classes.indexOf(Prefix + "BR-25") > -1) OPT.Rounded_Corners = 25;
	else if (OPT.Classes.indexOf(Prefix + "BR-24") > -1) OPT.Rounded_Corners = 24;
	else if (OPT.Classes.indexOf(Prefix + "BR-23") > -1) OPT.Rounded_Corners = 23;
	else if (OPT.Classes.indexOf(Prefix + "BR-22") > -1) OPT.Rounded_Corners = 22;
	else if (OPT.Classes.indexOf(Prefix + "BR-21") > -1) OPT.Rounded_Corners = 21;
	else if (OPT.Classes.indexOf(Prefix + "BR-20") > -1) OPT.Rounded_Corners = 20;
	else if (OPT.Classes.indexOf(Prefix + "BR-19") > -1) OPT.Rounded_Corners = 19;
	else if (OPT.Classes.indexOf(Prefix + "BR-18") > -1) OPT.Rounded_Corners = 18;
	else if (OPT.Classes.indexOf(Prefix + "BR-17") > -1) OPT.Rounded_Corners = 17;
	else if (OPT.Classes.indexOf(Prefix + "BR-16") > -1) OPT.Rounded_Corners = 16;
	else if (OPT.Classes.indexOf(Prefix + "BR-15") > -1) OPT.Rounded_Corners = 15;
	else if (OPT.Classes.indexOf(Prefix + "BR-14") > -1) OPT.Rounded_Corners = 14;
	else if (OPT.Classes.indexOf(Prefix + "BR-13") > -1) OPT.Rounded_Corners = 13;
	else if (OPT.Classes.indexOf(Prefix + "BR-12") > -1) OPT.Rounded_Corners = 12;
	else if (OPT.Classes.indexOf(Prefix + "BR-11") > -1) OPT.Rounded_Corners = 11;
	else if (OPT.Classes.indexOf(Prefix + "BR-10") > -1) OPT.Rounded_Corners = 10;
	else if (OPT.Classes.indexOf(Prefix + "BR-9")  > -1) OPT.Rounded_Corners = 9;
	else if (OPT.Classes.indexOf(Prefix + "BR-8")  > -1) OPT.Rounded_Corners = 8;
	else if (OPT.Classes.indexOf(Prefix + "BR-7")  > -1) OPT.Rounded_Corners = 7;
	else if (OPT.Classes.indexOf(Prefix + "BR-6")  > -1) OPT.Rounded_Corners = 6;
	else if (OPT.Classes.indexOf(Prefix + "BR-5")  > -1) OPT.Rounded_Corners = 5;
	else if (OPT.Classes.indexOf(Prefix + "BR-4")  > -1) OPT.Rounded_Corners = 4;
	else if (OPT.Classes.indexOf(Prefix + "BR-3")  > -1) OPT.Rounded_Corners = 3;
	else if (OPT.Classes.indexOf(Prefix + "BR-2")  > -1) OPT.Rounded_Corners = 2;
	else if (OPT.Classes.indexOf(Prefix + "BR-1")  > -1) OPT.Rounded_Corners = 1;
	
	APP.Slider_Set({Name: "Rounded-Corners", Value: OPT.Rounded_Corners });
	
	// Styles - Box Shadow
			 OPT.Box_Shadow = 0;
		 if (OPT.Classes.indexOf(Prefix + "BS-10") > -1) OPT.Box_Shadow = 10;
	else if (OPT.Classes.indexOf(Prefix + "BS-9")  > -1) OPT.Box_Shadow = 9;
	else if (OPT.Classes.indexOf(Prefix + "BS-8")  > -1) OPT.Box_Shadow = 8;
	else if (OPT.Classes.indexOf(Prefix + "BS-7")  > -1) OPT.Box_Shadow = 7;
	else if (OPT.Classes.indexOf(Prefix + "BS-6")  > -1) OPT.Box_Shadow = 6;
	else if (OPT.Classes.indexOf(Prefix + "BS-5")  > -1) OPT.Box_Shadow = 5;
	else if (OPT.Classes.indexOf(Prefix + "BS-4")  > -1) OPT.Box_Shadow = 4;
	else if (OPT.Classes.indexOf(Prefix + "BS-3")  > -1) OPT.Box_Shadow = 3;
	else if (OPT.Classes.indexOf(Prefix + "BS-2")  > -1) OPT.Box_Shadow = 2;
	else if (OPT.Classes.indexOf(Prefix + "BS-1")  > -1) OPT.Box_Shadow = 1;

	APP.Slider_Set({Name: "Box-Shadow", Value: OPT.Box_Shadow });
	
	// Styles - Text Shadow
				 OPT.Text_Shadow = 0;
		 if (OPT.Classes.indexOf(Prefix + "TS-10") > -1) OPT.Text_Shadow = 10;
	else if (OPT.Classes.indexOf(Prefix + "TS-9")  > -1) OPT.Text_Shadow = 9;
	else if (OPT.Classes.indexOf(Prefix + "TS-8")  > -1) OPT.Text_Shadow = 8;
	else if (OPT.Classes.indexOf(Prefix + "TS-7")  > -1) OPT.Text_Shadow = 7;
	else if (OPT.Classes.indexOf(Prefix + "TS-6")  > -1) OPT.Text_Shadow = 6;
	else if (OPT.Classes.indexOf(Prefix + "TS-5")  > -1) OPT.Text_Shadow = 5;
	else if (OPT.Classes.indexOf(Prefix + "TS-4")  > -1) OPT.Text_Shadow = 4;
	else if (OPT.Classes.indexOf(Prefix + "TS-3")  > -1) OPT.Text_Shadow = 3;
	else if (OPT.Classes.indexOf(Prefix + "TS-2")  > -1) OPT.Text_Shadow = 2;
	else if (OPT.Classes.indexOf(Prefix + "TS-1")  > -1) OPT.Text_Shadow = 1;

	APP.Slider_Set({Name: "Text-Shadow", Value: OPT.Text_Shadow });
	
	// Styles - Opacity
	OPT.Opacity = 100;
	
		 if (OPT.Classes.indexOf(Prefix + "OP-90") > -1) OPT.Opacity = 90;
	else if (OPT.Classes.indexOf(Prefix + "OP-80") > -1) OPT.Opacity = 80;
	else if (OPT.Classes.indexOf(Prefix + "OP-70") > -1) OPT.Opacity = 70;
	else if (OPT.Classes.indexOf(Prefix + "OP-60") > -1) OPT.Opacity = 60;
	else if (OPT.Classes.indexOf(Prefix + "OP-50") > -1) OPT.Opacity = 50;
	else if (OPT.Classes.indexOf(Prefix + "OP-40") > -1) OPT.Opacity = 40;
	else if (OPT.Classes.indexOf(Prefix + "OP-30") > -1) OPT.Opacity = 30;
	else if (OPT.Classes.indexOf(Prefix + "OP-20") > -1) OPT.Opacity = 20;
	else if (OPT.Classes.indexOf(Prefix + "OP-30") > -1) OPT.Opacity = 30;
	else if (OPT.Classes.indexOf(Prefix + "OP-20") > -1) OPT.Opacity = 20;
	else if (OPT.Classes.indexOf(Prefix + "OP-10") > -1) OPT.Opacity = 10;
	else if (OPT.Classes.indexOf(Prefix + "OP-0")  > -1) OPT.Opacity = 0;

	APP.Slider_Set({Name: "Opacity", Value: OPT.Opacity });
	
	// Styles - Opacity Hover
	OPT.Opacity_Hover = 100;
	
		 if (OPT.Classes.indexOf(Prefix + "OH-90") > -1) OPT.Opacity_Hover = 90;
	else if (OPT.Classes.indexOf(Prefix + "OH-80") > -1) OPT.Opacity_Hover = 80;
	else if (OPT.Classes.indexOf(Prefix + "OH-70") > -1) OPT.Opacity_Hover = 70;
	else if (OPT.Classes.indexOf(Prefix + "OH-60") > -1) OPT.Opacity_Hover = 60;
	else if (OPT.Classes.indexOf(Prefix + "OH-50") > -1) OPT.Opacity_Hover = 50;
	else if (OPT.Classes.indexOf(Prefix + "OH-40") > -1) OPT.Opacity_Hover = 40;
	else if (OPT.Classes.indexOf(Prefix + "OH-30") > -1) OPT.Opacity_Hover = 30;
	else if (OPT.Classes.indexOf(Prefix + "OH-20") > -1) OPT.Opacity_Hover = 20;
	else if (OPT.Classes.indexOf(Prefix + "OH-30") > -1) OPT.Opacity_Hover = 30;
	else if (OPT.Classes.indexOf(Prefix + "OH-20") > -1) OPT.Opacity_Hover = 20;
	else if (OPT.Classes.indexOf(Prefix + "OH-10") > -1) OPT.Opacity_Hover = 10;
	else if (OPT.Classes.indexOf(Prefix + "OH-0")  > -1) OPT.Opacity_Hover = 0;

	APP.Slider_Set({Name: "Opacity-Hover", Value: OPT.Opacity_Hover });
	
	// Styles - Animate Icon
		 if (OPT.Classes.indexOf(Prefix + "AnIco-Rotate-90")  > -1) OPT.Animate_Icon = "Rotate-90";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Rotate-180") > -1) OPT.Animate_Icon = "Rotate-180";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Rotate-360") > -1) OPT.Animate_Icon = "Rotate-360";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Zoom")       > -1) OPT.Animate_Icon = "Zoom";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Loop")       > -1) OPT.Animate_Icon = "Loop";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Grow")       > -1) OPT.Animate_Icon = "Grow";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Shrink")     > -1) OPT.Animate_Icon = "Shrink";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Skew")       > -1) OPT.Animate_Icon = "Skew";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Flip-LR")    > -1) OPT.Animate_Icon = "Flip-LR";
	else if (OPT.Classes.indexOf(Prefix + "AnIco-Flip-TB")    > -1) OPT.Animate_Icon = "Flip-TB";
	else OPT.Animate_Icon = "None";

	$("#OPT-Animate-Icon").val(OPT.Animate_Icon);
	
	// Styles - Animate Button
		 if (OPT.Classes.indexOf(Prefix + "Anim-Rotate")  > -1) OPT.Animate_Button = "Rotate";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Zoom")    > -1) OPT.Animate_Button = "Zoom";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Grow")    > -1) OPT.Animate_Button = "Grow";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Shrink")  > -1) OPT.Animate_Button = "Shrink";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Flip-LR") > -1) OPT.Animate_Button = "Flip-LR";
	else if (OPT.Classes.indexOf(Prefix + "Anim-Flip-TB") > -1) OPT.Animate_Button = "Flip-TB";
	else OPT.Animate_Button = "None";

	$("#OPT-Animate-Button").val(OPT.Animate_Button);
	
	// Styles - Transitions
	if (OPT.Classes.indexOf(Prefix + "Trans")  > -1)
		$("#OPT-Transitions").val("Enabled");
	else
		$("#OPT-Transitions").val("Disabled");
		
	// Customize - Font Family
	OPT.Font_Family = '';
	
		 if (OPT.Classes.indexOf(Prefix + "Font-Arial")           > -1) OPT.Font_Family = "[CLASS-Arial]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Arial-Black")     > -1) OPT.Font_Family = "[CLASS-Arial-Black]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Comic-Sans-MS")   > -1) OPT.Font_Family = "[CLASS-Comic-Sans-MS]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Impact")          > -1) OPT.Font_Family = "[CLASS-Impact]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Lucida-Sans")     > -1) OPT.Font_Family = "[CLASS-Lucida-Sans]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Tahoma")          > -1) OPT.Font_Family = "[CLASS-Tahoma]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Trebuchet-MS")    > -1) OPT.Font_Family = "[CLASS-Trebuchet-MS]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Verdana")         > -1) OPT.Font_Family = "[CLASS-Verdana]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Book-Antiqua")    > -1) OPT.Font_Family = "[CLASS-Book-Antiqua]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Georgia")         > -1) OPT.Font_Family = "[CLASS-Georgia]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Times-New-Roman") > -1) OPT.Font_Family = "[CLASS-Times-New-Roman]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Courier-New")     > -1) OPT.Font_Family = "[CLASS-Courier-New]";
	else if (OPT.Classes.indexOf(Prefix + "Font-Lucida-Console")  > -1) OPT.Font_Family = "[CLASS-Lucida-Console]";
	
	if (OPT.Font_Family === '' && OPT.Styles.fontFamily !== '')
		OPT.Font_Family = String(OPT.Styles.fontFamily);
		
	$("#OPT-Font-Family").val(OPT.Font_Family);
	
	// Customize - Font Size
	if (OPT.Styles.fontSize !== '')
		$("#OPT-Font-Size").val(OPT.Styles.fontSize);
		
	// Customize - Icon Placement
	if (Input.indexOf("<i") > -1)
	{
			 if (OPT.Classes.indexOf(Prefix + "Icon-Right") > -1) $("#OPT-Icon-Placement").val("Right");
		else if (OPT.Classes.indexOf(Prefix + "Icon-Only")  > -1) $("#OPT-Icon-Placement").val("Only");

		// Select Icon
		OPT.Icon = $("#Import-Space i").prop("class");
		OPT.Icon = OPT.Icon.replace(ICONS_TYPE, '').replace(/ /g, '');
		APP.Icons_Select(OPT.Icon);
	}
	
	// Customize - Small Placement
	if (Input.indexOf("<small>") > -1)
	{
		if (OPT.Classes.indexOf(Prefix + "Small-Left") > -1) $("#OPT-Small-Placement").val("Left");
		else $("#OPT-Small-Placement").val("Right");
	}
	
	// Customize - Text Only
	if (OPT.Classes.indexOf(Prefix + "Text-Only") > -1)
	{
		$("#OPT-Icon-Placement").val("None");
		$("#OPT-Small-Placement").val("None");
	}
	
	// Customize - Button Float
		 if (Input.indexOf("float:left;")  > -1) $("#OPT-Button-Float").val("Left");
	else if (Input.indexOf("float:right;") > -1) $("#OPT-Button-Float").val("Right");
	
	// Customize - Button Width
	if (OPT.Styles.width !== '')
		$("#OPT-Button-Width").val(OPT.Styles.width);
		
	// Customize - Button Height
	if (OPT.Styles.height !== '')
		$("#OPT-Button-Height").val(OPT.Styles.height);
		
	// Customize - Button Line Height
	if (OPT.Styles.lineHeight !== '')
		$("#OPT-Button-Line-Height").val(OPT.Styles.lineHeight);
		
	// Customize - Custom Text Color
	if (Input.indexOf("color:#") > -1)
	{
		$("#OPT-Custom-Text-Toggle").val("Enabled");
		$("#OPT-Custom-Text-Color" ).val(Input.Search("color:#", ";"));
		APP.Text_Color();
	}
	
	// Customize - Custom Background Color
	if (Input.indexOf("background:#") > -1)
	{
		$("#OPT-Custom-BG-Toggle").val("Enabled");
		$("#OPT-Custom-BG-Color" ).val(Input.Search("background:#", ";"));
		APP.Background_Color();
	}
	
	// Customize - Custom Border Color
	if (Input.indexOf("border-color:#") > -1)
	{
		$("#OPT-Custom-Border-Toggle").val("Enabled");
		$("#OPT-Custom-Border-Color" ).val(Input.Search("border-color:#", ";"));
		APP.Border_Color();
	}
	
	// Customize - Custom Border Width
	if (OPT.Styles.borderWidth !== '')
	{
		$("#OPT-Custom-BorderW-Toggle").val("Enabled");
		APP.Border_Width();
		OPT.Border_Width = OPT.Styles.borderWidth.replace("px", '');
		APP.Slider_Set({Name: "Custom-BorderW", Value: OPT.Border_Width });
	}
	
	// Customize - Custom Border Style	
		 if (OPT.Classes.indexOf(Prefix + "Border-None") > -1) OPT.Border_Style = "None";
	else if (OPT.Classes.indexOf(Prefix + "Border-Dashed")      > -1) OPT.Border_Style = "Dashed";
	else if (OPT.Classes.indexOf(Prefix + "Border-Dotted")      > -1) OPT.Border_Style = "Dotted";
	else if (OPT.Classes.indexOf(Prefix + "Border-Double")      > -1) OPT.Border_Style = "Double";
	else if (OPT.Classes.indexOf(Prefix + "Border-Groove")      > -1) OPT.Border_Style = "Groove";
	else if (OPT.Classes.indexOf(Prefix + "Border-Inset")       > -1) OPT.Border_Style = "Inset";
	else if (OPT.Classes.indexOf(Prefix + "Border-Outset")      > -1) OPT.Border_Style = "Outset";
	else if (OPT.Classes.indexOf(Prefix + "Border-Ridge")       > -1) OPT.Border_Style = "Ridge";
	else if (OPT.Classes.indexOf(Prefix + "Border-Solid")       > -1) OPT.Border_Style = "Solid";
	else OPT.Border_Style = "Default";
	
	$("#OPT-Custom-Border-Style").val(OPT.Border_Style);
};

//*************************************************************
//   APP >> Import: Shortcode
// PARAM >> String | Input
//*************************************************************
APP.Import_Shortcode = function(Input)
{
	var Args = [];
	var Params = Input.match(/[\w-]+="[^"]*"/g);
   
	for (var i = 0; i < Params.length; i++)
	{
		var Temp = Params[i].split(/=(.+)?/);
			Temp[1] = Temp[1].slice(1);
			Temp[1] = Temp[1].slice(0, -1);
	
		Args[Temp[0]] = Temp[1];
	}
	
	// Section - Details
	Shortcode_Value(Args, "link_address", '', "OPT-Link-Address");
	Shortcode_Value(Args, "link_target",  '', "OPT-Link-Target");
	Shortcode_Value(Args, "link_title",   '', "OPT-Link-Title");
	Shortcode_Value(Args, "link_rel",     '', "OPT-Link-Rel");
	Shortcode_Value(Args, "custom_id",    '', "OPT-Custom-ID");
	Shortcode_Value(Args, "custom_class", '', "OPT-Custom-Class");
	Shortcode_Value(Args, "button_text",  '', "OPT-Button-Text");
	Shortcode_Value(Args, "button_small", '', "OPT-Button-Small");
	
	// Section - Styles
	Shortcode_Value(Args, "button_size",       "XS",       "OPT-Button-Size");
	Shortcode_Value(Args, "button_color",      "Light",    "OPT-Button-Color");
	Shortcode_Value(Args, "text_color",        "Default",  "OPT-Text-Color");
	Shortcode_Value(Args, "button_style",      "Default",  "OPT-Button-Style");
	Shortcode_Value(Args, "button_style_icon", "None",     "OPT-Button-Style-Icon");
	Shortcode_Value(Args, "button_style_3d",   "None",     "OPT-Button-Style-3D");
	Shortcode_Value(Args, "button_hover",      "None",     "OPT-Button-Hover");
	Shortcode_Value(Args, "rounded_corners",   "3",        "Rounded-Corners", true);
	Shortcode_Value(Args, "box_shadow",        "0",        "Box-Shadow", true);
	Shortcode_Value(Args, "text_shadow",       "0",        "Text-Shadow", true);
	Shortcode_Value(Args, "opacity",           "100",      "Opacity", true);
	Shortcode_Value(Args, "opacity_hover",     "100",      "Opacity-Hover", true);
	Shortcode_Value(Args, "animate_icon",      "None",     "OPT-Animate-Icon");
	Shortcode_Value(Args, "animate_button",    "None",     "OPT-Animate-Button");
	Shortcode_Value(Args, "transitions",       "Disabled", "OPT-Transitions");
	
	// Section - Customize
	Shortcode_Value(Args, "font_family",         '',        "OPT-Font-Family");
	Shortcode_Value(Args, "font_size",           '',        "OPT-Font-Size");
	Shortcode_Value(Args, "icon_placement",      "Left",    "OPT-Icon-Placement");
	Shortcode_Value(Args, "small_placement",     "None",    "OPT-Small-Placement");
	Shortcode_Value(Args, "button_float",        "None",    "OPT-Button-Float");
	Shortcode_Value(Args, "button_width",        '',        "OPT-Button-Width");
	Shortcode_Value(Args, "button_height",       '',        "OPT-Button-Height");
	Shortcode_Value(Args, "button_line_height",  '',        "OPT-Button-Line-Height");
	Shortcode_Value(Args, "custom_text_color",   '',        "OPT-Custom-Text-Color");
	Shortcode_Value(Args, "custom_bg_color",     '',        "OPT-Custom-BG-Color");
	Shortcode_Value(Args, "custom_border_color", '',        "OPT-Custom-Border-Color");
	Shortcode_Value(Args, "custom_border_width", "1",       "Custom-BorderW", true);
	Shortcode_Value(Args, "custom_border_style", "Default", "OPT-Custom-Border-Style");
	
	if ($("#OPT-Custom-Text-Color").val() !== '')
	{
		$("#OPT-Custom-Text-Toggle").val("Enabled");
		APP.Text_Color();
	}
	
	if ($("#OPT-Custom-BG-Color").val() !== '')
	{
		$("#OPT-Custom-BG-Toggle").val("Enabled");
		APP.Background_Color();
	}
	
	if ($("#OPT-Custom-Border-Color").val() !== '')
	{
		$("#OPT-Custom-Border-Toggle").val("Enabled");
		APP.Border_Color();
	}
	
	if ("custom_border_width" in Args)
	{
		$("#OPT-Custom-BorderW-Toggle").val("Enabled");
		APP.Border_Width();
	}
	
	// Customize - Text Only
	if ("text_only" in Args)
	{
		if (Args['text_only'] === "Yes")
		{
			$("#OPT-Icon-Placement").val("None");
			$("#OPT-Small-Placement").val("None");
		}
	}
	
	// Section - Icon
	if ("icon" in Args)
		APP.Icons_Select(Args['icon']);
	
	function Shortcode_Value(Obj, Label, Default, Field, Slider)
	{
		try
		{
			Slider = Slider || false;
			var Temp = Default;
		
			if (Label in Obj)
				Temp = Obj[Label];
			
			if (Slider)
				APP.Slider_Set({Name: Field, Value: Temp });
			else
				$("#" + Field).val(Temp);
		}
		catch(e){}
	}
};

//*************************************************************
//   APP >> Import: PHP
// PARAM >> String | Input
//*************************************************************
APP.Import_PHP = function(Input)
{
	Input = Input.replace('<?php FLMBTN_Build( array( ', '');
	Input = Input.replace(' ) ); ?>', '');
	
	var Args = [];
	var Params = Input.split('", "');

	for (var i = 0; i < Params.length; i++)
	{
		var Temp = Params[i].split(/=>(.+)?/);
			Temp[0] = Temp[0].replace(/"/g, '');
			Temp[1] = Temp[1].replace(/"/g, '');

		Args[Temp[0]] = Temp[1];
	}
	
	// Section - Details
	PHP_Value(Args, "link_address", '', "OPT-Link-Address");
	PHP_Value(Args, "link_target",  '', "OPT-Link-Target");
	PHP_Value(Args, "link_title",   '', "OPT-Link-Title");
	PHP_Value(Args, "link_rel",     '', "OPT-Link-Rel");
	PHP_Value(Args, "custom_id",    '', "OPT-Custom-ID");
	PHP_Value(Args, "custom_class", '', "OPT-Custom-Class");
	PHP_Value(Args, "button_text",  '', "OPT-Button-Text");
	PHP_Value(Args, "button_small", '', "OPT-Button-Small");

	// Section - Styles
	PHP_Value(Args, "button_size",       "XS",       "OPT-Button-Size");
	PHP_Value(Args, "button_color",      "Light",    "OPT-Button-Color");
	PHP_Value(Args, "text_color",        "Default",  "OPT-Text-Color");
	PHP_Value(Args, "button_style",      "Default",  "OPT-Button-Style");
	PHP_Value(Args, "button_style_icon", "None",     "OPT-Button-Style-Icon");
	PHP_Value(Args, "button_style_3d",   "None",     "OPT-Button-Style-3D");
	PHP_Value(Args, "button_hover",      "None",     "OPT-Button-Hover");
	PHP_Value(Args, "rounded_corners",   "3",        "Rounded-Corners", true);
	PHP_Value(Args, "box_shadow",        "0",        "Box-Shadow", true);
	PHP_Value(Args, "text_shadow",       "0",        "Text-Shadow", true);
	PHP_Value(Args, "opacity",           "100",      "Opacity", true);
	PHP_Value(Args, "opacity_hover",     "100",      "Opacity-Hover", true);
	PHP_Value(Args, "animate_icon",      "None",     "OPT-Animate-Icon");
	PHP_Value(Args, "animate_button",    "None",     "OPT-Animate-Button");
	PHP_Value(Args, "transitions",       "Disabled", "OPT-Transitions");

	// Section - Customize
	PHP_Value(Args, "font_family",         '',        "OPT-Font-Family");
	PHP_Value(Args, "font_size",           '',        "OPT-Font-Size");
	PHP_Value(Args, "icon_placement",      "Left",    "OPT-Icon-Placement");
	PHP_Value(Args, "small_placement",     "None",    "OPT-Small-Placement");
	PHP_Value(Args, "button_float",        "None",    "OPT-Button-Float");
	PHP_Value(Args, "button_width",        '',        "OPT-Button-Width");
	PHP_Value(Args, "button_height",       '',        "OPT-Button-Height");
	PHP_Value(Args, "button_line_height",  '',        "OPT-Button-Line-Height");
	PHP_Value(Args, "custom_text_color",   '',        "OPT-Custom-Text-Color");
	PHP_Value(Args, "custom_bg_color",     '',        "OPT-Custom-BG-Color");
	PHP_Value(Args, "custom_border_color", '',        "OPT-Custom-Border-Color");
	PHP_Value(Args, "custom_border_width", "1",       "Custom-BorderW", true);
	PHP_Value(Args, "custom_border_style", "Default", "OPT-Custom-Border-Style");

	if ($("#OPT-Custom-Text-Color").val() !== '')
	{
		$("#OPT-Custom-Text-Toggle").val("Enabled");
		APP.Text_Color();
	}

	if ($("#OPT-Custom-BG-Color").val() !== '')
	{
		$("#OPT-Custom-BG-Toggle").val("Enabled");
		APP.Background_Color();
	}

	if ($("#OPT-Custom-Border-Color").val() !== '')
	{
		$("#OPT-Custom-Border-Toggle").val("Enabled");
		APP.Border_Color();
	}

	if ("custom_border_width" in Args)
	{
		$("#OPT-Custom-BorderW-Toggle").val("Enabled");
		APP.Border_Width();
	}
	
	// Customize - Text Only
	if ("text_only" in Args)
	{
		if (Args['text_only'] === "Yes")
		{
			$("#OPT-Icon-Placement").val("None");
			$("#OPT-Small-Placement").val("None");
		}
	}

	// Section - Icon
	if ("icon" in Args)
		APP.Icons_Select(Args['icon']);
	
	function PHP_Value(Obj, Label, Default, Field, Slider)
	{
		try
		{
			Slider = Slider || false;
			var Temp = Default;

			if (Label in Obj)
				Temp = Obj[Label];

			if (Slider)
				APP.Slider_Set({Name: Field, Value: Temp });
			else
				$("#" + Field).val(Temp);
		}
		catch(e){}
	}
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

})(jQuery);
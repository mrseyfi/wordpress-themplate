//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

var ADMIN = {
	Curr_Section: '',
	Over_Section: "Details",
	};

jQuery(document).ready(function()
{
	// Bind: Form
	jQuery("#Header-Button").click( function() { ADMIN.Settings_Save() });
	jQuery("#Settings-Form").submit(function() { ADMIN.Settings_Save() });
	
	// Bind: Sidebar
	jQuery("#Sidebar li").each(function(){
		var ID = jQuery(this).prop("id").replace("Side-", '');	
		jQuery(this).click(function(){ ADMIN.Sidebar(ID) });
	});
	ADMIN.Sidebar("Builder");
		
	// Overlay
	jQuery(window).resize(function()
	{
		var Height = jQuery(window).height();
		if (jQuery("#Overlay").css("display") === "block")
			jQuery("#Overlay").css("min-height", Height);
	});
});

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// ADMIN >> Code
// PARAM >> Int | Length
// NOTES >> Generate a randomized code.
//**********************************************************
ADMIN.Code = function(Length)
{	
	Length = Length || 10;
	var Chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXTZabcdefghiklmnopqrstuvwxyz";
	var Code  = '';

	for (var i = 0; i < Length; i++)
	{
		var Rand = Math.floor(Math.random() * Chars.length);
		Code += Chars.substring(Rand, Rand + 1);
	}
	return Code;
};

//**********************************************************
// ADMIN >> Message
// PARAM >> String | Type
// PARAM >> String | Message
//**********************************************************
ADMIN.Message = function(Type, Message)
{
	Type    = Type    || "Error";
	Message = Message || '';

	var Args = {
		TYPE: Type,
		CODE: ADMIN.Code(20),
		TEXT: Message
	};
	
	var Str = ADMIN.Template("Message", Args);
	jQuery("#Messages").append(Str);
	
	jQuery("#Message-" + Args.CODE).fadeIn(200);
	
	setTimeout(function(){
		jQuery("#Message-" + Args.CODE).fadeOut(200, function(){
			jQuery("#Message-" + Args.CODE).remove();
		});
	}, 7000);
};

//**********************************************************
// ADMIN >> Sidebar
// PARAM >> String | ID
//**********************************************************
ADMIN.Sidebar = function(ID)
{
	ID = ID || "Builder";
	
	if (ADMIN.Curr_Section !== ID)
	{	
		// Sidebar Links
		jQuery("#Sidebar li").each(function(){
			jQuery(this).prop("class", '');
		});
	
		jQuery("#Side-" + ID).prop("class", "Active");
	
		// Sections
		jQuery("#Main .Section").each(function(){ jQuery(this).hide() });
		jQuery("#Section-" + ID).fadeIn(200);
		
		ADMIN.Curr_Section = ID;
		
		/*if ("Builder" === ID)
			jQuery("#Header-Icon").html('<span class="dashicons dashicons-admin-tools"></span>');
		else if ("Settings" === ID)
			jQuery("#Header-Icon").html('<span class="dashicons dashicons-admin-generic"></span>');
		else if ( "About" === ID)
			jQuery("#Header-Icon").html('<span class="dashicons dashicons-smiley"></span>');
		else if ( "Support" === ID)
			jQuery("#Header-Icon").html('<span class="dashicons dashicons-shield"></span>');*/
		
		if ("Settings" === ID)
			jQuery("#Header-Right").fadeIn(200);
		else
			jQuery("#Header-Right").fadeOut(200);
	}
};

//**********************************************************
// ADMIN >> Template
// PARAM >> String | Template
// PARAM >> Object | Args
// PARAM >> String | Container
//**********************************************************
ADMIN.Template = function(Template, Args, Container)
{
	var Str = jQuery("#Template-" + Template).html();
		Str = ADMIN.Template_Parse(Str, Args);

	if (Container) $(Container).html(Str);
	return Str;
};

//**********************************************************
// ADMIN >> Template: Parse
// PARAM >> String | Template
// PARAM >> Object | Args
//**********************************************************
ADMIN.Template_Parse = function(Template, Args)
{
	Template = Template.replace(/\{{(.*?)\}}/g,
	function(Markup, Content)
	{
		Content = Content.split('.');
		Count   = Content.length;

		if (Count > 1)
		{
			var Initial = Args[Content[0]];
			var Explode = Content.splice(1, Count);
			for (var i = 0; i < Explode.length; i++)
			{
				Initial = Initial[Explode[i]];
			}
			return Initial;
		}
		else { return Args[Content] }
	});
	return Template;
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// PROTO >> String: Title
// NOTES >> Capitalizes the first letter of each word.
//**********************************************************
String.prototype.Title = function()
{
	return this.toLowerCase().replace(/_/g, ' ')
	.replace(/\b([a-z\u00C0-\u00ff])/g,
	function (_, Initial) { return Initial.toUpperCase();
	}).replace(/(\s(?:de|a|o|e|da|do|em|ou|[\u00C0-\u00ff]))\b/ig,
	function (_, Match) { return Match.toLowerCase(); });
};

//**********************************************************
// PROTO >> String: Cut
// PARAM >> Int  | Length
// PARAM >> Bool | Trail
//**********************************************************
String.prototype.Cut = function(Length, Trail)
{
	Length = Length || false;
	Trail  = Trail  || true;

	if (!Length || this.length <= Length) return this.toString();
	else
	{
		if (Trail) return this.substring(0, Length - 3) + "...";
		else { return this.substring(0, Length); }
	}
};

//**********************************************************
// PROTO >> String: Commas
// NOTES >> Add commas to numbers eg: 1,000,000
//**********************************************************
String.prototype.Commas = function()
{
	var Str = this.toString() + '',
		X   = Str.split('.'),
		X1  = X[0],
		X2  = X.length > 1 ? '.' + X[1] : '',
		Rx  = /(\d+)(\d{3})/;
	while (Rx.test(X1)) { X1 = X1.replace(Rx, '$1' + ',' + '$2'); }
	return X1 + X2;
};

//**********************************************************
// PROTO >> String: Search
// PARAM >> String | A
// PARAM >> String | B
// NOTES >> Grab a section of string based on A/B.
//**********************************************************
String.prototype.Search = function(A, B)
{
	var Str = this.toString();
		Str = Str.substring(Str.indexOf(A) + A.length);
		Str = Str.substring(0, Str.indexOf(B));
	return Str;
};

//**********************************************************
// PROTO >> String: Trim
// NOTES >> Trim extra spaces and line breaks.
//**********************************************************
String.prototype.Trim = function()
{
	return $.trim(this.replace(/(\r\n|\n|\r)/gm, " ").replace(/\s+/g, " "));
};

//**********************************************************
// PROTO >> String: Strip
// PARAM >> String | Type
// PARAM >> String | Allowed
// NOTES >> Strip out special characters and HTML tags.
//**********************************************************
String.prototype.Strip = function(Type, Allowed)
{
	var Tags = /<\/?([a-z][a-z0-9]*)\b[^>]*>/gi;
	var PHP  = /<!--[\s\S]*?-->|<\?(?:php)?[\s\S]*?\?>/gi;

		 if (Type === "Special") 		  { return this.replace(/[^a-zA-Z 0-9]+/g, ''); }
	else if (Type === "Tags" && !Allowed) { return this.replace(/(<([^>]+)>)/g, '');    }
	else
	{
		Allowed = (((Allowed || '') + '').toLowerCase().match(/<[a-z][a-z0-9]*>/g) || []).join('');
		return this.replace(PHP, '').replace(Tags, function($0, $1)
		{ return Allowed.indexOf('<' + $1.toLowerCase() + '>') > -1 ? $0 : ' '; });
	}
};

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//**********************************************************
// ADMIN >> Settings: Save
//**********************************************************
ADMIN.Settings_Save = function()
{
	// Get Fields
	var $Form   = jQuery("#Settings-Form");
	var $Fields = $Form.find("input, select, checkbox, textarea");
	var Data    = $Form.serialize();

	// Reset Message
	jQuery("#Messages").html('');

	// Set Button
	jQuery("#Header-Button").hide();
	jQuery("#Header-Loading").show();

	// Disable Fields
	$Fields.prop("disabled", true);
	
	var Send = {
		action: "flmbtn_admin",
		funct: "Settings_Save",
		data: Data
	};

	jQuery.post(DATA.AJAX_URL, Send, function(Response) {
		jQuery("#Header-Loading").hide();
		jQuery("#Header-Button").show();
		$Fields.prop("disabled", false);

		try
		{
			Response = jQuery.parseJSON(Response);
	
			var Type = Response.type;
			var Msg  = Response.message;
			
			ADMIN.Message(Type, Msg);
		}
		catch(e){ ADMIN.Message("Error", "Save Request Failed: " + e); }
	});
};
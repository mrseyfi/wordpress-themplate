<?php
// Security
defined( "ABSPATH" ) or die( "Unauthorized Access" );

//==========================================================
// CLASS >> FLMBTN: Editor
// NOTES >> Houses WordPress editor integration functions.
//==========================================================
class FLMBTN_Editor
{

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Constructor
//==========================================================
function __construct()
{
	add_action( "admin_init", array( $this, "Editor_Admin" ), 20 );
}

//==========================================================
// FUNCT >> Editor Admin
// NOTES >> Sets up admin filters.
//==========================================================
public function Editor_Admin()
{
	if ( current_user_can( "edit_posts" ) && current_user_can( "edit_pages" ) )
	{
		add_filter( "mce_buttons",           array( $this, "Filter_MCE_Button"     ) );
		add_filter( "mce_external_plugins",  array( $this, "Filter_MCE_Plugin"     ) );
		add_action( "print_media_templates", array( $this, "Print_Media_Templates" ) );
		add_action( "admin_enqueue_scripts", array( $this, "Enqueue_Assets" ) );
	}
}

//==========================================================
// FUNCT >> Filter: MCE Button
// PARAM >> Array | Buttons
// NOTES >> Add button to TinyMCE
//==========================================================
public function Filter_MCE_Button( $Buttons )
{
	array_push( $Buttons, '', "FLMBTN_Button" );
	return $Buttons;
}

//==========================================================
// FUNCT >> Filter: MCE Plugin
// PARAM >> Array | Plugins
// NOTES >> Add functionality to the button.
//==========================================================
public function Filter_MCE_Plugin( $Plugins )
{
	$Plugins['FLMBTN_Button'] = FLMBTN_URL . "Admin/Scripts/Integration-Editor.min.js";
	return $Plugins;
}

//==========================================================
// FUNCT >> Enqueue Assets
// NOTES >> Enqueue scripts and styles for use.
//==========================================================
public function Enqueue_Assets()
{
	wp_enqueue_style( "wp-color-picker" );
	wp_enqueue_style( "FLMBTN-Buttons" );
	wp_enqueue_style( "FLMBTN-Font-Awesome" );
	wp_enqueue_style( "FLMBTN-Editor", FLMBTN_URL . "Admin/Styles/Integration-Editor.min.css" );
	
	wp_enqueue_script( "wp-color-picker" );
	wp_enqueue_script( "FLMBTN-Font-Awesome", FLMBTN_URL . "Admin/Scripts/Font-Awesome.js" );
}

//==========================================================
// FUNCT >> Print Media Templates
// NOTES >> Add popup HTML to the editor page for JS use.
//==========================================================
public function Print_Media_Templates()
{
	?>
	<script type="text/html" id="FLMBTN-Popup">
		<aside id="FLMBTN-Popup-Overlay">
			<div id="FLMBTN-Popup-Window">
				
				<div id="FLMBTN-Top" class="CLR">
					<div id="FLMBTN-Top-Icon"></div>
					<div id="FLMBTN-Top-Title">Button Builder</div>
					<div id="FLMBTN-Top-Close" class="Trans" title="Close">
						<span class="dashicons dashicons-no"></span>
					</div>
				</div>
				
				<div id="FLMBTN-Preview" class="CLR">
					<div id="FLMBTN-Preview-Inner" class="CLR"></div>
				</div>
				
				<textarea id="FLMBTN-Code" style="display: none;"></textarea>
				
				<div id="FLMBTN-Tabs" class="CLR">
					<div id="FLMBTN-Tab-Details" class="Button Left Active">Details</div>
					<div id="FLMBTN-Tab-Styles"  class="Button Left">Styles</div>
					<div id="FLMBTN-Tab-Custom"  class="Button Left">Customize</div>
					<div id="FLMBTN-Tab-Icons"   class="Button Left">Icons</div>
					<div id="FLMBTN-Tab-Import"  class="Button Right">Import</div>
					<div id="FLMBTN-Tab-Extras"  class="Button Right">Extras</div>
				</div>
				
				<div id="FLMBTN-Sections" class="CLR">
					
					<!-- Section - Details -->
					<section id="FLMBTN-Section-Details" class="FLMBTN-Section CLR">

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Link-Address">Link Address</label></div>
							<div class="FLMBTN-Row-Right">
								<input type="text" id="FLMBTN-OPT-Link-Address" spellcheck="false">
								<div id="FLMBTN-Menu-Shortcuts" class="FLMBTN-Menu">
									<div id="FLMBTN-Button-Shortcuts" class="FLMBTN-Button Trans" data-toggle="dropdown">
										Shortcuts &nbsp;<i class="fa fa-caret-down"></i>
									</div>
									<ul id="FLMBTN-Menu-Shortcuts" class="FLMBTN-Menu" aria-labelledby="FLMBTN-Button-Shortcuts">
										<li id="Shortcut-Home-Site">Home - Site</li>
										<li id="Shortcut-Home-Network">Home - Network</li>
										<li id="Shortcut-Admin-Panel">Admin Panel</li>
										<li id="Shortcut-Login">Login</li>
										<li id="Shortcut-Logout">Logout</li>
										<li id="Shortcut-Register">Register</li>
										<li id="Shortcut-Lost-Password">Lost Password</li>
										<li id="Shortcut-Dir-Includes">Directory - Includes</li>
										<li id="Shortcut-Dir-Content">Directory - Content</li>
										<li id="Shortcut-Dir-Stylesheet">Directory - Stylesheet</li>
										<li id="Shortcut-Dir-Template">Directory - Template</li>
									</ul>
								</div>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Link-Title">Link Target</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Link-Target">
									<option value="">Default</option>
									<option value="_self">Self - Same Window</option>
									<option value="_blank">Blank - New Window</option>
									<option value="_parent">Parent - Parent Frameset</option>
									<option value="_top">Top - Top Document in Window</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Link-Title">Link Title</label></div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Link-Title" spellcheck="false"></div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Link-Rel">Link Rel</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Link-Rel">
									<option value="">None</option>
									<option value="alternate">Alternate - Links to an alternate version of the document.</option>
									<option value="author">Author - Links to the author of the document.</option>
									<option value="bookmark">Bookmark - Permanent URL used for bookmarking.</option>
									<option value="help">Help - Links to a help document.</option>
									<option value="license">License - Links to copyright information for the document.</option>
									<option value="next">Next - The next document in a selection.</option>
									<option value="nofollow">NoFollow - Links to an unendorsed document, like a paid link.</option>
									<option value="noreferrer">NoReferrer - Specifies that the browser should not send a HTTP referer header.</option>
									<option value="prefetch">Prefetch - Specifies that the target document should be cached.</option>
									<option value="prev">Prev - The previous document in a selection.</option>
									<option value="search">Search - Links to a search tool for the document.</option>
									<option value="tag">Tag - A tag (keyword) for the current document.</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-ID">Custom ID</label></div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Custom-ID" spellcheck="false"></div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-Class">Custom Class</label></div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Custom-Class" spellcheck="false"></div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Text">Button Text</label></div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Button-Text"></div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Small">Button Small Text</label></div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Button-Small"></div>
						</div>
					</section>
					
					<!-- Section - Styles -->
					<section id="FLMBTN-Section-Styles" class="FLMBTN-Section CLR">
						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Size">Button Size</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Button-Size">
									<option value="XS">X-Small</option>
									<option value="SM">Small</option>
									<option value="MD">Medium</option>
									<option value="LG">Large</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Color">Button Color</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Button-Color">
									<option value="Light">Light</option>
									<option value="Tan">Tan</option>
									<option value="Dark">Dark</option>
									<option value="Blue">Blue</option>
									<option value="Green">Green</option>
									<option value="Red">Red</option>
									<option value="Orange">Orange</option>
									<option value="Yellow">Yellow</option>
									<option value="Pink">Pink</option>
									<option value="Purple">Purple</option>
									<option value="Black">Black (Outline)</option>
									<option value="White">White (Outline)</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Text-Color">Text Color</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Text-Color">
									<option value="Default">Default</option>
									<option value="Engrave">Engrave</option>
									<option value="Light">Light</option>
									<option value="Tan">Tan</option>
									<option value="Dark">Dark</option>
									<option value="Blue">Blue</option>
									<option value="Green">Green</option>
									<option value="Red">Red</option>
									<option value="Orange">Orange</option>
									<option value="Yellow">Yellow</option>
									<option value="Pink">Pink</option>
									<option value="Purple">Purple</option>
									<option value="Black">Black</option>
									<option value="White">White</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Style">Button Style</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Button-Style">
									<option value="Default">Default</option>
									<option value="Flat">Flat</option>
									<option value="Border">Border</option>
									<option value="Outline">Outline</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Style-Icon">Button Style Icon</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Button-Style-Icon">
									<option value="None">None</option>
									<option value="Lines-Left">Lines Left</option>
									<option value="Lines-Right">Lines Right</option>
									<option value="Mask-Left">Mask Left</option>
									<option value="Mask-Right">Mask Right</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Style-3D">Button Style 3D</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Button-Style-3D">
									<option value="None">None</option>
									<option value="D3">3D</option>
									<option value="D3-Large">Large 3D</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Hover">Button Hover</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Button-Hover">
									<option value="None">None</option>
									<option value="Hover-Light">Outline: Light</option>
									<option value="Hover-Tan">Outline: Tan</option>
									<option value="Hover-Dark">Outline: Dark</option>
									<option value="Hover-Blue">Outline: Blue</option>
									<option value="Hover-Green">Outline: Green</option>
									<option value="Hover-Red">Outline: Red</option>
									<option value="Hover-Orange">Outline: Orange</option>
									<option value="Hover-Yellow">Outline: Yellow</option>
									<option value="Hover-Pink">Outline: Pink</option>
									<option value="Hover-Purple">Outline: Purple</option>
									<option value="Hover-Black">Outline: Black</option>
									<option value="Hover-White">Outline: White</option>
									<option value="HoverB-Light">Border: Light</option>
									<option value="HoverB-Tan">Border: Tan</option>
									<option value="HoverB-Dark">Border: Dark</option>
									<option value="HoverB-Blue">Border: Blue</option>
									<option value="HoverB-Green">Border: Green</option>
									<option value="HoverB-Red">Border: Red</option>
									<option value="HoverB-Orange">Border: Orange</option>
									<option value="HoverB-Yellow">Border: Yellow</option>
									<option value="HoverB-Pink">Border: Pink</option>
									<option value="HoverB-Purple">Border: Purple</option>
									<option value="HoverB-Black">Border: Black</option>
									<option value="HoverB-White">Border: White</option>
									<option value="HoverF-Light">Flat: Light</option>
									<option value="HoverF-Tan">Flat: Tan</option>
									<option value="HoverF-Dark">Flat: Dark</option>
									<option value="HoverF-Blue">Flat: Blue</option>
									<option value="HoverF-Green">Flat: Green</option>
									<option value="HoverF-Red">Flat: Red</option>
									<option value="HoverF-Orange">Flat: Orange</option>
									<option value="HoverF-Yellow">Flat: Yellow</option>
									<option value="HoverF-Pink">Flat: Pink</option>
									<option value="HoverF-Purple">Flat: Purple</option>
									<option value="HoverF-Black">Flat: Black</option>
									<option value="HoverF-White">Flat: White</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Rounded-Corners">Rounded Corners</div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Rounded-Corners">
									<option value="0">0</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
									<option value="11">11</option>
									<option value="12">12</option>
									<option value="13">13</option>
									<option value="14">14</option>
									<option value="15">15</option>
									<option value="16">16</option>
									<option value="17">17</option>
									<option value="18">18</option>
									<option value="19">19</option>
									<option value="20">20</option>
									<option value="21">21</option>
									<option value="22">22</option>
									<option value="23">23</option>
									<option value="24">24</option>
									<option value="25">25</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Box-Shadow">Box Shadow</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Box-Shadow">
									<option value="0">0</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Text-Shadow">Text Shadow</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Text-Shadow">
									<option value="0">0</option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
									<option value="6">6</option>
									<option value="7">7</option>
									<option value="8">8</option>
									<option value="9">9</option>
									<option value="10">10</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Opacity">Opacity</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Opacity">
									<option value="100">100</option>
									<option value="90">90</option>
									<option value="80">80</option>
									<option value="70">70</option>
									<option value="60">60</option>
									<option value="50">50</option>
									<option value="40">40</option>
									<option value="30">30</option>
									<option value="20">20</option>
									<option value="10">10</option>
									<option value="0">0</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Opacity-Hover">Opacity Hover</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Opacity-Hover">
									<option value="100">100</option>
									<option value="90">90</option>
									<option value="80">80</option>
									<option value="70">70</option>
									<option value="60">60</option>
									<option value="50">50</option>
									<option value="40">40</option>
									<option value="30">30</option>
									<option value="20">20</option>
									<option value="10">10</option>
									<option value="0">0</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Animate-Icon">Animate Icon</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Animate-Icon">
									<option value="None">None</option>
									<option value="Rotate-90">Rotate 90 Degrees</option>
									<option value="Rotate-180">Rotate 180 Degrees</option>
									<option value="Rotate-360">Rotate 360 Degrees</option>
									<option value="Zoom">Zoom</option>
									<option value="Loop">Loop</option>
									<option value="Grow">Grow</option>
									<option value="Shrink">Shrink</option>
									<option value="Skew">Skew</option>
									<option value="Flip-LR">Flip Left to Right</option>
									<option value="Flip-TB">Flip Top to Bottom</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Animate-Button">Animate Button</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Animate-Button">
									<option value="None">None</option>
									<option value="Rotate">Rotate</option>
									<option value="Grow">Grow</option>
									<option value="Shrink">Shrink</option>
									<option value="Flip-LR">Flip Left to Right</option>
									<option value="Flip-TB">Flip Top to Bottom</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Transitions">CSS Transitions</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Transitions">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>
					</section>
					
					<!-- Section - Customize -->
					<section id="FLMBTN-Section-Custom" class="FLMBTN-Section CLR">
						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left">
								<label for="FLMBTN-OPT-Font-Family">
									<abbr title="Optional: Override default font with custom font family or web-safe font family class.">Font Family</abbr>
								</label>
							</div>
							<div class="FLMBTN-Row-Right">
								<input type="text" id="FLMBTN-OPT-Font-Family" spellcheck="false">
								<div id="FLMBTN-Menu-Fonts" class="FLMBTN-Menu">
									<div id="FLMBTN-Button-Fonts" class="FLMBTN-Button Trans" data-toggle="dropdown">
										Fonts &nbsp;<i class="fa fa-caret-down"></i>
									</div>
									<ul id="FLMBTN-Menu-Fonts" class="FLMBTN-Menu" aria-labelledby="FLMBTN-Button-Fonts">
										<li id="Font-Arial"><strong>Sans-Serif |</strong> Arial</li>
										<li id="Font-Arial-Black"><strong>Sans-Serif |</strong> Arial Black</li>
										<li id="Font-Comic-Sans-MS"><strong>Sans-Serif |</strong> Comic Sans MS</li>
										<li id="Font-Impact"><strong>Sans-Serif |</strong> Impact</li>
										<li id="Font-Lucida-Sans"><strong>Sans-Serif |</strong> Lucida Sans</li>
										<li id="Font-Tahoma"><strong>Sans-Serif |</strong> Tahoma</li>
										<li id="Font-Trebuchet-MS"><strong>Sans-Serif |</strong> Trebuchet MS</li>
										<li id="Font-Verdana"><strong>Sans-Serif |</strong> Verdana</li>
										<li id="Font-Book-Antiqua"><strong>Serif |</strong> Book Antiqua</li>
										<li id="Font-Georgia"><strong>Serif |</strong> Georgia</li>
										<li id="Font-Times-New-Roman"><strong>Serif |</strong> Times New Roman</li>
										<li id="Font-Courier-New"><strong>Monospace |</strong> Courier New</li>
										<li id="Font-Lucida-Console"><strong>Monospace |</strong> Lucida Console</li>
									</ul>
								</div>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left">
								<label for="FLMBTN-OPT-Font-Size">
									<abbr title="Optional: Override and set a specific font size using inline-styles.">Font Size</abbr>
								</label>
							</div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Font-Size" spellcheck="false"></div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Icon-Placement">Icon Placement</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Icon-Placement">
									<option value="Left">Left Side</option>
									<option value="Right">Right Side</option>
									<option value="None">No Icon</option>
									<option value="Only">Icon Only</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Small-Placement">Small Text Placement</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Small-Placement">
									<option value="None">No Small Text</option>
									<option value="Left">Left Side</option>
									<option value="Right">Right Side</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Button-Type">Button Float</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Button-Float">
									<option value="None">None</option>
									<option value="Left">Left</option>
									<option value="Right">Right</option>
								</select>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left">
								<label for="FLMBTN-OPT-Button-Width">
									<abbr title="Optional: Override and set a specific button width using inline-styles.">Button Width</abbr>
								</label>
							</div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Button-Width" spellcheck="false"></div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left">
								<label for="FLMBTN-OPT-Button-Height">
									<abbr title="Optional: Override and set a specific button height using inline-styles.">Button Height</abbr>
								</label>
							</div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Button-Height" spellcheck="false"></div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left">
								<label for="FLMBTN-OPT-Button-Line-Height">
									<abbr title="Optional: Override and set a specific button line-height using inline-styles.">Button Line Height</abbr>
								</label>
							</div>
							<div class="FLMBTN-Row-Right"><input type="text" id="FLMBTN-OPT-Button-Line-Height" spellcheck="false"></div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-Text-Toggle">Custom Text Color</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Custom-Text-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>

						<div id="FLMBTN-Custom-Text-Color" style="display: none";>
							<div class="FLMBTN-Row CLR">
								<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-Text-Color">Hex Color:</label></div>
								<div class="FLMBTN-Row-Right">
									<input type="text" id="FLMBTN-OPT-Custom-Text-Color" class="Color-Picker">
								</div>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-BG-Toggle">Custom Background Color</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Custom-BG-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>

						<div id="FLMBTN-Custom-BG-Color" style="display: none";>
							<div class="FLMBTN-Row CLR">
								<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-BG-Color">Hex Color:</label></div>
								<div class="FLMBTN-Row-Right">
									<input type="text" id="FLMBTN-OPT-Custom-BG-Color" class="Color-Picker">
								</div>
							</div>
						</div>

						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-Border-Toggle">Custom Border Color</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Custom-Border-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>

						<div id="FLMBTN-Custom-Border-Color" style="display: none";>
							<div class="FLMBTN-Row CLR">
								<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-Border-Color">Hex Color:</label></div>
								<div class="FLMBTN-Row-Right">
									<input type="text" id="FLMBTN-OPT-Custom-Border-Color" class="Color-Picker">
								</div>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-BorderW-Toggle">Custom Border Width</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Custom-BorderW-Toggle">
									<option value="Disabled">Disabled</option>
									<option value="Enabled">Enabled</option>
								</select>
							</div>
						</div>

						<div id="FLMBTN-Custom-Border-Width" style="display: none";>
							<div class="FLMBTN-Row CLR">
								<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-BorderW">Width (Pixels)</label></div>
								<div class="FLMBTN-Row-Right">
									<select id="FLMBTN-OPT-Custom-BorderW">
										<option value="0">0</option>
										<option value="1">1</option>
										<option value="2">2</option>
										<option value="3">3</option>
										<option value="4">4</option>
										<option value="5">5</option>
										<option value="6">6</option>
										<option value="7">7</option>
										<option value="8">8</option>
										<option value="9">9</option>
										<option value="10">10</option>
										<option value="11">11</option>
										<option value="12">12</option>
										<option value="13">13</option>
										<option value="14">14</option>
										<option value="15">15</option>
										<option value="16">16</option>
										<option value="17">17</option>
										<option value="18">18</option>
										<option value="19">19</option>
										<option value="20">20</option>
										<option value="21">21</option>
										<option value="22">22</option>
										<option value="23">23</option>
										<option value="24">24</option>
										<option value="25">25</option>
									</select>
								</div>
							</div>
						</div>

						<div class="FLMBTN-Row CLR">
							<div class="FLMBTN-Row-Left"><label for="FLMBTN-OPT-Custom-Border-Style">Custom Border Style</label></div>
							<div class="FLMBTN-Row-Right">
								<select id="FLMBTN-OPT-Custom-Border-Style">
									<option value="Default">Default</option>
									<option value="None">None</option>
									<option value="Dashed">Dashed</option>
									<option value="Dotted">Dotted</option>
									<option value="Double">Double</option>
									<option value="Groove">Groove</option>
									<option value="Inset">Inset</option>
									<option value="Outset">Outset</option>
									<option value="Ridge">Ridge</option>
									<option value="Solid">Solid</option>
								</select>
							</div>
						</div>

					</section>
					
					<!-- Section - Icons -->
					<section id="FLMBTN-Section-Icons" class="FLMBTN-Section CLR">
						<div id="FLMBTN-Search-Bar">
							<input type="text" id="FLMBTN-Search-Text" placeholder="Search for...">
							<div id="FLMBTN-Search-Icon" class="Button" title="Search Icons"><i class="fa fa-search"></i></div>
							<div id="FLMBTN-Search-Reset" class="Button" title="Reset Search"><i class="fa fa-times"></i></div>
						</div>
						<div id="FLMBTN-Icons">
							<div id="FLMBTN-Icons-List"></div>
						</div>
					</section>
					
					<!-- Section - Extras -->
					<section id="FLMBTN-Section-Extras" class="FLMBTN-Section CLR">
						<div class="FLMBTN-Row FLMBTN-Button-Row CLR">
							<div class="FLMBTN-Row-Left">Reset Builder</div>
							<div class="FLMBTN-Row-Right" id="Reset-Buttons">
								<div id="FLMBTN-Reset-All"     class="Left Button-Alt">All</div>
								<div id="FLMBTN-Reset-Details" class="Left Button-Alt">Details</div>
								<div id="FLMBTN-Reset-Styles"  class="Left Button-Alt">Styles</div>
								<div id="FLMBTN-Reset-Custom"  class="Left Button-Alt">Customize</div>
								<div id="FLMBTN-Reset-Icons"   class="Left Button-Alt">Icons</div>
							</div>
						</div>
						<div class="FLMBTN-Row-Line"></div>

						<div class="FLMBTN-Row FLMBTN-Button-Row CLR">
							<div class="FLMBTN-Row-Left">Button Samples</div>
							<div class="FLMBTN-Row-Right">
								<div id="FLMBTN-Sample-Add-to-Cart" class="Left Button-Alt">Add to Cart</div>
								<div id="FLMBTN-Sample-Order-Now"   class="Left Button-Alt">Order Now</div>
								<div id="FLMBTN-Sample-Read-More"   class="Left Button-Alt">Read More</div>
								<div id="FLMBTN-Sample-Top"         class="Left Button-Alt">Top</div>
								<div id="FLMBTN-Sample-Previous"    class="Left Button-Alt">Previous</div>
								<div id="FLMBTN-Sample-Facebook"    class="Left Button-Alt">Facebook</div>
								<div id="FLMBTN-Sample-Tweet-This"  class="Left Button-Alt">Tweet This</div>
								<div id="FLMBTN-Sample-Google-Plus" class="Left Button-Alt">Google Plus</div>
								<div id="FLMBTN-Sample-GitHub"      class="Left Button-Alt">GitHub</div>
								<div id="FLMBTN-Sample-Play-Video"  class="Left Button-Alt">Play Video</div>
							</div>
						</div>
					</section>
					
					
					<!-- Section - Import -->
					<section id="FLMBTN-Section-Import" class="FLMBTN-Section CLR">
						<div class="Center">
							<h1>Import Button Code</h1>
							<p>
								Simply copy and paste an existing button (Shortcode, HTML, or PHP) into the box and press import.<br>
								This will automatically set the options and styles to match the button and allow for easy editing.
								<br><br>
								<strong>Note:</strong> Works with generated code. Altered codes may produce erratic imports.
							</p>
						</div>
						<textarea id="FLMBTN-Import-Box" spellcheck="false"></textarea>
						<div id="FLMBTN-Import-Button" class="Button-Alt">Import Code</div>
						<div id="FLMBTN-Import-Space" class="Hidden"></div>
					</section>
					
				</div>
				
				<div id="FLMBTN-Bottom" class="CLR">
					<div id="FLMBTN-Insert" class="button media-button button-primary button-large media-button-insert">Insert into post</div>
				</div>
				
			</div>
		</aside>
	</script>
	<?php
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // End Class

$FLMBTN_Editor = new FLMBTN_Editor();
?>
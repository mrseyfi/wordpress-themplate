<?php
//==========================================================
// CLASS >> FLMBTN: Admin
// NOTES >> Houses plugin admin-only functions.
//==========================================================
class FLMBTN_Admin
{
	private static $Prefix = "FLMBTN";
	private static $Permissions = "manage_options";

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Init
// NOTES >> Register settings and sanitization callback.
//==========================================================
public static function Init()
{
	register_setting( "FLMBTN_Options", self::$Prefix );
}

//==========================================================
// FUNCT >> Menu
// NOTES >> Add plugin menu to admin panel.
//==========================================================
public static function Menu()
{
	$Title    = "Button Builder";
	$Function = array( "FLMBTN_Admin", "Page" );

	add_theme_page( $Title, $Title, self::$Permissions, self::$Prefix, $Function );
}

//==========================================================
// FUNCT >> Page
// NOTES >> Build admin page HTML markup.
//==========================================================
public static function Page()
{
	if ( ! current_user_can( self::$Permissions ) )
		wp_die( "You do not have sufficient permissions to access this page." );

	// Include Page
	$Include = FLMBTN_DIR . "/Admin/Admin.php";
	if ( file_exists( $Include ) ) include_once $Include;
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Settings Link
// PARAM >> Array  | Links
// PARAM >> String | File
// NOTES >> Creates a settings link for the plugin page.
//==========================================================
public static function Settings_Link( $Links, $File )
{
	static $Check;

	if ( ! $Check )
	{
		$Check = plugin_basename( __FILE__ );
		$Check = str_replace( "Classes/FLMBTN-Admin.php", "FLM-Button-Builder.php", $Check );
	}

	if ( $File === $Check )
	{
		$Site = get_bloginfo( "wpurl" );
		$Link = "<a href='$Site/wp-admin/themes.php?page=" . self::$Prefix . "'>Settings</a>";
		array_unshift( $Links, $Link );
	}
	return $Links;
}

//==========================================================
// FUNCT >> AJAX Handler
// NOTES >> Redirects AJAX traffic to new destination.
//==========================================================
public static function AJAX_Handler()
{
	// Get AJAX Class
	require_once FLMBTN_DIR . "/Classes/FLMBTN-AJAX.php";
	
	// Determine Function
	call_user_func( array( "FLMBTN_AJAX", $_POST['funct'] ) );

	// End AJAX
	die();
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Uninstall
// NOTES >> Remove options for clean uninstall.
//==========================================================
public static function Uninstall()
{
	delete_option( "FLMBTN" );
	delete_option( "FLMBTN_VER" );
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // End Class
?>
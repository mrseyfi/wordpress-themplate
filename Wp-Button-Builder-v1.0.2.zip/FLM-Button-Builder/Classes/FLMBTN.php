<?php
//==========================================================
// CLASS >> FLMBTN
// NOTES >> Houses plugin cross-functions and basic data.
//==========================================================
class FLMBTN
{
	// Option Defaults
	private static $Prefix   = "FLMBTN";
	private static $Defaults = array(
		"Font_Awesome_Enqueue"      => TRUE,
		"Font_Awesome_Source"       => "Internal",
		"Button_Styles_Enqueue"     => FALSE,
		"Enable_Integration_Editor" => TRUE,
		"Enable_Integration_VC"     => FALSE
	);

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Get Option
// PARAM >> String | Name
// PARAM >> Array  | Options
// NOTES >> Checks an variable and sets default if needed.
//==========================================================
public static function Get_Option( $Name = NULL, $Options = NULL )
{
	if ( ! $Name    ) return;
	if ( ! $Options ) $Options = get_option( self::$Prefix );
	
	return isset( $Options[$Name] ) ? $Options[$Name] : self::$Defaults[$Name];
}

//==========================================================
// FUNCT >> Set Options
// PARAM >> Array  | Args
// NOTES >> Save options array with new optional data.
//==========================================================
public static function Set_Options( $Args = NULL )
{
	if ( ! $Args ) return;
	
	$Options = get_option( self::$Prefix );
	$Options = array_replace( $Options, $Args );
	
	update_option( self::$Prefix, $Options );
}

//==========================================================
// FUNCT >> Default Options
// NOTES >> Retrieves the default options for the plugin.
//==========================================================
public static function Default_Options()
{
	return isset( self::$Defaults ) ? self::$Defaults : array();
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Enqueue Assets
// NOTES >> Enqueue scripts and styles for use.
//==========================================================
public static function Enqueue_Assets()
{
	// Register: Font Awesome	
	$FA_Source  = self::Get_Option( "Font_Awesome_Source" );
	$FA_Version = "4.5.0";

		if ( "Internal" === $FA_Source )
		wp_register_style( "FLMBTN-Font-Awesome", FLMBTN_URL . "Assets/Styles/Font-Awesome.min.css" );
	elseif ( "BootstrapCDN" === $FA_Source )
		wp_register_style( "FLMBTN-Font-Awesome", "//netdna.bootstrapcdn.com/font-awesome/$FA_Version/css/font-awesome.css" );
	elseif ( "MaxCDN" === $FA_Source )
		wp_register_style( "FLMBTN-Font-Awesome", "//maxcdn.bootstrapcdn.com/font-awesome/$FA_Version/css/font-awesome.min.css" );
	elseif ( "CDNJS" === $FA_Source )
		wp_register_style( "FLMBTN-Font-Awesome", "//cdnjs.cloudflare.com/ajax/libs/font-awesome/$FA_Version/css/font-awesome.css" );
	
	// Register: Button Styles
	wp_register_style( "FLMBTN-Buttons", FLMBTN_URL . "Assets/Styles/CSS-Buttons.min.css" );
	
	// Always Enqueue?
	if ( ! is_admin() && self::Get_Option( "Button_Styles_Enqueue" ) )
	{
		wp_enqueue_style( "FLMBTN-Font-Awesome" );
		wp_enqueue_style( "FLMBTN-Buttons" );
	}
	
	// General Admin Files
	if ( is_admin() )
	{		
		// Track Current Screen
		$Screen = get_current_screen();
		$Screen = $Screen->base;
		
		// Enqueue on Admin Settings Page
		if ( "appearance_page_FLMBTN" === $Screen )
		{
			wp_enqueue_style( "dashboard" );
			wp_enqueue_style( "FLMBTN-Buttons" );
			wp_enqueue_style( "FLMBTN-Font-Awesome" );
			wp_enqueue_style( "FLMBTN-Admin",     FLMBTN_URL . "Admin/Styles/Admin.css" );
			wp_enqueue_style( "FLMBTN-JQuery-UI", FLMBTN_URL . "Admin/Styles/JQuery-UI.min.css" );
			wp_enqueue_style( "FLMBTN-Color",     FLMBTN_URL . "Admin/Styles/Color-Picker.css" );

			wp_enqueue_script( "dashboard" );
			wp_enqueue_script( "jquery" );
			
			wp_enqueue_script( "FLMBTN-Admin",        FLMBTN_URL . "Admin/Scripts/Admin.js",              array( "jquery" ) );
			wp_enqueue_script( "FLMBTN-JQuery-UI",    FLMBTN_URL . "Admin/Scripts/JQuery-UI.min.js",      array( "jquery" ) );
			wp_enqueue_script( "FLMBTN-Dropdown",     FLMBTN_URL . "Admin/Scripts/Bootstrap-Dropdown.js", array( "jquery" ) );
			wp_enqueue_script( "FLMBTN-Color",        FLMBTN_URL . "Admin/Scripts/Color-Picker.js",       array( "jquery", "FLMBTN-JQuery-UI" ) );
			wp_enqueue_script( "FLMBTN-Font-Awesome", FLMBTN_URL . "Admin/Scripts/Font-Awesome.js" );
			wp_enqueue_script( "FLMBTN-Builder",      FLMBTN_URL . "Admin/Scripts/Button-Builder.min.js", array( "jquery", "FLMBTN-JQuery-UI", "FLMBTN-Color", "FLMBTN-Font-Awesome" ) );
			
			wp_localize_script( "FLMBTN-Admin", "DATA", array(
				"AJAX_URL" => admin_url( "admin-ajax.php" ),
				"Version"  => FLMBTN_VER
			) );
			
			wp_localize_script( "FLMBTN-Builder", "URL", array(
				"Home_Site"      => home_url(),
				"Home_Network"   => network_home_url(),
				"Admin_Panel"    => admin_url(),
				"Login"          => wp_login_url(),
				"Logout"         => wp_logout_url(),
				"Register"       => wp_registration_url(),
				"Lost_Password"  => wp_lostpassword_url(),
				"Dir_Includes"   => includes_url(),
				"Dir_Content"    => content_url(),
				"Dir_Stylesheet" => get_stylesheet_directory_uri(),
				"Dir_Template"   => get_template_directory_uri()
			) );
		}
	}
}

//==========================================================
// FUNCT >> Integrations
// NOTES >> Determine which files to load and when.
//==========================================================
public static function Integrations()
{
	global $pagenow;

	if ( self::Get_Option( "Enable_Integration_Editor" ) )
	{
		if ( "post-new.php" === $pagenow || "post.php" === $pagenow )
			include_once FLMBTN_DIR . "/Admin/Integration-Editor.php";
	}
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Button Shortcode
// PARAM >> Array | atts
// NOTES >> Sets up shortcode call and button function.
//==========================================================
public static function Button_Shortcode( $atts )
{
	if ( ! $atts ) return;
	
	$Defaults = array(
		"link_address"        => '',
		"link_target"         => '',
		"link_title"          => '',
		"link_rel"            => '',
		"custom_id"           => '',
		"custom_class"        => '',
		"button_text"         => '',
		"button_small"        => '',
		"button_size"         => "XS",
		"button_color"        => "Light",
		"text_color"          => "Default",
		"button_style"        => "Default",
		"button_style_icon"   => "None",
		"button_style_3d"     => "None",
		"button_hover"        => "None",
		"rounded_corners"     => "3",
		"box_shadow"          => "0",
		"text_shadow"         => "0",
		"opacity"             => "100",
		"opacity_hover"       => "100",
		"animate_icon"        => "None",
		"animate_button"      => "None",
		"transitions"         => "Disabled",
		"font_family"         => '',
		"font_size"           => '',
		"icon_placement"      => "Left",
		"small_placement"     => "None",
		"button_float"        => "None",
		"button_width"        => '',
		"button_height"       => '',
		"button_line_height"  => '',
		"custom_text_color"   => '',
		"custom_bg_color"     => '',
		"custom_border_color" => '',
		"custom_border_width" => '',
		"custom_border_style" => "Default",
		"text_only"           => '',
		"icon"                => ''
	);
	
	$Args = shortcode_atts( $Defaults, $atts );
	$Args = apply_filters( "flmbtn_button_args", $Args );
	
	$HTML = FLMBTN_Build( $Args, FALSE );
	
	return $HTML;
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // End Class
?>
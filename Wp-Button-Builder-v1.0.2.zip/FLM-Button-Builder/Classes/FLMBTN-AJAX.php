<?php
//==========================================================
// CLASS >> FLMBTN: AJAX
// NOTES >> Maintaines various admin panel AJAX calls.
//==========================================================
class FLMBTN_AJAX {

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> Settings Save
// NOTES >> Sanatizes, converts, and saves settings options.
//==========================================================
public static function Settings_Save()
{
	// Get Data
	parse_str( $_POST['data'], $Input );
	$Options = get_option( "FLMBTN" );
	
	// Modify Input
	$Input['Font_Awesome_Enqueue']      = ! isset( $Input['Font_Awesome_Enqueue']      ) ? FALSE : TRUE;
	$Input['Button_Styles_Enqueue']     = ! isset( $Input['Button_Styles_Enqueue']     ) ? FALSE : TRUE;
	$Input['Enable_Integration_Editor'] = ! isset( $Input['Enable_Integration_Editor'] ) ? FALSE : TRUE;
	$Input['Enable_Integration_VC']     = ! isset( $Input['Enable_Integration_VC']     ) ? FALSE : TRUE;

	// Modify Data
	$Options['Font_Awesome_Source']       = isset( $Input['Font_Awesome_Source']       ) ? $Input['Font_Awesome_Source']       : $Options['Font_Awesome_Source'];
	$Options['Font_Awesome_Enqueue']      = isset( $Input['Font_Awesome_Enqueue']      ) ? $Input['Font_Awesome_Enqueue']      : $Options['Font_Awesome_Enqueue'];
	$Options['Button_Styles_Enqueue']     = isset( $Input['Button_Styles_Enqueue']     ) ? $Input['Button_Styles_Enqueue']     : $Options['Button_Styles_Enqueue'];
	$Options['Enable_Integration_Editor'] = isset( $Input['Enable_Integration_Editor'] ) ? $Input['Enable_Integration_Editor'] : $Options['Enable_Integration_Editor'];
	$Options['Enable_Integration_VC']     = isset( $Input['Enable_Integration_VC']     ) ? $Input['Enable_Integration_VC']     : $Options['Enable_Integration_VC'];
	
	// Save Options
	update_option( "FLMBTN", $Options );
	
	// Send Message
	echo '{"type":"Success","message":"Settings Saved!"}';
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // End Class
?>
<?php
//==========================================================
// CLASS >> FLMBTN: Utility
// NOTES >> Houses several base utility functions.
//==========================================================
class FLMBTN_Utility {

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%	

//==========================================================
// FUNCT >> Slashes
// PARAM >> String | Value
// NOTES >> Add slashes to string if magic quotes is off.
//==========================================================
public static function Slashes( $Value )
{
	if ( ! get_magic_quotes_gpc() ) $Value = addslashes( $Value );
	$Value = str_replace( "\"", "&quot;", $Value );
	return $Value;
}

//==========================================================
// FUNCT >> Page URL
// NOTES >> Return the current page URL.
//==========================================================
public static function Page_URL()
{
	$URL = isset( $_SERVER['HTTPS'] ) ? "https" : "http";
	$URL = $URL . "://" . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
	return $URL;
}

//==========================================================
// FUNCT >> String Cut
// PARAM >> String | Str
// PARAM >> Int    | Length
// NOTES >> Returns a cut string with ellipses if too long.
//==========================================================
public static function String_Cut( $Str, $Length = 160 )
{
	if ( $Length >= strlen( $Str ) )
		$Str = substr( $Str, 0, $Length - 3 ) . "...";
	return $Str;
}

//==========================================================
// FUNCT >> Get WP Option
// PARAM >> String | Option_Name
// NOTES >> Returns a WordPress option straight from DB.
//==========================================================
public static function Get_WP_Option( $Option_Name )
{
	global $wpdb;
	return $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->prefix}options WHERE option_name = %s LIMIT 1", $Option_Name ) );
}

//==========================================================
// FUNCT >> Get Username
// PARAM >> String | ID
// NOTES >> Retrieves a WP username for the given ID.
//==========================================================
public static function Get_Username( $ID = FALSE )
{
	if ( ! $ID ) return FALSE;

	$User = get_userdata( $ID );
	return $User->user_login;
}

//==========================================================
// FUNCT >> Message
// PARAM >> String | Type
// PARAM >> String | Message
// NOTES >> Echo JSON message output and exit.
//==========================================================
function Message( $Type = "Error", $Message = NULL )
{
	if ( $Message ) $Message = str_replace( '"', "&quot;", $Message );

	echo '{"type":"' . $Type . '", "message":"' . $Message . '"}';
	exit;
}

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

} // End Class
?>
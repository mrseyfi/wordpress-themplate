<?php
/*
Plugin Name:    Fuselight - Button Builder
Plugin URI:     http://fuselightmedia.com
Description:    Create custom buttons for your site, content, and sidebar! Hundreds of style possibilities! 2.0.S.C.R.I.P.T.i.r
Version:        1.0.2
Author:         20 Script
Author URI:     http://www.20script.ir
License:        http://codecanyon.net/licenses/standard
Text Domain:    FLMBTN
Domain Path:    /languages/
*/

// Security
defined( "ABSPATH" ) or die( "Unauthorized Access" );

// Constants
if ( ! defined( "FLMBTN_DIR" ) ) define( "FLMBTN_DIR",        dirname( __FILE__ ) );
if ( ! defined( "FLMBTN_URL" ) ) define( "FLMBTN_URL", plugin_dir_url( __FILE__ ) );
if ( ! defined( "FLMBTN_VER" ) ) define( "FLMBTN_VER", "1.0.2"                    );

// Include Main Class
require FLMBTN_DIR . "/Classes/FLMBTN.php";

// Initial Options
add_option( "FLMBTN", FLMBTN::Default_Options() );
add_option( "FLMBTN_VER", FLMBTN_VER );

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ( is_admin() )
{
	// ADMIN: File Includes
	require FLMBTN_DIR . "/Classes/FLMBTN-Admin.php";
	require FLMBTN_DIR . "/Classes/FLMBTN-Utility.php";

	// ADMIN: Define Backend Filters
	add_action( "admin_init", array( "FLMBTN_Admin", "Init" ) );
	add_action( "admin_menu", array( "FLMBTN_Admin", "Menu" ) );

	// ADMIN: Plugin Page Settings Link
	add_filter( "plugin_action_links", array( "FLMBTN_Admin", "Settings_Link" ), 10, 2 );

	// ADMIN: AJAX Handling
	add_action( "wp_ajax_flmbtn_admin", array( "FLMBTN_Admin", "AJAX_Handler" ) );

	// ADMIN: Uninstall
	if ( function_exists( "register_uninstall_hook" ) )
		register_uninstall_hook( __FILE__, array( "FLMBTN_Admin", "Uninstall" ) );
		
	// ADMIN: Enqueue Files
	add_action( "admin_enqueue_scripts", array( "FLMBTN", "Enqueue_Assets" ) );
	
	// ADMIN: Integrations
	add_action( "admin_init", array( "FLMBTN", "Integrations" ) );
}
else
{
	// EXTERNAL: Enqueue Files
	add_action( "wp_enqueue_scripts", array( "FLMBTN", "Enqueue_Assets" ) );
}

// Register Shortcode
add_shortcode( "flm_button", array( "FLMBTN", "Button_Shortcode" ) );

//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
//%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

//==========================================================
// FUNCT >> FLMBTN Build
// PARAM >> Array | Input
// PARAM >> Bool  | Echo
// NOTES >> Builds button HTML based on options.
//==========================================================
function FLMBTN_Build( $Input = NULL, $Echo = TRUE )
{
	if ( ! $Input ) return FALSE;
	
	// Enqueue Files
	if ( FLMBTN::Get_Option( "Font_Awesome_Enqueue" ) )
		wp_enqueue_style( "FLMBTN-Font-Awesome" );

	wp_enqueue_style( "FLMBTN-Buttons" );
	
	$Defaults = array(
		"link_address"        => '',
		"link_target"         => '',
		"link_title"          => '',
		"link_rel"            => '',
		"custom_id"           => '',
		"custom_class"        => '',
		"button_text"         => '',
		"button_small"        => '',
		"button_size"         => "XS",
		"button_color"        => "Light",
		"text_color"          => "Default",
		"button_style"        => "Default",
		"button_style_icon"   => "None",
		"button_style_3d"     => "None",
		"button_hover"        => "None",
		"rounded_corners"     => "3",
		"box_shadow"          => "0",
		"text_shadow"         => "0",
		"opacity"             => "100",
		"opacity_hover"       => "100",
		"animate_icon"        => "None",
		"animate_button"      => "None",
		"transitions"         => "Disabled",
		"font_family"         => '',
		"font_size"           => '',
		"icon_placement"      => "Left",
		"small_placement"     => "None",
		"button_float"        => "None",
		"button_width"        => '',
		"button_height"       => '',
		"button_line_height"  => '',
		"custom_text_color"   => '',
		"custom_bg_color"     => '',
		"custom_border_color" => '',
		"custom_border_width" => '',
		"custom_border_style" => "Default",
		"text_only"           => '',
		"icon"                => ''
	);
	
	$Args = array_merge( $Defaults, $Input );
	
	// Link Address URL
	$Link_Address = $Args['link_address'];
	$Link_Address = str_replace( "{HOME-SITE}",      home_url(),                     $Link_Address );
	$Link_Address = str_replace( "{HOME-NETWORK}",   network_home_url(),             $Link_Address );
	$Link_Address = str_replace( "{ADMIN-PANEL}",    admin_url(),                    $Link_Address );
	$Link_Address = str_replace( "{LOGIN}",          wp_login_url(),                 $Link_Address );
	$Link_Address = str_replace( "{LOGOUT}",         wp_logout_url(),                $Link_Address );
	$Link_Address = str_replace( "{REGISTER}",       wp_registration_url(),          $Link_Address );
	$Link_Address = str_replace( "{LOST-PASSWORD}",  wp_lostpassword_url(),          $Link_Address );
	$Link_Address = str_replace( "{DIR-INCLUDES}",   includes_url(),                 $Link_Address );
	$Link_Address = str_replace( "{DIR-CONTENT}",    content_url(),                  $Link_Address );
	$Link_Address = str_replace( "{DIR-STYLESHEET}", get_stylesheet_directory_uri(), $Link_Address );
	$Link_Address = str_replace( "{DIR-TEMPLATE}",   get_template_directory_uri(),   $Link_Address );

	// Setup Class
	$Prefix = "FLMBTN-";
	$Class  = $Prefix . "Btn";
	$Class .= " " . $Prefix . "Size-"  . $Args['button_size'];
	$Class .= " " . $Prefix . "Color-" . $Args['button_color'];
	
	if ( $Args['rounded_corners']           > 0    ) $Class .= " " . $Prefix . "BR-" . $Args['rounded_corners'];
	if ( $Args['box_shadow']                > 0    ) $Class .= " " . $Prefix . "BS-" . $Args['box_shadow'];
	if ( $Args['text_shadow']               > 0    ) $Class .= " " . $Prefix . "TS-" . $Args['text_shadow'];
	if ( $Args['opacity']                 < 100    ) $Class .= " " . $Prefix . "OP-" . $Args['opacity'];
	if ( $Args['icon_placement']    === "Right"    ) $Class .= " " . $Prefix . "Icon-Right";
	if ( $Args['icon_placement']    === "Only"     ) $Class .= " " . $Prefix . "Icon-Only";
	if ( $Args['small_placement']   === "Left"     ) $Class .= " " . $Prefix . "Small-Left";
	if ( $Args['small_placement']   === "Right"    ) $Class .= " " . $Prefix . "Small-Right";
	if ( $Args['button_style_icon'] !== "None"     ) $Class .= " " . $Prefix . $Args['button_style_icon'];
	if ( $Args['button_style_3d']   !== "None"     ) $Class .= " " . $Prefix . $Args['button_style_3d'];
	if ( $Args['button_hover']      !== "None"     ) $Class .= " " . $Prefix . $Args['button_hover'];
	if ( $Args['animate_icon']      !== "None"     ) $Class .= " " . $Prefix . "AnIco-" . $Args['animate_icon'];
	if ( $Args['animate_button']    !== "None"     ) $Class .= " " . $Prefix . "Anim-" . $Args['animate_button'];
	if ( $Args['transitions']       !== "Disabled" ) $Class .= " " . $Prefix . "Trans";
	
	if ( $Args['custom_border_style'] !== "Default" )
		$Class .= " " . $Prefix . "BorderStyle-" . $Args['custom_border_style'];

	if ( $Args['opacity'] < 100 || $Args['opacity_hover'] < 100 )
		$Class .= " " . $Prefix . "OH-" . $Args['opacity_hover'];
		
	if ( $Args['button_style'] !== "Default" )
	{
			 if ( $Args['button_style'] === "Flat"    ) $Class .= " " . $Prefix . "Flat-"    . $Args['button_color'];
		else if ( $Args['button_style'] === "Border"  ) $Class .= " " . $Prefix . "Border-"  . $Args['button_color'];
		else if ( $Args['button_style'] === "Outline" ) $Class .= " " . $Prefix . "Outline-" . $Args['button_color'];
		else $Class .= " " . $Prefix . $Args['button_style'];
	}
	
	if ( $Args['text_color'] !== "Default" )
	{
		if ( $Args['text_color'] !== "Engrave" ) $Class .= " " . $Prefix . "Text-" . $Args['text_color'];
		else $Class .= " " . $Prefix . $Args['text_color'];
	}
	
	if ( $Args['custom_class'] !== '' )
		$Class .= " " . $Args['custom_class'];
		
	$Font_Class = '';
	if ( strpos( $Args['font_family'], "{" ) !== FALSE )
	{
		$Font_Class = $Args['font_family'];
		$Font_Class = str_replace( "{CLASS-", '', $Font_Class );
		$Font_Class = str_replace( "}",       '', $Font_Class );
		$Font_Class = " " . $Prefix . "Font-" . $Font_Class;
		$Class .= $Font_Class;
	}
	
	// No Icon or Small Text
	if ( $Args['text_only'] === "Yes" )
		$Class .= " " . $Prefix . "Text-Only";
	
	// Build: HTML Code
	$Str  = '<a ';
	$Str .= 'href="' . $Link_Address . '"';

	if ( $Args['link_target'] !== '' )
		$Str .= ' target="' . $Args['link_target'] . '"';

	if ( $Args['link_rel'] !== '' )
		$Str .= ' rel="' . $Args['link_rel'] . '"';

	if ( $Args['link_title'] !== '' )
		$Str .= ' title="' . str_replace( '"', '&#34;', $Args['link_title'] ) . '"';

	// Set Class
	$Str .= ' class="' . $Class . '"';
	
	// Custom Styles
	$Styles = '';

	// Custom Text Color
	if ( $Args['custom_text_color'] !== '' )
		$Styles .= 'color:#' . $Args['custom_text_color'] . ';';
	
	// Custom Background Color
	if ( $Args['custom_bg_color'] !== '' )
		$Styles .= 'background:#' . $Args['custom_bg_color'] . ';';

	// Custom Border Color
	if ( $Args['custom_border_color'] !== '' )
		$Styles .= 'border-color:#' . $Args['custom_border_color'] . ';';
		
	// Custom Border Width
	if ( $Args['custom_border_width'] !== '' )
		$Styles .= 'border-width:' . $Args['custom_border_width'] . 'px;';

	// Button Float
	if ( $Args['button_float'] !== "None" )
		$Styles .= 'float:' . strtolower( $Args['button_float'] ) . ';';
		
	// Custom Font
	if ( $Args['font_family'] !== '' && strpos( $Args['font_family'], "{" ) <= -1 )
		$Styles .= 'font-family:' . str_replace( '"', '', $Args['font_family'] ) . ';';

	// Font Size
	if ( $Args['font_size'] !== '' )
		$Styles .= 'font-size:' . $Args['font_size'] . ';';
		
	// Button Width
	if ( $Args['button_width'] !== '' )
		$Styles .= 'width:' . $Args['button_width'] . ';';

	// Button Height
	if ( $Args['button_height'] !== '' )
		$Styles .= 'height:' . $Args['button_height'] . ';';
		
	// Button Line Height
	if ( $Args['button_line_height'] !== '' )
		$Styles .= 'line-height:' . $Args['button_line_height'] . ';';

	// Append Styles
	if ( $Styles !== '' ) $Str .= ' style="' . $Styles . '"';

	// Append Custom ID
	if ( $Args['custom_id'] !== '' )
		$Str .= ' id="' . $Args['custom_id'] . '"';
		
	$Str .= '>';
	
	// Set Inner
	$Button_Text = $Args['button_text'];
	if ( $Button_Text === '' ) $Button_Text = "Button";
	
	if ( $Button_Text          !== '' ) $Button_Text          = '<span>'  . $Button_Text . '</span>';
	if ( $Args['button_small'] !== '' ) $Args['button_small'] = '<small>' . $Args['button_small'] . '</small>';
	
	if ( $Args['icon'] !== '' )
	{
		$Icon = $Args['icon'];
		$Icon = '<b><i class="fa ' . $Icon . '"';

		if ( $Args['button_line_height'] !== '' || $Args['font_size'] !== '' )
		{
			$Icon .= 'style="';

			if ( $Args['button_line_height'] !== '' )
				$Icon .= 'line-height:' . $Args['button_line_height'] . ';';

			if ( $Args['font_size'] !== '' )
				$Icon .= 'font-size:' . $Args['font_size'] . ';';

			$Icon .= '"';
		}

		$Icon .= '></i></b>';
	}
	
	if ( $Args['icon_placement'] === "Only" ) $Str .= $Icon;
	else if ( $Args['text_only'] === "Yes"  ) $Str .= $Button_Text;
	else
	{
		if ( $Args['icon_placement']  === "Left" ) $Str .= $Icon;
		if ( $Args['small_placement'] === "Left" ) $Str .= $Args['button_small'];

		$Str .= $Button_Text;
		
		if ( $Args['small_placement'] === "Right" ) $Str .= $Args['button_small'];
		if ( $Args['icon_placement']  === "Right" ) $Str .= $Icon;
	}

	$Str .= '</a>';
	
	// Apply filter
	$Str = apply_filters( "flmbtn_button_output", $Str, $Args );
	
	// Echo Button
	if ( $Echo ) echo $Str;
	
	return $Str;
}
?>
<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cunter config.
 *
 * @class 		Note_Shortcode
 * @version		1.0
 * @package		Note/Classes/for shortcode
 * @category	Class
 * @author 		Mandegarweb
 */
/**
* 
*/
/**
* Path to the includes directory.
 *
 * @var string
*/
/**
*
 *include config  class
*/
class Note_Shortcode 
{

	function __construct()
	{
	 add_shortcode('Note', array(&$this,'mandegarweb_Note_cilent'));
	 add_shortcode('note-login', array(&$this,'mandegarweb_note_login'));
	 add_action('wp_enqueue_scripts',array(&$this,'Note_js_and_css'));
	 add_action('wp_ajax_mandegarweb_save_note',array(&$this,'wp_ajax_mandegarweb_save_note')); 
	 add_action('init',array(&$this,'create_account_user'));

	}
	function validate_mobile($mobile)
	{
	    return preg_match('/^[0-9]+$/', $mobile);
	}
	function create_account_user()
	{
	   if (isset($_POST["cn_user"])) {

        $error = new WP_Error();
	   	$mobile = ( isset($_POST['umobile']) ? $_POST['umobile'] : '' );
	   	$email = ( isset($_POST['uemail']) ? $_POST['uemail'] : '' );
	    $pass = ( isset($_POST['upass']) ? $_POST['upass'] : '' );
		$passa = ( isset($_POST['upassa']) ? $_POST['upassa'] : '' );
		$E=0;
		if (empty($mobile)) {
			$E=1;
		}
		if ($this->validate_mobile($mobile)==false) {
		 	$E=1;
		 	}
		if (strlen($mobile)!=11) {
		 	$E=1;
		 	}
		if (empty($email)) {
			$E=1;
		}
		if (!is_email(esc_attr($email)))
        {
         $E=1;
        }
		if (empty($pass)) {
			$E=1;
		}
		if ($passa!=$pass) {
			$E=1;
		}
		if ( username_exists( 	$mobile )  ) 
		{
			$E=1;
		}
		if ( email_exists( $email ) ) 
		{
			$E=1;

		}
		if ($E==0) {

			 $user_id = wp_create_user( $mobile, $pass, $email );
           if( !is_wp_error($user_id) ) 
           {

           	$data["note"]="این یک یادداشت نمونه است. شما می‌توانید آن را حذف و یا ویرایش کنید. برای دسترسی به دکمه‌های ویرایش و حذف ماوس خود را روی متن آورده و از دکمه‌هایی که بالای یادداشت ظاهر می‌شود استفاده کنید. در صورتی که از موبایل و یا تبلت استفاده می‌کنید برای مشاهده این دکمه‌ها بر روی یادداشت کلیک کنید.";
           	$data["id_user"]= $user_id; 
           	$date=date("Y-m-d H:i:s"); 
			if (function_exists('jdate'))
			{
			 $date=jdate('Y-m-d H:i:s');
			}$data["date"]=$date;
           	global $wpdb;
		  	 $table=$wpdb->prefix."note";
		  	 $wpdb->insert($table,$data);
	  	      
           //	$GUID= get_page_link(get_the_ID());
           //	wp_redirect( home_url()."/note" );
           // exit;
           }
			
		}

	
		}

	}
	function mandegarweb_note_login()
	{
      

	if ( ! is_user_logged_in() ) { // Display WordPress login form:
$error="";
    if (isset($_POST["cn_user"])) {
		
		$mobile = ( isset($_POST['umobile']) ? $_POST['umobile'] : '' );
	   	$email = ( isset($_POST['uemail']) ? $_POST['uemail'] : '' );
	    $pass = ( isset($_POST['upass']) ? $_POST['upass'] : '' );
		$passa = ( isset($_POST['upassa']) ? $_POST['upassa'] : '' );
		$E=0;
		if (empty($mobile)) {
			$error='<b class="bold red" > شماره موبایل خالی است </b><br/>';
		}
		if ($this->validate_mobile($mobile)==false) {
		 	$error='<b class="bold red" > شماره موبایل نامعتبر! مقدار شماره موبایل باید عددی باشد  </b><br/>'; 
		 	}
		if (strlen($mobile)!=11) {
		 	$error='<b class="bold red" > شماره موبایل باید 11 رقم باشد  </b><br/>';  
		 	}
		if (empty($email)) {
			$error='<b class="bold red" > ایمیل خالی است </b><br/>';
		}
		if (!is_email(esc_attr($email)))
        {
           $error='<b class="bold red" > ایمیل معتبر نیست </b><br/>';

        }
		if (empty($pass)) {
			$error='<b class="bold red" > کلمه عبور خالی است </b><br/>';
		}
		if ($passa!=$pass) {
			$error='<b class="bold red" > کلمه عبور وارد شده یکسان نیستند </b><br/>';
		}
		if ( !username_exists( 	$mobile )  ) 
		{
			$error='<b class="bold red" > این شماره تلفن قبلا ثبت  شده </b><br/>';
		}
		if ( !email_exists( $email ) ) 
		{
			$error='<b class="bold red" > این ایمیل قبلا ثبت شده  </b><br/>';

		}

		if (empty($error)) {

			$error='<b class="bold green" > ثبت نام با موفقیت انجام شد . هم اکنون مستوانید وارد شوید  </b><br/>';

		}
		

	
		}






		echo "<div class='note-user'>";
			echo "<div class='note-login'>";
		    $args = array(
		        'redirect' => home_url()."/note", 
		        'form_id' => 'loginform-custom',
		        'label_username' => __( 'ایمیل یا شماره  موبایل ' ),
		        'label_password' => __( 'کلمه عبور ' ),
		        'label_remember' => __( 'مرا به خاطر بسپار ' ),
		        'label_log_in' => __( 'ورود ' ),
		        'remember' => true
		    );
		    wp_login_form( $args );
		  
           
		    echo "</div>";
		    echo '<div class="note-register">
		        '.$error.'
			    <form method="post" action="">
			        <label>ایمیل   </label>  
			        <input id="email" type="text" name="uemail" />
			        <label>موبایل  </label>  
			        <input type="text"  name="umobile" />
			        <label> کلمه عبور  </label>
			        <input type="password"  name="upass" />
			        <label>تکرار کلمه عبور  </label> 
			        <input type="password"  name="upassa" />
			         <input type="submit" value="عضویت " name="cn_user" />
		       </form>';
		    echo "</div>";
		echo "</div>";

		} 

	}
	function wp_ajax_mandegarweb_save_note()
	{
		$id=0;
		$response= array(); 
	  if (isset($_POST["command"])  ) 
	  {
         global $wpdb;
	  	 $table=$wpdb->prefix."note";
	  	 $data["note"]=trim($_POST["note"]);
	  	 $id_user= get_current_user_id() ;
	  	 $data["id_user"]=$id_user;
	  	 switch ($_POST["command"]) {
	  	 	case 'new':
	  	 	   $date=date("Y-m-d H:i:s"); 
			 	if (function_exists('jdate'))
			 	{
				  $date=jdate('Y-m-d H:i:s');
			    }$data["date"]=$date;
			    $response["date"]=$date;
			    $wpdb->insert($table,$data);
	  	        $id=$wpdb->insert_id;
	  	 		break;
	  	 	case 'edit':
	  	 	    $item=intval(str_replace("item-","", $_POST["item"]));  
	  	 		$wpdb->update($table,$data, array('id' => $item,"id_user"=>$id_user));
	  	        $id=$item;
	  	 		break;
	  	 	case 'done':
	  	 	    $item=intval(str_replace("c","", $_POST["item"]));  
	  	 		$wpdb->update($table,array("do"=>intval($_POST["done"])), array('id' => $item,"id_user"=>$id_user));
	  	        $id=$item;
	  	 		break;

	  	 	case 'remove':
	  	 	    $item=intval(str_replace("item-","", $_POST["item"]));  
                $wpdb->delete($table,array("id"=>$item));
	  	        $id=$item;
	  	 		break;
	  	 	default:
	  	 		# code...
	  	 		break;
	  	 }
	  	
	  }
     $response["id"]=$id; 
	  echo  json_encode($response);
	  exit();

	}
	function Note_js_and_css()
	{
	 wp_register_style('note_css', plugins_url('/css/style.css', __FILE__) );
     wp_enqueue_style( 'note_css' );	
     wp_enqueue_script( "note_js", plugin_dir_url( __FILE__ ) . 'js/note.js', array( 'jquery' ) );
     wp_localize_script( 'note_js', 'the_lab_url', array( 'lab_url' => admin_url( 'admin-ajax.php' ) ) ); 	
	}
	function mandegarweb_Note_cilent()
	{

		$id_user=get_current_user_id();
		if ($id_user >=1 ) {
			
		$HTMLS='<div class="note" id="notes">';

		$HTMLS.='
		
		<div class="note-item add">
		
			<h3>یادداشت جدید</h3>
			  <textarea 
			    placeholder="اینجا کلیک کنید..."
			   id="foo" class="autoExpand" cols="11" var rows="7" data-min-rows="3"></textarea> 
			   <div class="buttonHolder">
                    <button id="newnot">ذخیره&nbsp;<i class="fa fa-floppy-o" aria-hidden="true"></i></button>
                </div>
			
			</div>';

             global $wpdb;
	         $table=$wpdb->prefix."note";
	         $notes=$wpdb->get_results("SELECT * FROM $table WHERE id_user=$id_user");
	         foreach ($notes as  $value) { 

	         	$checked="";
	         	if ($value->do==1) {
	         		$checked="checked";
	         	}

       
			$HTMLS.='<div class="note-item" id="item-'.$value->id.'">

			 <div class="icon">
			     <i data-id="item-'.$value->id.'" class="fa fa-times right remove-item" ></i>
                 <i data-id="item-'.$value->id.'" class="fa fa-pencil-alt left edit-item" ></i>
			 </div>

			 <p>'.trim($value->note).'</p>
			 
			   <div class="buttonHolder">
                   <div class="can-toggle can-toggle--size-large">
				  <input id="c'.$value->id.'" type="checkbox" '.$checked.'>
				  <label for="c'.$value->id.'">
				    <div class="can-toggle__switch" data-checked="انجام شد" data-unchecked="انجام نشد"></div>
				  </label>
				  <span class="date">'.$value->date.'</span>
				</div>
                </div>
			
			</div>
			';
        }
     
         $HTMLS.=' <div id="id01" class="modal" >
			  <div class="modal-content animate" >
			    <div class="imgcontainer">
			      <span  class="boxclose" title="Close Modal"</span>
			    </div>

			    <div class="container-modal">
			     
			    </div>

			    
			  </div>
			</div>';

			 $HTMLS.=' <div id="loader" class="modal" >
			  <div class="modal-content animate" >
			    <div class="imgcontainer">
			      <span  class="boxclose" title="Close Modal"</span>
			    </div>

			    
			     <div class="loader"></div>
			   

			    
			  </div>
			</div>';

            $HTMLS.='</div>';

            return $HTMLS;
        }
	}

}new Note_Shortcode() ; 




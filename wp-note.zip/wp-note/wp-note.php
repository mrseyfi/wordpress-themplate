<?php 
/**
* Plugin Name: Note and Reminder  
* Plugin URI: http://mandegarweb.com/%d8%b3%d9%81%d8%a7%d8%b1%d8%b4-%d8%b7%d8%b1%d8%a7%d8%ad%db%8c-%d8%a7%d9%81%d8%b2%d9%88%d9%86%d9%87-%d8%a7%d8%ae%d8%aa%d8%b5%d8%a7%d8%b5%db%8c-%d9%88%d8%b1%d8%af%d9%be%d8%b1%d8%b3/
* Description: A Plugin For Save Note Customer
* Version: 1.0.0
* Author: Mandegarweb Team
* Author URI: http://mandegarweb.com/
 *
 * @package Note
 * @category Wordpress
 * @author Mandegarweb
*
*/

/*
*
*check for correct directory
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'Note' ) ) :
/**
* 
*define Cunter  class
* @version 1.0
*/
class Note 
{
/**
 * WooCommerce version.
 *
 * @var string
*/
	public $version = '1.0.0';
/**
*
 *@var string
*/

	function __construct()
	{

	register_activation_hook( __FILE__,array(__CLASS__, 'mandegarweb_activate_pliugin' ));
    include_once('inc/shortcode.php');
    //include_once('inc/menue.php');
	}
	function mandegarweb_activate_pliugin()
	{
		global $wpdb;
		$table=$wpdb->prefix."note";
		if($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
		 $databaser=$wpdb->query("CREATE TABLE IF NOT EXISTS `$table` (
		  `id` int(255) NOT NULL AUTO_INCREMENT,
		  `note` longtext CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
		  `do` tinyint(1) NOT NULL DEFAULT '0',
		  `date` varchar(255) CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL,
		  `id_user` int(255) NOT NULL,
		  PRIMARY KEY (`id`)
		) ENGINE=InnoDB DEFAULT CHARSET=latin1;");
	   }
	    	
	}
}
$load=new Note();
endif;?>

<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>

<div class="totalpoll-buttons">
	<?php echo implode( '', $this->buttons() ); ?>
</div>

</form>
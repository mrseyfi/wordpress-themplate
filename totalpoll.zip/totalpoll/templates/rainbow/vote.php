<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>
<?php include 'partials/vote/errors.php'; ?>
<?php include 'partials/question.php'; ?>
<?php include 'partials/vote/choices.php'; ?>
<?php include 'partials/vote/fields.php'; ?>
<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>

<?php echo $this->poll->settings( 'results', 'hide', 'content' ); ?>
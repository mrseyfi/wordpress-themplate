<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>

<div class="totalpoll-result-progress-container">
	<div class="totalpoll-result-progress" style="width: <?php echo $choice['votes%']; ?>%"></div>
</div>
<?php
if ( defined( 'ABSPATH' ) === false ) :
	exit;
endif; // Shhh
?>
<div class="totalpoll-choice-label" itemprop="text"><?php echo $choice['content']['label']; ?></div>
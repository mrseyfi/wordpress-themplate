	function imagemaps() {
   

  var img = document.getElementById('imageid'); 
		//or however you get a handle to the IMG
   
		var width = img.clientWidth;
		var height = img.clientHeight;

		var stepx=width/17;
		var stepy=height/10;
    //20,40,180,180
      var x0=20; 
      var y0=10;
      var coords7= stepx+','+(1.5*stepy)+','+(4*stepx)+','+(4.5*stepy);
      var x = document.getElementById("step7").coords=coords7;
      //100,200,200,300
      var coords6= (3*stepx)+','+(4.5*stepy)+','+(5.5*stepx)+','+(7*stepy);
      var x = document.getElementById("step6").coords=coords6;

      //100,200,200,300
      var coords5= (7.5*stepx)+','+(3*stepy)+','+(10*stepx)+','+(6*stepy);
      var x = document.getElementById("step5").coords=coords5;
      
       var coords4= (10*stepx)+','+(1.5*stepy)+','+(12*stepx)+','+(4.5*stepy);
       var x = document.getElementById("step4").coords=coords4;

       var coords3= (11.5*stepx)+','+(.1*stepy)+','+(14*stepx)+','+(2.5*stepy);
       var x = document.getElementById("step3").coords=coords3;

       var coords2= (13*stepx)+','+(2*stepy)+','+(16*stepx)+','+(5*stepy);
       var x = document.getElementById("step2").coords=coords2;

        var coords1= (14.5*stepx)+','+(5*stepy)+','+(17*stepx)+','+(8*stepy);
        var x = document.getElementById("step1").coords=coords1;
}
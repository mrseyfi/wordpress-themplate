<?php 
/**
* Plugin Name: Image Maps
* Plugin URI: 
* Description:A plugin Show Image Map
*
* Version: 1.0.0
* Author: Behzad Rohizadeh
* Author URI: 
*
 * @package Image
 * @category Wordpress
 * @author Behzad Rohizadeh
*
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
add_shortcode('imagemap','imagemap_sdkhgfj_wfwje');
add_action('wp_enqueue_scripts','imagemap_js_and_css');
function imagemap_sdkhgfj_wfwje($attr)
{
  
 $width=(isset($attr['w'])) ? intval($attr['w']) : 600; 
 //$height=(isset($attr['h'])) ? intval($attr['h']) : 600; 
return '
<img id="imageid" class="map" src="'.plugin_dir_url( __FILE__ ).'img/map.jpg" width="'.$width.'"  alt="Planets" usemap="#planetmap" onload="imagemaps()">

<map name="planetmap">
  <area id="step7" shape="rect" coords="20,40,180,180" alt="گام 7" href="https://griffin.titanicuk.org/griffin-map-success/step-7/" >
 
   <area id="step6" shape="rect" coords="100,200,200,300" alt="گام 6" href="https://griffin.titanicuk.org/griffin-map-success/step-6/" >

   <area id="step5" shape="rect" coords="250,140,350,240" alt="گام 5" href="https://griffin.titanicuk.org/griffin-map-success/step-5/" >


   <area id="step4" shape="rect" coords="350,100,450,180" alt="گام 4" href="https://griffin.titanicuk.org/griffin-map-success/step-4/" >


   <area id="step3" shape="rect" coords="400,10,500,100" alt="گام 3" href="https://griffin.titanicuk.org/griffin-map-success/step-3/" >


   <area id="step2" shape="rect" coords="450,100,550,200" alt="گام 2" href="https://griffin.titanicuk.org/griffin-map-success/step-2/" >

    <area id="step1" shape="rect" coords="500,200,600,310" alt="گام 1" href="https://griffin.titanicuk.org/griffin-map-success/step-1/" >

</map>';



}
function imagemap_js_and_css()
{
     wp_enqueue_script( "imagemap", plugin_dir_url( __FILE__ ) . 'js/imagemap.js', array( 'jquery' ) );

}
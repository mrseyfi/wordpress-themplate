jQuery( document ).ready( function ($) {

    /***** Colour picker *****/

    jQuery('.colorpicker').hide();
    jQuery('.colorpicker').each( function() {
        jQuery(this).farbtastic( jQuery(this).closest('.color-picker').find('.color') );
    });

    jQuery('.color').click(function() {

        if (jQuery(this).val().length == 0) {
            jQuery(this).val(' ');
        }

        jQuery(this).closest('.color-picker').find('.colorpicker').fadeIn();
    });

    jQuery(document).mousedown(function() {
        jQuery('.colorpicker').each(function() {
            var display = jQuery(this).css('display');
            if ( display == 'block' )
                jQuery(this).fadeOut();
        });
    });


  var defaults = {
      color             : '#64bd63'
    , secondaryColor    : '#dfdfdf'
    , jackColor         : '#fff'
    , jackSecondaryColor: null
    , className         : 'night-mode-wp-switch'
    , disabled          : false
    , disabledOpacity   : 0.5
    , speed             : '0.4s'
    , size              : 'default'
  };

	// Switcher init 
	var elems = Array.prototype.slice.call(document.querySelectorAll('.osny-nightmode-js-switch'));
	elems.forEach(function(html) {
	  var switchery = new Switchery(html,defaults);
	});

	// Switcher button change 
    jQuery(document).on('change', '.osny-nightmode-js-switch', function(){
    	var name = jQuery(this)[0].name;
    	 var isChecked = jQuery(this)[0].checked;

    	if (name == 'osny_nightmode_show_icon') {
  			if (isChecked == false) {
  				jQuery('input[name="osny_nightmode_toggle_icons"]').removeAttr('checked');
  				jQuery('input[name="osny_nightmode_toggle_icons"]').next().css('box-shadow', '0px 0px 0px 16px #fff inset').css('border-color', '#dfdfdf');
  				jQuery('input[name="osny_nightmode_toggle_icons"]').next().find('small').css('left', '0px');
  			}	
    	}

    	if (name == 'nightmode_toggle_icons') {
  			if (isChecked == true) {
  				jQuery('input[name="osny_nightmode_show_icon"]').attr('checked', true);
  				jQuery('input[name="osny_nightmode_show_icon"]').next().css('box-shadow', '0px 0px 0px 16px #13bf11 inset').css('border-color', '#dfdfdf');
  				jQuery('input[name="osny_nightmode_show_icon"]').next().find('small').css('left', '20px');
  			}
    	}
	});



    // Reset Inputs to default color
    jQuery('#nightmode-default-color-on').click(function(){
      jQuery('input[name="osny_nightmode_switch_on_color"]').val('#13bf11');
      jQuery('input[name="osny_nightmode_switch_on_color"]').css('background-color', '#13bf11');
      return false;
    });

    jQuery('#nightmode-default-color-off').click(function(){
      jQuery('input[name="osny_nightmode_switch_off_color"]').val('#fff');
      jQuery('input[name="osny_nightmode_switch_off_color"]').css('background-color', '#fff');
      return false;
    });

    jQuery('#nightmode-default-bg-color').click(function(){
      jQuery('input[name="osny_nightmode_background_color"]').val('#1b2836');
      jQuery('input[name="osny_nightmode_background_color"]').css('background-color', '#1b2836');
      return false;
    });
    
    jQuery('#nightmode-default-switch-color-on').click(function(){
      jQuery('input[name="osny_nightmode_switch_button_on_color"]').val('#fff').css('color', '#000');
      jQuery('input[name="osny_nightmode_switch_button_on_color"]').css('background-color', '#fff');
      return false;
    });

    jQuery('#nightmode-default-switch-color-off').click(function(){
      jQuery('input[name="osny_nightmode_switch_button_off_color"]').val('#fff').css('color', '#000');
      jQuery('input[name="osny_nightmode_switch_button_off_color"]').css('background-color', '#fff');
      return false;
    });

    jQuery('#nightmode-default-text-color').click(function(){
      jQuery('input[name="osny_nightmode_text_color"]').val('#fff').css('color', '#000');
      jQuery('input[name="osny_nightmode_text_color"]').css('background-color', '#fff');
      return false;
    });

    jQuery('#nightmode-default-link-color').click(function(){
      jQuery('input[name="osny_nightmode_link_color"]').val('#459BE6');
      jQuery('input[name="osny_nightmode_link_color"]').css('background-color', '#459BE6');
      return false;
    });

    jQuery('#nightmode-empty-header-footer-color').click(function(){
      jQuery('input[name="osny_nightmode_header_footer_color"]').val('');
      jQuery('input[name="osny_nightmode_header_footer_color"]').css('background-color', '#fff');
      return false;
    });

    jQuery('#nightmode-default-header-footer-color').click(function(){
      var night_mode_bg_color = jQuery('input[name="osny_nightmode_background_color"]').val();
      var secondaryColor = generateColor(night_mode_bg_color, 10);

      jQuery('input[name="osny_nightmode_header_footer_color"]').val(secondaryColor);
      jQuery('input[name="osny_nightmode_header_footer_color"]').css('background-color', secondaryColor);

      var night_mode_color = jQuery('input[name="osny_nightmode_text_color"]').val();
      jQuery('input[name="osny_nightmode_header_footer_color"]').css('color', night_mode_color);
      return false;
    });

    function generateColor(color, percent) {
        var num = parseInt(color.slice(1), 16),
            amt = Math.round(2.55 * percent),
            R = (num >> 16) + amt,
            G = (num >> 8 & 0x00FF) + amt,
            B = (num & 0x0000FF) + amt;
        return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 + (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 + (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
    }
});
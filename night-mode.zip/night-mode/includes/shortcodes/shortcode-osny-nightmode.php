<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Shortcode to disapy Night Mode [nightmode]
*/

add_shortcode("nightmode", "OSNY_NightMode_Shortcode");
function OSNY_NightMode_Shortcode() { 
	global $base;
	$css_position_prefix = 'osny-nightmode--';
	$switch_title = esc_html( get_option( $base . 'switch_title' ) );
	$show_icon = esc_html( get_option( $base . 'show_icon' ) );
	$switch_position = !empty( get_option( $base . 'switch_position' ) ) ? esc_html( get_option( $base . 'switch_position' ) ) : "left";
	$switch_position = $css_position_prefix . $switch_position;
	
	$random_id = 'nightmode-' . wp_generate_password( 3, false );
?>
<div class="osny-nightmode <?php echo $switch_position; ?>">
	<div class="osny-night-mode-wp__container">
		<?php if ( $show_icon == "on" ): ?>
			<i class="night-mode-wp-moon-o"></i>
			<i class="night-mode-wp-light-up"></i>
		<?php endif ?>
		<input type="checkbox" class="osny-nightmode-switch-wp" id="<?php echo $random_id; ?>">
		<small class="osny-nightmode__title"><?php echo $switch_title; ?></small>
	</div>
</div>
<?php } ?>
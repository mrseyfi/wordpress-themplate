<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class OSNY_NightMode_Settings {

	/**
	 * The single instance of OSNY_NightMode_Settings.
	 * @var 	object
	 * @access  private
	 * @since 	1.0.0
	 */
	private static $_instance = null;

	/**
	 * The main plugin object.
	 * @var 	object
	 * @access  public
	 * @since 	1.0.0
	 */
	public $parent = null;

	/**
	 * Prefix for plugin settings.
	 * @var     string
	 * @access  public
	 * @since   1.0.0
	 */

	public $base = '';

	/**
	 * Available settings for plugin.
	 * @var     array
	 * @access  public
	 * @since   1.0.0
	 */
	public $settings = array();

	public function __construct ( $parent ) {
		$this->parent = $parent;

		$this->base = $GLOBALS['base'];

		// Initialise settings
		add_action( 'init', array( $this, 'init_settings' ), 11 );

		// Register plugin settings
		add_action( 'admin_init' , array( $this, 'register_settings' ) );

		// Add settings page to menu
		add_action( 'admin_menu' , array( $this, 'add_menu_item' ) );

		// Add settings link to plugins page
		add_filter( 'plugin_action_links_' . plugin_basename( $this->parent->file ) , array( $this, 'add_settings_link' ) );
	}

	/**
	 * Initialise settings
	 * @return void
	 */
	public function init_settings () {
		$this->settings = $this->settings_fields();
	}

	/**
	 * Add settings page to admin menu
	 * @return void
	 */
	public function add_menu_item () {
		$page = add_options_page( __( 'Night Mode', 'osny-nightmode' ) , __( 'Night Mode', 'osny-nightmode' ) , 'manage_options' , $this->parent->_token . '_settings' ,  array( $this, 'settings_page' ) );
		add_action( 'admin_print_styles-' . $page, array( $this, 'settings_assets' ) );
	}

	/**
	 * Load settings JS & CSS
	 * @return void
	 */
	public function settings_assets () {
		wp_enqueue_style( 'farbtastic' );
    	wp_enqueue_script( 'farbtastic' );
	}

	/**
	 * Add settings link to plugin list table
	 * @param  array $links Existing links
	 * @return array 		Modified links
	 */
	public function add_settings_link ( $links ) {
		$settings_link = '<a href="options-general.php?page=' . $this->parent->_token . '_settings">' . __( 'Settings', 'osny-nightmode' ) . '</a>';
  		array_push( $links, $settings_link );
  		return $links;
	}

	/**
	 * Build settings fields
	 * @return array Fields to be displayed on settings page
	 */
	private function settings_fields () {

		$settings['standard'] = array(
			'title'					=> __( 'Settings', 'osny-nightmode' ),
			'description'			=> __( '-You can use Night mode as <a href="/wp-admin/widgets.php">Widget</a>.<br>
											-Or can check "Add Night Mode before content" in below to add Night mode button automatically before content.<br>
											-Also you can copy this <code>[nightmode]</code> shortcode and past in post/page.', 'osny-nightmode' ),
			'fields'				=> array(
				array(
					'id' 			=> 'switch_title',
					'label'			=> __( 'Night Mode Title' , 'osny-nightmode' ),
					'description'	=> __( 'Text beside Night Mode switch.', 'osny-nightmode' ),
					'type'			=> 'text',
					'default'		=> '',
					'placeholder'	=> __( 'Night mode', 'osny-nightmode' )
				),
				array(
					'id' 			=> 'add_above_content_posts',
					'label'			=> __( 'Add above content in posts', 'osny-nightmode' ),
					'description'	=> __( 'This will add Night Mode above content in posts.', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'on'
				),
				array(
					'id' 			=> 'add_above_content_pages',
					'label'			=> __( 'Add above content in pages', 'osny-nightmode' ),
					'description'	=> __( 'This will add Night Mode above content in pages.', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'off'
				),
				array(
					'id' 			=> 'show_on_home',
					'label'			=> __( 'Show on home page', 'osny-nightmode' ),
					'description'	=> __( 'Check ON to see Night Mode switch in home page.', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'off'
				),
				array(
					'id' 			=> 'stay_on_with_navigation',
					'label'			=> __( 'Stay on with navigation', 'osny-nightmode' ),
					'description'	=> __( 'When Night Mode ON and start navigation, will automatically activate. ', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'off'
				),
				array(
					'id' 			=> 'show_icon',
					'label'			=> __( 'Show moon icon', 'osny-nightmode' ),
					'description'	=> __( 'Moon icon beside switch.', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'on'
				),
				array(
					'id' 			=> 'toggle_icons',
					'label'			=> __( 'Switch icon', 'osny-nightmode' ),
					'description'	=> __( 'Switch between sun and moon icons.', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'on'
				),
				array(
					'id' 			=> 'img_opacity',
					'label'			=> __( 'Image Opacity', 'osny-nightmode' ),
					'description'	=> __( 'Check ON to see images opacity 0.5 when Night Mode ON, PS: when mouse hover you can see image normal', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'off'
				),
				array(
					'id' 			=> 'img_filter',
					'label'			=> __( 'Images filter', 'osny-nightmode' ),
					'description'	=> __( 'Check ON to see images filter grayscale 50% when Night Mode ON, PS: when mouse hover you can see image normal.', 'osny-nightmode' ),
					'type'			=> 'checkbox',
					'default'		=> 'off'
				),
				array(
					'id' 			=> 'switch_position',
					'label'			=> __( 'Night Mode position', 'osny-nightmode' ),
					'description'	=> __( 'Select Night Mode button position', 'osny-nightmode' ),
					'type'			=> 'select',
					'options'		=> array( 'left' => 'Left', 'center' => 'Center', 'right' => 'Right' ),
					'default'		=> array( 'center' )
				),
				array(
					'id' 			=> 'switch_on_color',
					'label'			=> __( 'Night Mode "ON" color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-default-color-on">Default</a> - Switch button background color when ON.', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> '#13bf11'
				),
				array(
					'id' 			=> 'switch_off_color',
					'label'			=> __( 'Night Mode "OFF" color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-default-color-off">Default</a> - Switch button background color when OFF.', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> '#fff'
				),
				array(
					'id' 			=> 'switch_button_on_color',
					'label'			=> __( 'Night Mode button "ON" color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-default-switch-color-on">Default</a> - Switch cirecle button color when ON.', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> '#fff'
				),
				array(
					'id' 			=> 'switch_button_off_color',
					'label'			=> __( 'Night Mode button "OFF" color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-default-switch-color-off">Default</a> - Switch cirecle button background color when OFF.', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> '#fff'
				),
				array(
					'id' 			=> 'background_color',
					'label'			=> __( 'Night Mode background color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-default-bg-color">Default</a> - Web page background color when Night Mode ON.', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> '#1b2836'
				),
				array(
					'id' 			=> 'header_footer_color',
					'label'			=> __( 'Night Mode Header/footer color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-empty-header-footer-color">Empty</a> - Leave empty will not change header/footer color.<br><a href="#" id="nightmode-default-header-footer-color">Default - Generate from "Night Mode background color".</a> - header and footer color, by default this generate from "Night Mode background color".', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> ''
				),
				array(
					'id' 			=> 'text_color',
					'label'			=> __( 'Night Mode text color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-default-text-color">Default</a> - text color when Night Mode ON.', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> '#fff'
				),
				array(
					'id' 			=> 'link_color',
					'label'			=> __( 'Links color', 'osny-nightmode' ),
					'description'	=> __( '<a href="#" id="nightmode-default-link-color">Default</a> - Links color when Night Mode ON.', 'osny-nightmode' ),
					'type'			=> 'color',
					'default'		=> '#459BE6'
				),
			)
		);



		$settings = apply_filters( $this->parent->_token . '_settings_fields', $settings );

		return $settings;
	}

	/**
	 * Register plugin settings
	 * @return void
	 */
	public function register_settings () {
		if ( is_array( $this->settings ) ) {

			// Check posted/selected tab
			$current_section = '';
			if ( isset( $_POST['tab'] ) && $_POST['tab'] ) {
				$current_section = $_POST['tab'];
			} else {
				if ( isset( $_GET['tab'] ) && $_GET['tab'] ) {
					$current_section = $_GET['tab'];
				}
			}

			foreach ( $this->settings as $section => $data ) {

				if ( $current_section && $current_section != $section ) continue;

				// Add section to page
				add_settings_section( $section, $data['title'], array( $this, 'settings_section' ), $this->parent->_token . '_settings' );

				foreach ( $data['fields'] as $field ) {

					// Validation callback for field
					$validation = '';
					if ( isset( $field['callback'] ) ) {
						$validation = $field['callback'];
					}

					// Register field
					$option_name = $this->base . $field['id'];
					register_setting( $this->parent->_token . '_settings', $option_name, $validation );

					// Add field to page
					add_settings_field( $field['id'], $field['label'], array( $this->parent->admin, 'display_field' ), $this->parent->_token . '_settings', $section, array( 'field' => $field, 'prefix' => $this->base ) );
				}

				if ( ! $current_section ) break;
			}
		}
	}

	public function settings_section ( $section ) {
		$html = '<p> ' . $this->settings[ $section['id'] ]['description'] . '</p>' . "\n";
		echo $html;
	}

	/**
	 * Load settings page content
	 * @return void
	 */
	public function settings_page () {

		// Build page HTML
		$html = '<div class="wrap" id="' . $this->parent->_token . '_settings">' . "\n";
			$html .= '<h2>' . __( 'Night Mode V3.0.0       —       <small style="font-size:16px;"><a href="https://codecanyon.net/item/night-mode-for-wordpress/19502073" target="_blank">Rate me &#9734;&#9734;&#9734;&#9734;&#9734;</a></small>' , 'osny-nightmode' ) . '</h2>' . "\n";

			$tab = '';
			if ( isset( $_GET['tab'] ) && $_GET['tab'] ) {
				$tab .= $_GET['tab'];
			}

			// Show page tabs
			if ( is_array( $this->settings ) && 1 < count( $this->settings ) ) {

				$html .= '<h2 class="nav-tab-wrapper">' . "\n";

				$c = 0;
				foreach ( $this->settings as $section => $data ) {

					// Set tab class
					$class = 'nav-tab';
					if ( ! isset( $_GET['tab'] ) ) {
						if ( 0 == $c ) {
							$class .= ' nav-tab-active';
						}
					} else {
						if ( isset( $_GET['tab'] ) && $section == $_GET['tab'] ) {
							$class .= ' nav-tab-active';
						}
					}

					// Set tab link
					$tab_link = add_query_arg( array( 'tab' => $section ) );
					if ( isset( $_GET['settings-updated'] ) ) {
						$tab_link = remove_query_arg( 'settings-updated', $tab_link );
					}

					// Output tab
					$html .= '<a href="' . $tab_link . '" class="' . esc_attr( $class ) . '">' . esc_html( $data['title'] ) . '</a>' . "\n";

					++$c;
				}

				$html .= '</h2>' . "\n";
			}

			$html .= '<form method="post" action="options.php" enctype="multipart/form-data">' . "\n";

				// Get settings fields
				ob_start();
				settings_fields( $this->parent->_token . '_settings' );
				do_settings_sections( $this->parent->_token . '_settings' );
				$html .= ob_get_clean();

				$html .= '<p class="submit">' . "\n";
					$html .= '<input type="hidden" name="tab" value="' . esc_attr( $tab ) . '" />' . "\n";
					$html .= '<input name="Submit" type="submit" class="button-primary" value="' . esc_attr( __( 'Save Settings' , 'osny-nightmode' ) ) . '" />' . "\n";
				$html .= '</p>' . "\n";
			$html .= '</form>' . "\n";
		$html .= '</div>' . "\n";

		echo $html;
	}

	/**
	 * Main OSNY_NightMode_Settings Instance
	 *
	 * Ensures only one instance of OSNY_NightMode_Settings is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 * @static
	 * @see OSNY_NightMode()
	 * @return Main OSNY_NightMode_Settings instance
	 */
	public static function instance ( $parent ) {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self( $parent );
		}
		return self::$_instance;
	} // End instance()

}
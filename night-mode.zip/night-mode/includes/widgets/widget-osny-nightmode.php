<?php

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Night Mode Widget Class
 *
 * @since  1.0.0
 * @return widget html
 */

// Creating the widget 

if( !class_exists( 'OSNY_NightMode_Widget' ) ) {

class OSNY_NightMode_Widget extends WP_Widget {
	private $css_position_prefix = 'osny-nightmode--';
	function __construct() {
		$widget_ops = array(
			'classname' => 'OSNY_NightMode_Widget',
			'description' => 'Night Mode Widget',
		);
		parent::__construct( 'nightmode', 'Night Mode', $widget_ops );
	}

	// Creating widget front-end
	public function widget( $args, $instance ) {

		$title = apply_filters( 'widget_title', $instance['title'] );

		$switch_position = $this->css_position_prefix . $instance[ 'switch_position' ];
		global $base;
		$switch_title = esc_html( get_option( $base . 'switch_title' ) );
		$show_icon = esc_html( get_option( $base . 'show_icon' ) );
		$random_id = 'nightmode-' . wp_generate_password( 3, false );

		// before and after widget arguments are defined by themes
		echo $args['before_widget'];
		if ( !empty( $title ) && empty( $instance['hide_title'] ) ){
			echo $args['before_title'] . $title . $args['after_title'];
		}
	?>
<div class="osny-nightmode <?php echo $switch_position; ?>">
	<div class="osny-night-mode-wp__container">
		<?php if ( $show_icon == "on" ): ?>
			<i class="night-mode-wp-moon-o"></i>
			<i class="night-mode-wp-light-up"></i>
		<?php endif ?>	
		<input type="checkbox" class="osny-nightmode-switch-wp" id="<?php echo $random_id; ?>">
		<small class="osny-nightmode__title"><?php echo $switch_title; ?></small>
	</div>
</div>
<?php
	echo $args['after_widget'];
}

	// Widget Backend 
	public function form( $instance ) {
		$title = '';
		$switch_position = $this->css_position_prefix .'left';
		if ( !empty($instance[ 'title' ]) ) { $title = $instance[ 'title' ]; } 
		if ( !empty($instance[ 'switch_position' ]) ) { $switch_position = $instance[ 'switch_position' ]; } 
?>
	<p>
	<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo 'Widget Title: '; ?></label> 
	<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
	</p>

	<p>
	<label for="<?php echo $this->get_field_id( 'switch_position' ); ?>"><?php echo 'Button Position: '; ?></label> 
	<select name="<?php echo $this->get_field_name( 'switch_position' ); ?>" id="<?php echo $this->get_field_id( 'switch_position' ); ?>">
		<option <?php if($switch_position == 'lfet'){echo "selected";} ?> value="left">Left</option>
		<option <?php if($switch_position == 'center'){echo "selected";} ?> value="center">Center</option>
		<option <?php if($switch_position == 'right'){echo "selected";} ?> value="right">Right</option>
	</select>
<?php 
	}
	// Updating widget replacing old instances with new
	public function update( $new_instance, $old_instance ) {
		$instance 						= $old_instance;
		$instance['title'] 				= strip_tags( $new_instance['title'] );
		$instance['switch_position'] 	= strip_tags( $new_instance['switch_position'] );
		return $instance;
	}
} // Class OSNY_NightMode_Widget end

//Register and load the widget
add_action( 'widgets_init', 'NightMode_Widget_init' );
function NightMode_Widget_init() {
	register_widget( 'OSNY_NightMode_Widget' );
}

}

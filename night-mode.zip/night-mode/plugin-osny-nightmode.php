<?php
/*
 * Plugin Name: Night Mode
 * Version: 3.0.0
 * Description: WordPress Night Mode Plugin -  With this plugin you can easily change the background color of pages and adjust it to improve the readability of text, images and videos, Protect eyes from hurting when the screen is too bright by dimming the light or vise-versa.
 * Author: hosny
 * Author Email: developer.hosny@gmail.com
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Prefix for plugin.
 * @var     string
 * @since   1.0.0
 */
$base = 'osny_nightmode_';

/**
 * Show Night Mode switch on home page.
 * @var     string
 * @since   3.0.0
 */
$show_on_home = 'off';

// Load plugin enqueue
require_once( 'includes/class-osny-nightmode-enqueue.php' );
// Load plugin widget
require_once( 'includes/widgets/widget-osny-nightmode.php' );
// Load plugin shortcode
require_once( 'includes/shortcodes/shortcode-osny-nightmode.php' );


/**
 * Returns the main instance of OSNY_NightMode to prevent the need to use globals.
 * @since  1.0.0
 * @return object OSNY_NightMode
 */


add_action( 'init', 'OSNY_NightMode', 10 );
function OSNY_NightMode () {
	$instance = OSNY_NightMode::instance( __FILE__, '3.0.0' );
	if ( is_admin() ) {
		require_once( 'includes/class-osny-nightmode-settings.php' );
		OSNY_NightMode_Settings::instance( $instance );
	}
	return $instance;
}


/**
 * Initial Night Mode for javascript.
 * @since  1.0.0
 * @return js vars
 */
add_action( 'wp_head', 'NightMode_init' );
function NightMode_init(){
	global $base;
	global $show_on_home;
	$text_color 			 = !empty( get_option($base . 'text_color') ) 			 	? esc_html( get_option($base . 'text_color') ) 			 	: "#fff";
	$link_color 			 = !empty( get_option($base . 'link_color') ) 			 	? esc_html( get_option($base . 'link_color') ) 			 	: "#459BE6";
	$toggle_icons 			 = !empty( get_option($base . 'toggle_icons') )				? esc_html( get_option($base . 'toggle_icons') ) 			: "off";
	$switch_on_color 		 = !empty( get_option($base . 'switch_on_color') ) 		 	? esc_html( get_option($base . 'switch_on_color') ) 		: "#13bf11";
	$background_color 		 = !empty( get_option($base . 'background_color') ) 		? esc_html( get_option($base . 'background_color') ) 		: "#1b2836";
	$switch_off_color 		 = !empty( get_option($base . 'switch_off_color') ) 		? esc_html( get_option($base . 'switch_off_color') ) 		: "#fff";
	$switch_button_on_color  = !empty( get_option($base . 'switch_button_on_color') )  	? esc_html( get_option($base . 'switch_button_on_color') )  : "#fff";
	$switch_button_off_color = !empty( get_option($base . 'switch_button_off_color') ) 	? esc_html( get_option($base . 'switch_button_off_color') ) : "#fff";
	$img_opacity 			 = !empty( get_option($base . 'img_opacity') )				? esc_html( get_option($base . 'img_opacity') ) 			: "off";
	$img_filter 			 = !empty( get_option($base . 'img_filter') )				? esc_html( get_option($base . 'img_filter') ) 				: "off";
	$header_footer_color 	 = !empty( get_option($base . 'header_footer_color') ) 		? esc_html( get_option($base . 'header_footer_color') ) 	: "";
	$stay_on_with_navigation = !empty( get_option($base . 'stay_on_with_navigation') ) 	? esc_html( get_option($base . 'stay_on_with_navigation') ) : "off";
	$show_on_home			 = !empty( get_option($base . 'show_on_home') ) 			? esc_html( get_option($base . 'show_on_home') ) 			: "off";
?>

<script>
var nightmode_text_color="<?php echo $text_color; ?>";
var nightmode_link_color="<?php echo $link_color; ?>";
var nightmode_toggle_icons="<?php echo $toggle_icons; ?>";
var switch_on_color="<?php echo $switch_on_color; ?>";
var switch_off_color="<?php echo $switch_off_color; ?>";
var nightmode_background_color="<?php echo $background_color; ?>";
var switch_button_on_color="<?php echo $switch_button_on_color; ?>";
var switch_button_off_color="<?php echo $switch_button_off_color; ?>";
var nightmode_img_opacity="<?php echo $img_opacity; ?>";
var nightmode_img_filter="<?php echo $img_filter; ?>";
var header_footer_color="<?php echo $header_footer_color; ?>";
var stay_on_with_navigation="<?php echo $stay_on_with_navigation; ?>";
</script>
<?php 
} 


/**
 * Get Night Mode shortcode above the content
 * @since  1.0.0
 * @return Content with Night Mode shortcode
 */
add_filter( 'the_content', 'OSNY_NightMode_Above_Content', 20 );
function OSNY_NightMode_Above_Content($content) {
	global $show_on_home;
	
	if ( is_page() || is_single() || (is_home() && $show_on_home == 'on') ) {
		
		global $base;
		$add_above_content_posts = !empty( get_option($base . 'add_above_content_posts') ) ? esc_html( get_option($base . 'add_above_content_posts') ) : "off";
		$add_above_content_pages = !empty( get_option($base . 'add_above_content_pages') ) ? esc_html( get_option($base . 'add_above_content_pages') ) : "off";

		if ( $add_above_content_posts == 'on' && $add_above_content_pages == 'on' ) {
			return do_shortcode( '[nightmode]' ) . $content;
		}

		if ( $add_above_content_posts == 'on' && is_single() ) {
			return do_shortcode( '[nightmode]' ) . $content;
		}

		if ( $add_above_content_pages == 'on' && is_singular() && !is_single() ) {
			return do_shortcode( '[nightmode]' ) . $content;
		}

		return $content;

	}else{
		return $content;
	}
}